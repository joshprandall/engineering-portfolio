# Publish in about five minutes

1. Extract the ZIP and open the folder.
2. Run the three README commands. The sample audit returns exit 1 intentionally; all tests should pass.
3. Create a public GitHub repository named `recovery-readiness-auditor`. Description: “Offline Python audit of declared backup and recovery readiness, with deterministic examples and tests.” Do not add a starter README.
4. Choose **uploading an existing file** (or Add file → Upload files). Drag this folder’s contents into GitHub, preserving `examples`, `tests`, and `.github/workflows`. Commit. If your browser omits the hidden `.github` folder, create `.github/workflows/test.yml` manually using the supplied content; it is optional for local operation.
5. Suggested topics: `python`, `infrastructure`, `disaster-recovery`, `automation`, `portfolio`.
6. Send the repository URL back to add its verified link to the portfolio. For now the website offers downloadable source.

Before an interview, explain RPO versus RTO, why this cannot prove recoverability, UTC timestamps, boundary tests, and exit codes. Start with sample data. Never upload real company inventories or credentials.

Optional Git workflow after creating the repository:

```sh
git init
git add .
git commit -m "Add recovery readiness auditor with examples and tests"
git branch -M main
git remote add origin https://github.com/joshprandall/recovery-readiness-auditor.git
git push -u origin main
```

That URL is the intended repository name, not a claim that it already exists. Replace it if you choose another name/account.
