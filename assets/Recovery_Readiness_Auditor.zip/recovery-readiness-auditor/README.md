# Recovery Readiness Auditor

An offline Python command-line tool that checks a service inventory for recorded recovery gaps. A small infrastructure-engineering portfolio project with explicit assumptions, deterministic examples, machine-readable output, and boundary tests.

## Quick start

Python 3.10 or newer. No third-party dependencies, accounts, credentials, or network access.

```sh
python audit.py examples/services.csv --as-of 2026-09-06T12:00:00Z
python audit.py examples/services.csv --as-of 2026-09-06T12:00:00Z --format json
python -m unittest discover -s tests -v
```

On Windows, use `py` instead of `python` if needed. Run from the project folder. The sample audit deliberately exits with code **1**, because two fictional services have gaps. This is expected behavior.

## Checks

- Recorded backup age versus declared recovery point objective (RPO).
- Restore-test age versus configurable policy (90 days by default).
- Missing service names, owners, runbook references, and backup/test timestamps.
- Positive finite RPO and recovery time objective (RTO) values.
- Invalid/future dates, malformed CSV rows, and duplicate service names or columns.

The CSV is a user-provided inventory, not a backup-platform connection. All examples are fictional. `runbook_url` can hold a path or URL; the tool does not fetch it or verify its existence. No client data is included.

## Results and limits

Exit **0**: no recorded gaps. Exit **1**: findings. Exit **2**: input/configuration error.

A finding is not proof of downtime. A clean result is not proof of recoverability. The tool does not verify backup integrity, successful completion, replication consistency, application dependencies, or restore duration. It checks whether RTO is declared, not whether it was achieved. A restore exercise remains necessary.

The backup timestamp should represent the latest successful backup according to your source. Backups exactly at the RPO boundary pass; older backups fail. Timezone-aware ISO 8601 timestamps are mandatory; comparisons happen in UTC.

## Design decisions

- Standard library only for portability and straightforward review.
- Evaluation separated from I/O for rule-level tests.
- `--as-of` for reproducible examples.
- JSON for reporting and CI integration.
- Explicit findings instead of a synthetic readiness percentage.

At the sample audit time, Inventory API has no recorded gaps. Reporting Database exceeds its 4-hour RPO and has an overdue restore test. File Services lacks an owner and runbook reference. See `examples/sample-report.json`.

## Future directions (not implemented)

Backup-platform export adapters, per-service restore policies, measured restore-duration checks, and Markdown reports. Keep credentials and real inventories out of this repository.

## Authorship and portfolio use

Prepared with AI assistance for Joshua Randall’s engineering portfolio. Review, run, and understand the implementation before presenting it as personal work. This is a new demonstration, not a claim of deployment at a previous employer.

MIT License; see LICENSE.
