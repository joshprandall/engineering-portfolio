from pathlib import Path
import json,re,urllib.parse,subprocess,sys,collections,csv
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'public_html'
s=(P/'knowledge-data.js').read_text(encoding='utf-8');D=json.loads(s[s.index('{'):s.rfind('}')+1]);L=D['lessons'];errors=[]
ids=[x['id'] for x in L];titles=[re.sub(r'\W+',' ',x['title'].lower()).strip() for x in L];idset=set(ids)
expected={'cloud':1200,'advanced':1200,'software':1150,'cyber':1150,'leadership':1100,'math':1100,'physics':1100}
counts=collections.Counter(x['domain'] for x in L)
if D.get('version')!='1.0.0':errors.append('wrong version')
if len(L)!=8000:errors.append(f'expected 8000, got {len(L)}')
if dict(counts)!=expected:errors.append('domain counts '+repr(dict(counts)))
if len(ids)!=len(set(ids)):errors.append('duplicate IDs')
if len(titles)!=len(set(titles)):errors.append('duplicate titles')
allowed=set('openstax.org sre.google www.nist.gov www.rfc-editor.org www.postgresql.org docs.python.org git-scm.com csrc.nist.gov www.intel.com dlmf.nist.gov kubernetes.io docs.nvidia.com docs.kernel.org learn.microsoft.com www.mpi-forum.org cheatsheetseries.owasp.org ocw.mit.edu www.openmp.org docs.riscv.org pages.nist.gov www.cisa.gov quantum.cloud.ibm.com docs.redhat.com developer.hashicorp.com www.usenix.org docs.aws.amazon.com opentelemetry.io www.gnu.org lamport.azurewebsites.net slurm.schedmd.com prometheus.io www.freedesktop.org systemd.io escholarship.org www.iana.org pubs.opengroup.org developer.download.nvidia.com'.split())
for x in L:
    if x.get('verification',{}).get('status')!='verified':errors.append(x['id']+': not verified')
    if not x.get('verifiedClaims'):errors.append(x['id']+': missing claim')
    if not x.get('references'):errors.append(x['id']+': missing evidence')
    for r in x.get('references',[]):
        u=urllib.parse.urlparse(r[1]);host=u.netloc.lower()
        if u.scheme!='https' or not host:errors.append(x['id']+': bad URL')
        if host not in allowed:errors.append(x['id']+': unapproved source '+host)
    for k in ('prereq','related'):
        for y in x.get(k,[]):
            if y not in idset:errors.append(x['id']+': bad '+k+' '+y)
    q=x.get('quiz')
    if q and (not q.get('options') or not isinstance(q.get('answer'),int) or not 0<=q['answer']<len(q['options'])):errors.append(x['id']+': bad quiz')
if len(D.get('paths',[]))!=300:errors.append('paths '+str(len(D.get('paths',[]))))
for p in D.get('paths',[]):
    if not p.get('lesson_ids'):errors.append('empty path '+p.get('id','?'))
    for y in p.get('lesson_ids',[]):
        if y not in idset:errors.append('path missing '+y)
if len(D.get('glossary',[]))!=1600:errors.append('glossary '+str(len(D.get('glossary',[]))))
for g in D.get('glossary',[]):
    if g.get('lesson_id') not in idset:errors.append('glossary missing '+g.get('term','?'))
labs=sum(x.get('kind')=='Lab' for x in L);inter=sum(1 for x in L if x.get('kind')=='Lab' or x.get('interactive'))
if labs!=3000:errors.append('labs '+str(labs))
if inter!=4000:errors.append('interactive union '+str(inter))
for name in ['learn.html','learn-browse.html','learn-paths.html','learn-practice.html','learn-labs.html','learn-glossary.html','learn-map.html','learn-mastery.html','learn-verify.html','index.html','projects.html']:
    if not (P/name).exists():errors.append('missing '+name)
for f in P.glob('*.html'):
    t=f.read_text(encoding='utf-8');xs=re.findall(r'\bid=["\']([^"\']+)',t);dups=[k for k,v in collections.Counter(xs).items() if v>1]
    if dups:errors.append(f.name+': duplicate IDs '+repr(dups[:5]))
try:subprocess.run(['node','--check',str(P/'knowledge.js')],check=True,capture_output=True,text=True)
except Exception as e:errors.append('JS syntax '+str(e))
M=json.loads((P/'verification-manifest.json').read_text(encoding='utf-8'))
if M.get('version')!='1.0.0' or M.get('count')!=8000 or len(M.get('records',[]))!=8000:errors.append('manifest mismatch')
print('VALIDATION','PASS' if not errors else 'FAIL')
print('lessons',len(L),'domains',dict(counts),'labs',labs,'paths',len(D.get('paths',[])),'glossary',len(D.get('glossary',[])),'interactive_experiences',inter,'model_workflows',sum(bool(x.get('interactive')) for x in L))
if errors:
    print('\n'.join('ERROR: '+e for e in errors[:120]));sys.exit(1)
