from pathlib import Path
import json,re,urllib.parse,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]; P=ROOT/'public_html'
s=(P/'knowledge-data.js').read_text(encoding='utf-8');D=json.loads(s[s.index('{'):s.rfind('}')+1])
errors=[]; notes=[]
lessons=D['lessons']; ids=[l['id'] for l in lessons]; titles=[re.sub(r'\W+',' ',l['title'].lower()).strip() for l in lessons]
if D.get('version')!='0.7.0': errors.append(f"version is {D.get('version')}")
if len(lessons)!=950: errors.append(f'lesson count {len(lessons)} != 950')
if len(ids)!=len(set(ids)): errors.append('duplicate lesson IDs')
if len(titles)!=len(set(titles)): errors.append('duplicate normalized lesson titles')
idset=set(ids)
required=['title','summary','explanation','why','example','takeaway','difficulty','kind','references','verification','verifiedClaims']
approved={
'www.rfc-editor.org','www.intel.com','openstax.org','kubernetes.io','sre.google','docs.kernel.org','learn.microsoft.com','docs.nvidia.com','www.mpi-forum.org','docs.riscv.org','www.openmp.org','www.postgresql.org','www.nist.gov','quantum.cloud.ibm.com','docs.python.org','docs.redhat.com','dlmf.nist.gov','csrc.nist.gov','git-scm.com','cheatsheetseries.owasp.org','docs.aws.amazon.com','slurm.schedmd.com','www.gnu.org','pages.nist.gov','developer.hashicorp.com','www.usenix.org','ocw.mit.edu','www.freedesktop.org','systemd.io','www.cisa.gov','opentelemetry.io','lamport.azurewebsites.net','prometheus.io','www.iana.org','pubs.opengroup.org','escholarship.org','developer.download.nvidia.com'
}
for l in lessons:
    for k in required:
        if not l.get(k): errors.append(f"{l['id']}: missing {k}")
    if not isinstance(l.get('verifiedClaims'),list) or not all(str(x).strip() for x in l.get('verifiedClaims',[])): errors.append(f"{l['id']}: invalid verifiedClaims")
    refs=l.get('references',[])
    if not refs: errors.append(f"{l['id']}: no sources")
    for r in refs:
        if not isinstance(r,list) or len(r)!=2 or not r[0] or not r[1]: errors.append(f"{l['id']}: malformed source {r}"); continue
        u=urllib.parse.urlparse(r[1])
        if u.scheme!='https': errors.append(f"{l['id']}: non-HTTPS source {r[1]}")
        if u.netloc not in approved: errors.append(f"{l['id']}: source host not approved {u.netloc}")
    for k in ('prereq','related'):
        for rid in l.get(k,[]):
            if rid not in idset: errors.append(f"{l['id']}: bad {k} reference {rid}")
    q=l.get('quiz')
    if q:
        opts=q.get('options',[]); ans=q.get('answer')
        if not opts or not isinstance(ans,int) or ans<0 or ans>=len(opts): errors.append(f"{l['id']}: invalid quiz")
for path in D['paths']:
    if not path.get('lesson_ids'): errors.append(f"path {path.get('id')}: empty")
    for rid in path.get('lesson_ids',[]):
        if rid not in idset: errors.append(f"path {path.get('id')}: missing lesson {rid}")
for g in D['glossary']:
    if g.get('lesson_id') not in idset: errors.append(f"glossary {g.get('term')}: missing lesson {g.get('lesson_id')}")
# Implemented interactive type audit.
js=(P/'knowledge.js').read_text(encoding='utf-8')
implemented=set(re.findall(r"type==='([^']+)'",js))
implemented.update(['urljourney','dns','api','tls','tcp'])
implemented.update(['vector','derivative','matrix','force','projectile','wave','doppler','ohm'])
used={l['interactive'] for l in lessons if l.get('interactive')}
missing=sorted(used-implemented)
if missing: errors.append('interactive types without implementation: '+', '.join(missing))
if 'Interactive model coming in a later library release.' in js: errors.append('placeholder interactive fallback still present')
# HTML duplicate IDs and local href/src checks.
for f in P.glob('*.html'):
    t=f.read_text(encoding='utf-8')
    html_ids=re.findall(r'\bid=["\']([^"\']+)',t); dups={x for x in html_ids if html_ids.count(x)>1}
    if dups: errors.append(f'{f.name}: duplicate IDs {sorted(dups)}')
    for attr,target in re.findall(r'\b(href|src)=["\']([^"\']+)',t):
        if target.startswith(('http:','https:','mailto:','#','javascript:','data:')): continue
        target=target.split('?',1)[0].split('#',1)[0]
        if not target: continue
        if not (P/target).exists() and not (ROOT/target).exists():
            # Existing portfolio assets/styles/app are overlay dependencies and intentionally not bundled.
            if target in {'styles.css','app.js','resume.html'} or target.startswith('assets/'): continue
            errors.append(f'{f.name}: missing local {attr} {target}')
# JS syntax + Python source compilation.
try: subprocess.run(['node','--check',str(P/'knowledge.js')],check=True,capture_output=True,text=True)
except subprocess.CalledProcessError as e: errors.append('knowledge.js syntax: '+e.stderr.strip())
for f in (ROOT/'source').glob('*.py'):
    try: compile(f.read_text(encoding='utf-8'),str(f),'exec')
    except Exception as e: errors.append(f'{f.name} compile error: {e}')
# Verification manifest parity.
M=json.loads((P/'verification-manifest.json').read_text(encoding='utf-8'))
if M.get('count')!=len(lessons): errors.append('verification manifest count mismatch')
if len(M.get('records',[]))!=len(lessons): errors.append('verification manifest records mismatch')
from collections import Counter
counts=Counter(l['domain'] for l in lessons)
lab_count=sum(l.get('kind')=='Lab' for l in lessons); interactive_count=sum(bool(l.get('interactive')) for l in lessons); types=len(used)
atlas_count=sum(len(v) for v in D['atlas'].values()) if isinstance(D['atlas'],dict) else 0
print('VALIDATION', 'PASS' if not errors else 'FAIL')
print('lessons',len(lessons),'unique_ids',len(set(ids)),'verified',sum(bool(l.get('verifiedClaims') and l.get('references')) for l in lessons))
print('domains',dict(counts));print('paths',len(D['paths']),'glossary',len(D['glossary']),'labs',lab_count,'interactive',interactive_count,'interactive_types',types,'atlas',atlas_count)
print('implemented_types',len(implemented),'used_types',len(used))
if errors:
    print('\n'.join('ERROR: '+e for e in errors));sys.exit(1)
