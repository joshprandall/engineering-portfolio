#!/usr/bin/env python3
"""Build v1.1.0 Deep Learning Edition from v1.0.0 data.

Facts remain anchored to the existing verified claims and authoritative references.
The deep-learning packs add teaching scaffolding, not new technical claims.
Packs are split by domain/category and lazy-loaded in the browser so the mobile
experience does not require downloading all expanded material at startup.
"""
from pathlib import Path
from collections import defaultdict
import json, re

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'public_html'/'knowledge-data.js'
DEEP=ROOT/'public_html'/'deep-learning'

VIDEO_PROFILES={
'networking':{'id':'BWZ-MHIhqjM','title':'What is Subnetting? — Subnetting Mastery, Part 1','channel':'Practical Networking','why':'A visual networking foundation for addressing and network-boundary intuition.'},
'kubernetes':{'id':'aSrqRSk43lY','title':'Kubernetes Explained','channel':'IBM Technology','why':'A broad visual foundation for Kubernetes concepts and vocabulary.'},
'operating-systems':{'id':'26QPDBe-NB8','title':'Operating Systems: Crash Course Computer Science #18','channel':'CrashCourse','why':'A broad operating-systems foundation before deeper systems material.'},
'gpu':{'id':'GmNkYayuaA4','title':'Getting Started with CUDA and Parallel Programming','channel':'NVIDIA Developer','why':'A CUDA and parallel-programming foundation from NVIDIA Developer.'},
'quantum':{'id':'Tk9LOL9--Y4','title':'Introduction to Qiskit | Coding with Qiskit 1.x','channel':'Qiskit','why':'A quantum-computing coding foundation from the Qiskit channel.'},
'software':{'id':'8hly31xKli0','title':'Algorithms and Data Structures Tutorial — Full Course for Beginners','channel':'freeCodeCamp.org','why':'A long-form software and data-structures foundation.'},
'cyber':{'id':'8ZtInClXe1Q','title':'How NOT to Store Passwords!','channel':'Computerphile','why':'A concrete security video that models evidence-based reasoning about implementation choices.'},
'leadership':{'id':'eopc_ijIfLg','title':'Site Reliability Engineering (SRE) Fundamentals','channel':'Google Cloud Events','why':'A reliability/operations foundation connecting technical systems with operational practice.'},
'math-algebra':{'id':'kpCJyQ2usJ4','title':'The beauty of algebra','channel':'Khan Academy','why':'An accessible mathematical foundation for algebraic reasoning.'},
'math-calculus':{'id':'N2PpRnFqnqY','title':'Derivative as a concept','channel':'Khan Academy','why':'A conceptual calculus foundation focused on understanding before procedure.'},
'physics':{'id':'F3N5EkMX_ks','title':'8.01SC Classical Mechanics Introduction','channel':'MIT OpenCourseWare','why':'A university-level physics foundation from MIT OpenCourseWare.'},
}

def extract_obj(text):
    start=text.index('{'); depth=0; ins=False; esc=False
    for i,ch in enumerate(text[start:],start):
        if ins:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': ins=False
        else:
            if ch=='"': ins=True
            elif ch=='{': depth+=1
            elif ch=='}':
                depth-=1
                if depth==0:return json.loads(text[start:i+1])
    raise ValueError('Could not parse knowledge object')

def slug(s):
    return re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',s.lower())).strip('-') or 'general'

def norm(s): return re.sub(r'\s+',' ',str(s or '')).strip()

def video_key(l):
    d=l['domain']; c=l.get('category','').lower(); text=' '.join([l.get('title',''),l.get('summary',''),' '.join(l.get('tags',[]))]).lower()
    if d=='cloud':
        if 'kubernetes' in c or 'kubernetes' in text:return 'kubernetes'
        if c=='networking' or any(k in text for k in ('dns','subnet','routing','tcp','udp','ipv4','ipv6','vlan','arp','bgp','ospf')):return 'networking'
        return 'operating-systems'
    if d=='advanced':
        if 'quantum' in c or 'quantum' in text or 'qubit' in text:return 'quantum'
        if 'gpu' in c or 'cuda' in text or 'simt' in text:return 'gpu'
        return 'operating-systems'
    if d=='software':return 'software'
    if d=='cyber':return 'cyber'
    if d=='leadership':return 'leadership'
    if d=='math':return 'math-calculus' if c=='calculus' or any(k in text for k in ('derivative','integral','limit','calculus')) else 'math-algebra'
    return 'physics'

def analogy(l):
    return {
      'cloud':'Analogy — not literal: picture a city of services with addresses, routes, rules, and responsibilities. Use that picture only to organize the idea; the verified claim is the literal technical statement.',
      'advanced':'Analogy — not literal: picture a workshop with specialized tools and workers. Some resources do different jobs and coordination matters. The real hardware, mathematics, or protocol is defined by the verified claim and evidence.',
      'software':'Analogy — not literal: picture a recipe being carried out in a kitchen with ingredients, tools, tests, and feedback. Software mechanisms are more precise than the analogy; use it only as a memory scaffold.',
      'cyber':'Analogy — not literal: doors, keys, checkpoints, and records can help separate identity, authorization, barriers, and evidence. Real security systems are more complex; the verified claim is the factual boundary.',
      'leadership':'Analogy — not literal: picture a control room where people need roles, signals, priorities, communication, and feedback. Real organizations vary; use the analogy only to organize the lesson.',
      'math':'Analogy — not literal: mathematics can be treated like a language for patterns and relationships. The analogy is not a proof; definitions, worked reasoning, and cited sources establish the result.',
      'physics':'Analogy — not literal: a physical model is like a carefully labeled map that leaves out some detail to make a relationship easier to study. The map is not the territory; equations, measurements, and cited evidence define the claim.'
    }[l['domain']]

def main():
    data=extract_obj(DATA.read_text(encoding='utf-8'))
    lesson_by_id={l['id']:l for l in data['lessons']}
    glossary_by_lesson=defaultdict(list)
    for g in data.get('glossary',[]): glossary_by_lesson[g.get('lesson_id')].append(g)
    domain_name={d['id']:d['name'] for d in data['domains']}
    packs=defaultdict(dict)
    index={}
    for l in data['lessons']:
        claim=(l.get('verifiedClaims') or [l.get('takeaway') or l.get('summary')])[0]
        prereq=[lesson_by_id[x]['title'] for x in l.get('prereq',[]) if x in lesson_by_id][:6]
        related=[lesson_by_id[x]['title'] for x in l.get('related',[]) if x in lesson_by_id][:8]
        vocab=glossary_by_lesson.get(l['id'],[])[:6]
        if not vocab:
            tags=[t.lower() for t in l.get('tags',[]) if t]
            for g in data.get('glossary',[]):
                if g.get('domain')!=l['domain']:continue
                term=g.get('term','').lower()
                if any(t in term for t in tags):vocab.append(g)
                if len(vocab)>=6:break
        vk=video_key(l); v=VIDEO_PROFILES[vk]
        pack={
          'essentialQuestion':f"What does {l['title']} mean, why does it matter, how can it be used, and how can the central claim be independently checked?",
          'verifiedBoundary':claim,
          'analogy':analogy(l),
          'starter':{
            'plainStart':f"Start with one idea instead of memorizing everything at once: {norm(l.get('takeaway') or l.get('summary'))}",
            'tryThis':f"Use the lesson example as a practice situation: {norm(l.get('example'))} Predict first; then compare your thinking with the verified claim.",
            'helper':'If a word is unfamiliar, open the vocabulary cards first. Return to the big idea and explain it in your own words before moving to technical vocabulary.'
          },
          'technical':{
            'scope':'Use the cited evidence to support the verified claim only. Do not infer undocumented implementation details, universal behavior, or current product behavior that the sources do not establish.',
            'versionCaution':'This topic is version-sensitive. Check current vendor, project, or standards documentation before operational use.' if l.get('versionSensitive') else 'No version dependency is currently flagged. The evidence links remain the authority for the published claim.',
            'prerequisites':prereq,'connections':related
          },
          'reasoningSteps':[
            'State the question in your own words before reading the answer.',
            'Identify the exact verified claim and separate it from examples, analogies, and hypotheses.',
            'Trace the mechanism or reasoning in the Learn view one step at a time.',
            'Apply the idea to the worked example, then change one assumption and predict what changes.',
            'Challenge the common misconception or invent a plausible wrong answer and explain why it fails.',
            'Open the Evidence view and independently inspect at least one cited source.'
          ],
          'memoryLadder':[
            f"Explain “{l['title']}” in one sentence without looking.",
            'List the important vocabulary and define each term in plain language.',
            'Recreate the worked example from memory, then compare it with the lesson.',
            'Name one misconception or overgeneralization you should avoid.',
            'Point to the exact verified claim and identify which evidence source supports it.',
            'Teach the idea twice: once to a beginner and once using the correct technical vocabulary.'
          ],
          'labPlan':[
            'Predict the outcome before manipulating the model or revealing the answer.',
            'Write the assumption you are testing.',
            'Run the interactive model or work through the controlled scenario.',
            'Compare the result with the verified claim and the worked example.',
            'Change one input, assumption, or condition and explain how your reasoning changes.',
            'Finish by checking the Evidence view and writing one sentence about what the source does and does not establish.'
          ],
          'vocabulary':[{'term':g.get('term',''),'definition':g.get('definition','')} for g in vocab],
          'video':{'profile':vk,'youtubeId':v['id'],'title':v['title'],'channel':v['channel'],'why':v['why'],'searchQuery':f"{l['title']} {domain_name[l['domain']]} tutorial"}
        }
        key=f"{l['domain']}/{slug(l.get('category','general'))}.json"
        packs[key][l['id']]=pack; index[f"{l['domain']}|{l.get('category','general')}"]=key
    DEEP.mkdir(parents=True,exist_ok=True)
    for key,items in packs.items():
        path=DEEP/key; path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(items,separators=(',',':'),ensure_ascii=False),encoding='utf-8')
    (DEEP/'index.json').write_text(json.dumps(index,separators=(',',':'),ensure_ascii=False),encoding='utf-8')
    (DEEP/'video-profiles.json').write_text(json.dumps(VIDEO_PROFILES,separators=(',',':'),ensure_ascii=False),encoding='utf-8')
    data['version']='1.1.0'; data['buildDate']='2026-09-13'; data['lastBuilt']='2026-09-13'
    data['deepLearning']={'enabled':True,'chunkRoot':'deep-learning','chunkCount':len(packs),'lessonCount':len(data['lessons']),'audienceModes':['starter','general','technical'],'videoPolicy':'Supplementary video companions are not verification evidence.'}
    data['verificationPolicy']=(data.get('verificationPolicy','')+' v1.1.0 adds child/beginner, general, and technical scaffolding, visuals, practice, and supplementary video companions without adding unsupported technical claims; YouTube is never used as verification evidence.').strip()
    DATA.write_text('window.JR_KNOWLEDGE = '+json.dumps(data,separators=(',',':'),ensure_ascii=False)+';\n',encoding='utf-8')
    print(f"Built {len(data['lessons']):,} deep-learning packs across {len(packs)} lazy-loaded chunks.")

if __name__=='__main__':main()
