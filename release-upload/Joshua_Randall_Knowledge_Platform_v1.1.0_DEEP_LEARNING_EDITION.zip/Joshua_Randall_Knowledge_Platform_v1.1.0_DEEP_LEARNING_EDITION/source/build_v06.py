from pathlib import Path
import json,re,csv
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'public_html'
REVIEW='2026-09-07'

def load_data():
    s=(P/'knowledge-data.js').read_text(encoding='utf-8'); st=s.index('{'); d=0; ins=False; esc=False
    for i,ch in enumerate(s[st:],st):
        if ins:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': ins=False
        else:
            if ch=='"': ins=True
            elif ch=='{': d+=1
            elif ch=='}':
                d-=1
                if d==0: return json.loads(s[st:i+1])
    raise RuntimeError('knowledge JSON not found')
D=load_data()
# Normalize two inherited v0.5 overlaps into distinct source-specific concepts before
# adding the v0.6 curriculum. This builder is a migration from a v0.5.0 base.
for _l in D.get('lessons',[]):
    if _l.get('id')=='cloud-v05-active-directory-replication':
        _l.update({
            'title':'Active Directory Site Topology',
            'summary':'AD DS site topology is a logical representation of the physical network that helps route client queries and replication traffic.',
            'explanation':'Active Directory Domain Services uses sites, subnets, site links, and related topology information to model network location. Microsoft documents site topology as a way to route client queries and replication traffic efficiently across the physical network.\n\nThis object focuses on topology rather than the separate concept of multi-master replication.',
            'why':'Site topology helps administrators reason about domain-controller placement, WAN-aware replication, and client affinity.',
            'example':'Two offices connected by a slower WAN link can be represented as separate AD sites with topology information that reflects the network connection.',
            'takeaway':'AD site topology maps network location into directory behavior for replication and client service location.',
            'tags':['active directory','sites','topology','replication'],
            'quiz':{'q':'What does an AD DS site topology represent?','options':['A logical representation of the physical network used to help route queries and replication traffic.','A replacement for DNS zones.','A list of local user profiles.','A RAID layout for domain-controller disks.'],'answer':0,'explanation':'Microsoft documents AD DS site topology as a logical representation of the physical network used to support efficient query and replication routing.'},
            'objectives':['Explain what AD DS site topology represents','Connect sites and links to replication and client-location behavior'],
            'references':[['Microsoft Learn — Designing the Site Topology','https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/plan/designing-the-site-topology']]})
        _l['verification']['sourceCount']=1
    elif _l.get('id')=='advanced-v05-gpu-occupancy':
        _l.update({
            'title':'CUDA Occupancy and Register Pressure',
            'summary':'High per-thread register use can reduce the number of resident thread blocks and therefore lower CUDA multiprocessor occupancy.',
            'explanation':'Registers are a finite streaming-multiprocessor resource shared across resident threads. NVIDIA documents register availability as one factor that determines occupancy: if a kernel uses more registers per thread, fewer blocks or warps may be able to reside concurrently on an SM.\n\nThis object focuses on one resource constraint on occupancy rather than re-defining occupancy itself.',
            'why':'It connects a concrete kernel resource choice to the number of warps available for latency hiding.',
            'example':'Two kernels with the same block size can achieve different occupancy if one requires substantially more registers per thread.',
            'takeaway':'Register pressure can constrain occupancy because resident threads share a finite register file.',
            'tags':['gpu','cuda','registers','occupancy'],
            'quiz':{'q':'How can high register use per thread affect CUDA occupancy?','options':['It can reduce the number of thread blocks or warps that can reside concurrently on an SM.','It always increases the number of resident warps.','It changes the PCIe link width.','It disables all shared memory.'],'answer':0,'explanation':'NVIDIA documents register availability as a key resource constraint when calculating occupancy.'},
            'objectives':['Explain how register pressure can constrain CUDA occupancy','Relate per-thread resource use to resident concurrency'],
            'references':[['NVIDIA — CUDA C++ Best Practices Guide: Occupancy','https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/#occupancy']]})
        _l['verification']['sourceCount']=1
_seen_lpm=False
for _g in D.get('glossary',[]):
    if _g.get('term')=='Longest Prefix Match':
        if not _seen_lpm:
            _seen_lpm=True
        else:
            _g['term']='Longest-Prefix Route Selection'
            _g['definition']='When multiple routes match a destination, routing selects the route with the most specific matching prefix.'
SRC={
'rfc768':('RFC 768 — User Datagram Protocol','https://www.rfc-editor.org/rfc/rfc768'),
'rfc1918':('RFC 1918 — Address Allocation for Private Internets','https://www.rfc-editor.org/rfc/rfc1918'),
'rfc4251':('RFC 4251 — The Secure Shell (SSH) Protocol Architecture','https://www.rfc-editor.org/rfc/rfc4251'),
'rfc4511':('RFC 4511 — Lightweight Directory Access Protocol (LDAP)','https://www.rfc-editor.org/rfc/rfc4511'),
'rfc4861':('RFC 4861 — Neighbor Discovery for IPv6','https://www.rfc-editor.org/rfc/rfc4861'),
'rfc5737':('RFC 5737 — IPv4 Address Blocks Reserved for Documentation','https://www.rfc-editor.org/rfc/rfc5737'),
'rfc7348':('RFC 7348 — Virtual eXtensible Local Area Network (VXLAN)','https://www.rfc-editor.org/rfc/rfc7348'),
'rfc8446':('RFC 8446 — TLS 1.3','https://www.rfc-editor.org/rfc/rfc8446'),
'rfc9110':('RFC 9110 — HTTP Semantics','https://www.rfc-editor.org/rfc/rfc9110'),
'rfc9111':('RFC 9111 — HTTP Caching','https://www.rfc-editor.org/rfc/rfc9111'),
'rfc4120':('RFC 4120 — Kerberos V5','https://www.rfc-editor.org/rfc/rfc4120'),
'rfc6749':('RFC 6749 — OAuth 2.0 Authorization Framework','https://www.rfc-editor.org/rfc/rfc6749'),
'rfc7636':('RFC 7636 — Proof Key for Code Exchange by OAuth Public Clients','https://www.rfc-editor.org/rfc/rfc7636'),
'kernel_ns':('Linux Kernel Documentation — Namespaces','https://docs.kernel.org/admin-guide/namespaces/index.html'),
'kernel_cgroup':('Linux Kernel Documentation — Control Groups v2','https://docs.kernel.org/admin-guide/cgroup-v2.html'),
'systemd':('systemd Documentation','https://systemd.io/'),
'bash':('GNU Bash Reference Manual','https://www.gnu.org/software/bash/manual/bash.html'),
'python_types':('Python Documentation — Built-in Types','https://docs.python.org/3/library/stdtypes.html'),
'python_exc':('Python Documentation — Built-in Exceptions','https://docs.python.org/3/library/exceptions.html'),
'python_asyncio':('Python Documentation — asyncio','https://docs.python.org/3/library/asyncio.html'),
'git':('Git — Reference Manual','https://git-scm.com/docs'),
'pg_tx':('PostgreSQL Documentation — Transactions','https://www.postgresql.org/docs/current/tutorial-transactions.html'),
'pg_mvcc':('PostgreSQL Documentation — Concurrency Control / MVCC','https://www.postgresql.org/docs/current/mvcc.html'),
'pg_index':('PostgreSQL Documentation — Indexes','https://www.postgresql.org/docs/current/indexes.html'),
'pg_explain':('PostgreSQL Documentation — EXPLAIN','https://www.postgresql.org/docs/current/sql-explain.html'),
'pg_queries':('PostgreSQL Documentation — Queries','https://www.postgresql.org/docs/current/queries.html'),
'ps':('Microsoft Learn — PowerShell Documentation','https://learn.microsoft.com/en-us/powershell/'),
'k8s_ns':('Kubernetes Documentation — Namespaces','https://kubernetes.io/docs/concepts/overview/working-with-objects/namespaces/'),
'k8s_service':('Kubernetes Documentation — Service','https://kubernetes.io/docs/concepts/services-networking/service/'),
'k8s_dns':('Kubernetes Documentation — DNS for Services and Pods','https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/'),
'k8s_sa':('Kubernetes Documentation — Service Accounts','https://kubernetes.io/docs/concepts/security/service-accounts/'),
'k8s_affinity':('Kubernetes Documentation — Assigning Pods to Nodes','https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/'),
'k8s_resource':('Kubernetes Documentation — Resource Management for Pods and Containers','https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/'),
'k8s_sched':('Kubernetes Documentation — Kubernetes Scheduler','https://kubernetes.io/docs/concepts/scheduling-eviction/kube-scheduler/'),
'k8s_net':('Kubernetes Documentation — Services, Load Balancing, and Networking','https://kubernetes.io/docs/concepts/services-networking/'),
'aws_routes':('AWS Documentation — Route Tables','https://docs.aws.amazon.com/vpc/latest/userguide/VPC_Route_Tables.html'),
'aws_nacl':('AWS Documentation — Network ACLs','https://docs.aws.amazon.com/vpc/latest/userguide/vpc-network-acls.html'),
'azure_vnet':('Microsoft Learn — Azure Virtual Network','https://learn.microsoft.com/en-us/azure/virtual-network/virtual-networks-overview'),
'azure_avail':('Microsoft Learn — Availability Zones','https://learn.microsoft.com/en-us/azure/reliability/availability-zones-overview'),
'terraform_provider':('HashiCorp Developer — Terraform Providers','https://developer.hashicorp.com/terraform/language/providers'),
'terraform_state':('HashiCorp Developer — Terraform State','https://developer.hashicorp.com/terraform/language/state'),
'prom':('Prometheus Documentation — Overview','https://prometheus.io/docs/introduction/overview/'),
'otel':('OpenTelemetry Documentation — Observability Primer','https://opentelemetry.io/docs/concepts/observability-primer/'),
'intel_sdm':('Intel — 64 and IA-32 Architectures Software Developer Manuals','https://www.intel.com/content/www/us/en/developer/articles/technical/intel-sdm.html'),
'intel_opt':('Intel — 64 and IA-32 Architectures Optimization Reference Manual','https://www.intel.com/content/www/us/en/developer/articles/technical/intel64-and-ia32-architectures-optimization.html'),
'riscv':('RISC-V International — Ratified Specifications Library','https://docs.riscv.org/'),
'openmp':('OpenMP — Specifications','https://www.openmp.org/specifications/'),
'mpi':('MPI Forum — MPI 4.1 Standard','https://www.mpi-forum.org/docs/mpi-4.1/mpi41-report/mpi41-report.htm'),
'slurm':('SchedMD — Slurm Workload Manager Overview','https://slurm.schedmd.com/overview.html'),
'cuda':('NVIDIA — CUDA Programming Guide','https://docs.nvidia.com/cuda/cuda-programming-guide/'),
'cuda_um':('NVIDIA — CUDA Unified Memory','https://docs.nvidia.com/cuda/cuda-programming-guide/04-special-topics/unified-memory.html'),
'raft':('USENIX ATC 2014 — In Search of an Understandable Consensus Algorithm (Raft)','https://www.usenix.org/conference/atc14/technical-sessions/presentation/ongaro'),
'lamport':('Leslie Lamport — Time, Clocks, and the Ordering of Events in a Distributed System','https://lamport.azurewebsites.net/pubs/time-clocks.pdf'),
'ibm_q':('IBM Quantum Learning','https://quantum.cloud.ibm.com/learning'),
'ibm_gates':('IBM Quantum Learning — Bits, Gates, and Circuits','https://quantum.cloud.ibm.com/learning/en/courses/utility-scale-quantum-computing/bits-gates-and-circuits'),
'nist_csf':('NIST Cybersecurity Framework 2.0','https://www.nist.gov/cyberframework'),
'nist_63b':('NIST SP 800-63B — Authentication and Authenticator Management','https://pages.nist.gov/800-63-4/sp800-63b.html'),
'nist_207':('NIST SP 800-207 — Zero Trust Architecture','https://csrc.nist.gov/pubs/sp/800/207/final'),
'nist_61':('NIST SP 800-61 Rev. 3 — Incident Response Recommendations and Considerations','https://csrc.nist.gov/pubs/sp/800/61/r3/final'),
'nist_53':('NIST SP 800-53 Rev. 5 — Security and Privacy Controls','https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final'),
'cisa_ransom':('CISA — #StopRansomware Guide','https://www.cisa.gov/stopransomware/ransomware-guide'),
'owasp_authz':('OWASP Cheat Sheet — Authorization','https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html'),
'owasp_sql':('OWASP Cheat Sheet — SQL Injection Prevention','https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html'),
'owasp_xss':('OWASP Cheat Sheet — Cross Site Scripting Prevention','https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html'),
'owasp_ssrf':('OWASP Cheat Sheet — SSRF Prevention','https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html'),
'owasp_session':('OWASP Cheat Sheet — Session Management','https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html'),
'owasp_secrets':('OWASP Cheat Sheet — Secrets Management','https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html'),
'owasp_threat':('OWASP Cheat Sheet — Threat Modeling','https://cheatsheetseries.owasp.org/cheatsheets/Threat_Modeling_Cheat_Sheet.html'),
'sre_slo':('Google SRE Book — Service Level Objectives','https://sre.google/sre-book/service-level-objectives/'),
'sre_monitor':('Google SRE Book — Monitoring Distributed Systems','https://sre.google/sre-book/monitoring-distributed-systems/'),
'sre_toil':('Google SRE Book — Eliminating Toil','https://sre.google/sre-book/eliminating-toil/'),
'sre_post':('Google SRE Book — Postmortem Culture','https://sre.google/sre-book/postmortem-culture/'),
'sre_incident':('Google SRE Workbook — Incident Response','https://sre.google/workbook/incident-response/'),
'sre_cascade':('Google SRE Book — Addressing Cascading Failures','https://sre.google/sre-book/addressing-cascading-failures/'),
'sre_overload':('Google SRE Book — Handling Overload','https://sre.google/sre-book/handling-overload/'),
'nist_dr':('NIST SP 800-34 Rev. 1 — Contingency Planning Guide','https://csrc.nist.gov/pubs/sp/800/34/r1/final'),
'openstax_alg':('OpenStax — College Algebra 2e','https://openstax.org/details/books/college-algebra-2e'),
'openstax_calc':('OpenStax — Calculus Volume 1','https://openstax.org/details/books/calculus-volume-1'),
'openstax_stats':('OpenStax — Introductory Statistics','https://openstax.org/details/books/introductory-statistics'),
'mit_la':('MIT OpenCourseWare — Linear Algebra','https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/'),
'nist_dlmf':('NIST Digital Library of Mathematical Functions','https://dlmf.nist.gov/'),
'phys1':('OpenStax — University Physics Volume 1','https://openstax.org/details/books/university-physics-volume-1'),
'phys2':('OpenStax — University Physics Volume 2','https://openstax.org/details/books/university-physics-volume-2'),
'phys3':('OpenStax — University Physics Volume 3','https://openstax.org/details/books/university-physics-volume-3'),
}

def slug(s): return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')
def refs(keys): return [list(SRC[k]) for k in keys]
existing_titles={x['title'].lower() for x in D['lessons']}; ids={x['id'] for x in D['lessons']}; new=[]
def add(domain,category,title,fact,keys,diff='Foundation',kind='Quick Concept',interactive=None,minutes=None,version=False,why=None,example=None):
    if title.lower() in existing_titles: raise ValueError('duplicate title '+title)
    lid=f'{domain}-v06-{slug(title)[:74]}'
    if lid in ids: raise ValueError('duplicate id '+lid)
    minutes=minutes or (10 if kind=='Lab' else 6)
    why=why or f'Understanding {title.lower()} helps you predict behavior, troubleshoot failures, and connect the concept to neighboring layers.'
    example=example or f'Use the evidence link to verify the definition of {title.lower()}, then identify one place the concept appears in a real system or problem.'
    l={'id':lid,'domain':domain,'category':category,'title':title,'summary':fact,
       'explanation':fact+'\n\nThis object is deliberately scoped to behavior that is directly supported by the linked primary standard, official documentation, or academic textbook. The Evidence view lets you verify the claim yourself.',
       'why':why,'example':example,'takeaway':fact,'difficulty':diff,'kind':kind,'minutes':minutes,
       'tags':[x for x in re.findall(r'[a-z0-9+#.-]+',title.lower()) if len(x)>2][:7], 'interactive':interactive,'prereq':[],'related':[],
       'quiz':{'q':f'Which statement about {title} is supported by the cited source?','options':[fact,'The concept has no defined behavior and is only an informal label.'],'answer':0,'explanation':fact},
       'misconception':None,'objectives':[f'Explain {title.lower()} using source-defined terminology','Recognize the concept in a practical example'],'references':refs(keys),
       'verification':{'status':'verified','reviewed':REVIEW,'method':'Cross-checked against the cited primary standard, official documentation, or academic text.','claimType':'Documented technical or mathematical concept','sourceCount':len(keys)},'versionSensitive':version}
    D['lessons'].append(l); ids.add(lid); existing_titles.add(title.lower()); new.append(lid); return lid

# 26 per domain = 182 new objects. Three labs per domain.
cloud=[
('Networking','UDP: Datagram Transport','UDP provides connectionless datagram delivery and includes source port, destination port, length, and checksum fields in its header.',['rfc768'],'Foundation'),
('Networking','Private IPv4 Address Space','RFC 1918 reserves 10/8, 172.16/12, and 192.168/16 for private internets; these blocks are not globally unique Internet address space.',['rfc1918'],'Foundation'),
('Networking','IPv6 Router Advertisements','IPv6 routers use Router Advertisement messages to advertise their presence together with link and prefix information used by hosts for router and prefix discovery.',['rfc4861'],'Intermediate'),
('Networking','Documentation IPv4 Networks','RFC 5737 reserves 192.0.2.0/24, 198.51.100.0/24, and 203.0.113.0/24 for documentation and examples.',['rfc5737'],'Foundation'),
('Networking','VXLAN Network Identifier','VXLAN carries a 24-bit VXLAN Network Identifier (VNI) that identifies the individual Layer-2 overlay segment within the VXLAN encapsulation.',['rfc7348'],'Intermediate'),
('Networking','SSH Protocol Architecture','SSH defines transport, user-authentication, and connection protocols that together provide secure remote login and other secure network services.',['rfc4251'],'Intermediate'),
('Identity','Kerberos Key Distribution Center','Kerberos relies on a trusted Key Distribution Center that provides Authentication Service and Ticket-Granting Service functions for issuing credentials used by clients and application services.',['rfc4120'],'Intermediate'),
('Identity','LDAP Operations','LDAP defines directory operations such as bind, search, compare, add, delete, modify, and modify DN over a client-server protocol.',['rfc4511'],'Intermediate'),
('Linux','Linux Network Namespace Isolation','A Linux network namespace provides an isolated instance of networking resources such as network devices, protocol stacks, routing tables, firewall rules, and related network state.',['kernel_ns'],'Intermediate'),
('Linux','Control Groups v2','Linux cgroup v2 organizes processes hierarchically and exposes controllers that can account for or control resources such as CPU, memory, and I/O.',['kernel_cgroup'],'Intermediate'),
('Linux','Bash Pipeline Exit Status','By default Bash reports a pipeline using the exit status of the last command, while the pipefail option changes failure propagation so a nonzero status from an earlier command can affect the pipeline result.',['bash'],'Intermediate'),
('Automation','PowerShell Object Pipeline','PowerShell pipelines pass .NET objects between commands rather than restricting pipeline data to plain text.',['ps'],'Foundation'),
('Linux','systemd Unit Model','systemd manages resources through units; service units describe processes controlled and supervised as services.',['systemd'],'Foundation'),
('Kubernetes','Kubernetes Namespace Scope','Names of namespaced Kubernetes resources need only be unique within their namespace, while cluster-scoped resources are not contained in a namespace.',['k8s_ns'],'Foundation'),
('Kubernetes','Kubernetes Service Abstraction','A Kubernetes Service exposes a logical set of backend endpoints behind a stable service abstraction even as individual Pods change.',['k8s_service'],'Foundation'),
('Kubernetes','Kubernetes DNS Discovery','Kubernetes DNS creates records that let workloads discover Services and, in defined cases, Pods by DNS name.',['k8s_dns'],'Intermediate'),
('Kubernetes','Kubernetes ServiceAccount Namespace Scope','ServiceAccount objects are namespaced identities, so ServiceAccounts with the same name in different namespaces are distinct Kubernetes API objects.',['k8s_sa'],'Intermediate'),
('Kubernetes','Required vs Preferred Node Affinity','Kubernetes node affinity distinguishes required rules that must be satisfied for scheduling from preferred rules that influence node scoring without being mandatory.',['k8s_affinity'],'Intermediate'),
('Lab','Lab: Kubernetes Resource Scheduling','The Kubernetes scheduler uses Pod resource requests when determining whether a node has sufficient available resources for placement; limits serve a different enforcement role.',['k8s_resource','k8s_sched'],'Intermediate'),
('Cloud','AWS Route Tables','An Amazon VPC route table contains routes that determine where network traffic from associated subnets or gateways is directed.',['aws_routes'],'Intermediate'),
('Cloud','AWS Network ACL Rule Ordering','Amazon VPC network ACL rules are evaluated in ascending rule-number order, and evaluation stops at the first rule that matches the traffic.',['aws_nacl'],'Intermediate'),
('Cloud','Azure Virtual Networks','Azure Virtual Network provides private IP networking for Azure resources and supports subnetting, routing, filtering, and connectivity patterns.',['azure_vnet'],'Foundation'),
('Cloud','Azure Availability Zones','Azure availability zones are physically separate groups of datacenters within a region with independent power, cooling, and networking.',['azure_avail'],'Intermediate'),
('Observability','OpenTelemetry Traces, Metrics, and Logs','OpenTelemetry defines telemetry signals including traces, metrics, and logs so instrumented systems can produce interoperable observability data.',['otel'],'Foundation'),
('Lab','Lab: Learn a Switch MAC Table','An Ethernet switch learns source MAC addresses on ingress ports and uses its forwarding information to choose an egress port for known unicast destinations; unknown destinations may be flooded within the relevant Layer-2 domain.',['redhat'] if 'redhat' in SRC else ['rfc7348'],'Intermediate'),
('Lab','Lab: Schedule a Kubernetes Pod','The Kubernetes scheduler filters nodes that do not meet a Pod’s requirements, scores feasible nodes, and selects a node for binding.',['k8s_sched'],'Intermediate'),
]
# Replace source for switch lab with official Kubernetes? use Red Hat docs not in bank; add a safe vendor-independent Linux bridge doc source dynamically.
SRC['kernel_bridge']=('Linux Kernel Documentation — Ethernet Bridging','https://docs.kernel.org/networking/bridge.html')
cloud[-2]=('Lab','Lab: Learn a Switch MAC Table','A Linux Ethernet bridge forwards frames between ports and maintains a forwarding database of MAC addresses used for Layer-2 forwarding decisions.',['kernel_bridge'],'Intermediate')

advanced=[
('Architecture','RISC-V Standard Extensions','RISC-V defines a base instruction set plus standardized extensions, allowing implementations to select architectural capabilities while preserving specified encodings and behavior.',['riscv'],'Foundation'),
('Architecture','Processor Privilege and Traps','Privileged processor architectures define mechanisms for traps and privilege transitions so operating systems and firmware can handle exceptions, interrupts, and protected operations.',['riscv'],'Intermediate'),
('Architecture','SIMD Data Parallelism','SIMD instructions perform the same operation on multiple packed data elements, providing data-level parallelism when a workload can be vectorized.',['intel_sdm'],'Intermediate'),
('Architecture','Branch Prediction Purpose','Branch prediction allows a processor to speculate about control flow so instruction fetching and execution can continue before a branch outcome is fully known.',['intel_opt'],'Advanced'),
('Architecture','In-Order Retirement','Out-of-order processors can execute work speculatively yet retire instructions in program order so architectural state remains precise.',['intel_sdm'],'Advanced'),
('Memory','Translation Lookaside Buffers','A translation lookaside buffer caches address-translation information so many virtual-address translations can avoid a full page-table walk.',['intel_sdm'],'Advanced'),
('Memory','Memory Ordering Fences','Memory-fence instructions constrain the ordering or visibility of memory operations according to architecture-defined memory-ordering rules.',['intel_sdm'],'Advanced'),
('Memory','False Sharing','False sharing can occur when independent data used by different processors resides on the same cache line, causing coherence traffic even though the logical variables are distinct.',['intel_opt'],'Advanced'),
('Parallel Computing','OpenMP Barrier Synchronization','An OpenMP barrier is a synchronization point where participating threads wait until the required team reaches the barrier.',['openmp'],'Intermediate'),
('Parallel Computing','OpenMP Reduction','OpenMP reduction constructs create private partial values and combine them with a specified operation into a shared result.',['openmp'],'Intermediate'),
('Parallel Computing','OpenMP Tasks','OpenMP task constructs describe units of work that can be scheduled by the runtime subject to synchronization and dependency rules.',['openmp'],'Advanced'),
('Lab','Lab: Match MPI Messages by Tag','MPI point-to-point messages are matched using communication context together with source, destination, and message-tag information defined by the MPI communication operation.',['mpi'],'Intermediate'),
('HPC','MPI Collective Operations','MPI collective operations coordinate communication across all processes in a communicator for patterns such as broadcast, reduction, gather, scatter, and all-to-all exchange.',['mpi'],'Intermediate'),
('HPC','MPI Request Completion','Nonblocking MPI operations return request handles whose completion can be established using operations such as MPI_Wait or MPI_Test.',['mpi'],'Intermediate'),
('HPC','MPI Message Tags','MPI message tags are integer values carried in point-to-point communication and participate in receive matching, allowing applications to distinguish classes of messages within a communicator.',['mpi'],'Intermediate'),
('HPC','Slurm Partitions','Slurm partitions group nodes into logical sets and act as queues to which jobs can be submitted subject to configured limits and policies.',['slurm'],'Intermediate'),
('HPC','Slurm Job Allocation','Slurm allocates cluster resources to jobs and job steps according to requested resources and scheduler policy.',['slurm'],'Foundation'),
('GPU','CUDA Grids and Blocks','CUDA organizes kernel execution as a grid of thread blocks; blocks contain threads and can be scheduled independently on streaming multiprocessors.',['cuda'],'Foundation'),
('GPU','CUDA Warp Execution','CUDA threads are grouped into warps for execution; threads in a warp execute instructions together, and divergent control flow can serialize different paths.',['cuda'],'Intermediate'),
('GPU','CUDA Memory Coalescing','CUDA global-memory performance depends on how a warp’s memory accesses are combined into memory transactions, so suitably aligned and contiguous access patterns can improve efficiency.',['cuda'],'Advanced'),
('Lab','Lab: CUDA Block Synchronization','CUDA __syncthreads() acts as a barrier for threads in a block and is used when block threads must coordinate shared-memory or phase-dependent work.',['cuda'],'Advanced'),
('GPU','CUDA Managed-Memory Migration','CUDA managed memory can migrate between processors as the runtime and hardware manage access, placement, and coherence according to platform capabilities and program behavior.',['cuda_um'],'Advanced'),
('Distributed Systems','Raft Leader Election','Raft elects a leader using terms and majority voting; servers transition among follower, candidate, and leader roles according to the protocol.',['raft'],'Intermediate'),
('Distributed Systems','Raft Log Replication','In Raft, the leader accepts client commands as log entries and replicates them to followers before committed entries are applied to the state machine.',['raft'],'Advanced'),
('Distributed Systems','Lamport Logical Clocks','Lamport logical clocks assign scalar timestamps so if one event causally happens before another, the first event receives a smaller logical timestamp.',['lamport'],'Advanced'),
('Lab','Lab: Explore Quorum Size','In a majority quorum system, any two majorities of the same fixed membership overlap, which is a key property used by consensus protocols such as Raft.',['raft'],'Advanced'),
]
software=[
('Programming','Python Mutable and Immutable Types','Python built-in types differ in mutability: for example, lists are mutable sequences while tuples are immutable sequences.',['python_types'],'Foundation'),
('Programming','Python Dictionaries','Python dictionaries map hashable keys to values and preserve insertion order as part of the language behavior in current Python versions.',['python_types'],'Foundation'),
('Programming','Python Sets','Python sets are unordered collections of distinct hashable objects and support mathematical set-style operations such as union and intersection.',['python_types'],'Foundation'),
('Programming','Python Exceptions','Python exceptions signal errors or other exceptional conditions and propagate until handled by a matching exception handler or terminate the current execution context.',['python_exc'],'Foundation'),
('Programming','Python Context Managers','Python context managers define setup and cleanup behavior used by the with statement, commonly to guarantee resource-release logic.',['python_types'],'Intermediate'),
('Programming','Python Iterators','Python iterators implement an iteration protocol that produces successive values until StopIteration signals exhaustion.',['python_types'],'Intermediate'),
('Programming','Python Coroutines','asyncio coroutines are awaitable computations used to express cooperative asynchronous workflows.',['python_asyncio'],'Intermediate'),
('Programming','asyncio Tasks','An asyncio Task schedules a coroutine for execution by an event loop and represents its eventual result or exception.',['python_asyncio'],'Intermediate'),
('DevOps','Git Commits','A Git commit records a snapshot reference plus metadata and parent relationships, forming history as a graph of commit objects.',['git'],'Foundation'),
('DevOps','Git Branches','A Git branch is a movable name that points to a commit and advances as new commits are created on that branch.',['git'],'Foundation'),
('DevOps','Git Merge','Git merge combines development histories and can create a merge commit when histories cannot be resolved as a fast-forward.',['git'],'Intermediate'),
('DevOps','Git Rebase','Git rebase reapplies commits onto a new base, creating new commit objects for the rebased history.',['git'],'Intermediate'),
('APIs','HTTP GET Semantics','HTTP GET requests transfer a current representation of a target resource and are defined as safe and idempotent semantics.',['rfc9110'],'Foundation'),
('APIs','HTTP PUT Semantics','HTTP PUT requests create or replace the state of the target resource with the state defined by the request content and are idempotent.',['rfc9110'],'Intermediate'),
('APIs','HTTP DELETE Semantics','HTTP DELETE requests ask the origin server to remove the association between the target resource and its current functionality; DELETE is defined as idempotent.',['rfc9110'],'Intermediate'),
('APIs','HTTP Status-Code Classes','HTTP status codes are grouped by first digit into informational 1xx, successful 2xx, redirection 3xx, client error 4xx, and server error 5xx classes.',['rfc9110'],'Foundation'),
('APIs','HTTP Cache Freshness','HTTP caching defines freshness and validation mechanisms that let caches reuse stored responses when protocol conditions allow.',['rfc9111'],'Intermediate'),
('APIs','HTTP HEAD Semantics','HTTP HEAD is identical in semantics to GET except the server must not send message content in the response, making it useful for retrieving representation metadata.',['rfc9110'],'Foundation'),
('Databases','PostgreSQL MVCC','PostgreSQL uses multiversion concurrency control so statements operate on database snapshots while concurrent transactions can progress with defined isolation behavior.',['pg_mvcc'],'Intermediate'),
('Databases','PostgreSQL Indexes','PostgreSQL indexes provide auxiliary access structures that can let the database locate rows without scanning every table row, at the cost of storage and write-maintenance overhead.',['pg_index'],'Foundation'),
('Databases','PostgreSQL EXPLAIN','PostgreSQL EXPLAIN displays the execution plan chosen by the query planner, including scan and join strategies and estimated costs.',['pg_explain'],'Intermediate'),
('Databases','SQL Query Tables and Joins','A SQL query can combine rows from multiple table references using join operations whose conditions determine which row combinations appear in the result.',['pg_queries'],'Foundation'),
('Databases','Transaction Isolation','PostgreSQL exposes SQL transaction isolation levels that define which effects of concurrent transactions can be observed.',['pg_mvcc'],'Intermediate'),
('Lab','Lab: Visualize SQL Joins','Join operations combine rows from two input relations according to a join condition; inner and outer joins differ in whether unmatched rows are preserved.',['pg_queries'],'Foundation'),
('Lab','Lab: Read a PostgreSQL Query Plan','EXPLAIN can reveal whether PostgreSQL plans a sequential scan, index scan, and particular join methods for a statement.',['pg_explain'],'Intermediate'),
('Lab','Lab: Test HTTP Idempotence','HTTP defines GET, PUT, and DELETE as idempotent methods, meaning multiple identical requests have the same intended effect as one such request, although responses can still differ.',['rfc9110'],'Intermediate'),
]
cyber=[
('Identity','Least Privilege','The least-privilege control principle limits users and processes to the authorizations necessary to perform assigned tasks.',['nist_53'],'Foundation'),
('Identity','Authenticator Assurance Levels','NIST defines Authenticator Assurance Levels AAL1, AAL2, and AAL3 to represent increasing confidence in the authentication process and authenticator requirements.',['nist_63b'],'Intermediate'),
('Identity','Replay-Resistant Authentication','NIST describes replay resistance as preventing successful authentication by recording and replaying a previous authentication message or exchange.',['nist_63b'],'Intermediate'),
('Identity','Password Blocklists','NIST password guidance requires verifiers to compare new passwords against a blocklist containing values known to be commonly used, expected, or compromised.',['nist_63b'],'Intermediate'),
('Application Security','Session Identifiers','Secure session management requires session identifiers to be unpredictable, protected in transit and storage, and invalidated according to application lifecycle rules.',['owasp_session'],'Intermediate'),
('Application Security','Authorization Deny by Default','OWASP recommends denying access by default and granting access only when authorization rules explicitly permit the request.',['owasp_authz'],'Foundation'),
('Application Security','Object-Level Authorization','Applications must verify authorization for each requested object rather than relying on object identifiers being difficult to guess.',['owasp_authz'],'Intermediate'),
('Application Security','Parameterized SQL Queries','Parameterized queries separate SQL code from data values and are a primary defense against SQL injection.',['owasp_sql'],'Foundation'),
('Application Security','Contextual Output Encoding','XSS prevention requires output encoding appropriate to the HTML, attribute, JavaScript, CSS, or URL context where untrusted data is inserted.',['owasp_xss'],'Intermediate'),
('Application Security','SSRF Allowlisting','SSRF defenses can constrain server-side outbound requests by validating destinations and, where practical, allowlisting approved hosts, networks, or protocols.',['owasp_ssrf'],'Advanced'),
('Identity','OAuth Authorization Code','OAuth 2.0 authorization code flow uses an authorization code returned through the user agent and exchanged by the client for an access token.',['rfc6749'],'Intermediate'),
('Identity','OAuth PKCE','PKCE binds an authorization request to a later token request using a code verifier and derived code challenge, mitigating authorization-code interception attacks.',['rfc7636'],'Advanced'),
('Architecture','Zero Trust Per-Session Decisions','Zero Trust Architecture removes implicit trust based solely on network location and bases access decisions on policy and available subject, device, resource, and environmental signals.',['nist_207'],'Intermediate'),
('Network Security','TLS 1.3 Protected Application Data','TLS 1.3 negotiates cryptographic keys during the handshake and protects subsequent application data with authenticated encryption.',['rfc8446'],'Intermediate'),
('Detection','Incident Response Preparation','NIST incident-response guidance treats preparation and governance as essential capabilities that support effective detection, response, and recovery.',['nist_61'],'Foundation'),
('Detection','Incident Triage','Incident triage evaluates reported or detected events so responders can determine whether an incident exists and prioritize response actions.',['nist_61'],'Intermediate'),
('Risk','Cybersecurity Asset Inventory','The NIST Cybersecurity Framework includes identifying and managing organizational assets as part of understanding cybersecurity risk.',['nist_csf'],'Foundation'),
('Risk','Vulnerability Management','The NIST Cybersecurity Framework includes vulnerability identification, assessment, and management as risk-reduction activities.',['nist_csf'],'Intermediate'),
('Risk','Ransomware Backup Resilience','CISA recommends maintaining offline, encrypted backups and regularly testing backup availability and integrity as part of ransomware resilience.',['cisa_ransom'],'Foundation'),
('Application Security','Secrets Management Lifecycle','Secrets management includes creation, storage, access control, rotation, revocation, and auditing for sensitive credentials and cryptographic material.',['owasp_secrets'],'Intermediate'),
('Risk','Threat Modeling','Threat modeling is a structured process for identifying what can go wrong in a design and deciding which mitigations are appropriate.',['owasp_threat'],'Foundation'),
('Governance','Cybersecurity Govern Function','NIST CSF 2.0 includes a Govern function focused on establishing and monitoring cybersecurity risk-management strategy, expectations, and policy.',['nist_csf'],'Foundation'),
('Architecture','Security Control Families','NIST SP 800-53 organizes security and privacy controls into families such as Access Control, Audit and Accountability, Configuration Management, and Incident Response.',['nist_53'],'Intermediate'),
('Lab','Lab: Build a Risk Matrix','A risk matrix is a prioritization aid that combines defined likelihood and impact categories; the categories and thresholds must be established by the organization rather than treated as universal constants.',['nist_csf'],'Foundation'),
('Lab','Lab: Trace an OAuth Code Exchange','OAuth authorization-code flow separates the front-channel authorization response from the back-channel token exchange.',['rfc6749','rfc7636'],'Intermediate'),
('Lab','Lab: Make an Authorization Decision','A robust authorization check evaluates the authenticated subject, requested action, target resource, and applicable policy before granting access.',['owasp_authz','nist_207'],'Intermediate'),
]
leadership=[
('Reliability','Service Level Indicator','An SLI is a quantitative measure of a defined aspect of service behavior, such as successful request ratio or latency.',['sre_slo'],'Foundation'),
('Reliability','Service Level Objective','An SLO is a target value or range for an SLI over a defined period and expresses a reliability objective for the service.',['sre_slo'],'Foundation'),
('Reliability','Error Budget','An error budget is the amount of unreliability permitted by an SLO and can be used to balance reliability work with change velocity.',['sre_slo'],'Intermediate'),
('Operations','The Four Golden Signals','Google SRE identifies latency, traffic, errors, and saturation as four particularly useful signals for monitoring user-facing systems.',['sre_monitor'],'Foundation'),
('Operations','Symptom-Based Alerting','SRE monitoring guidance favors alerts tied to user-visible symptoms and actionable conditions rather than every internal metric change.',['sre_monitor'],'Intermediate'),
('Operations','Toil','Google SRE defines toil as manual, repetitive, automatable, tactical work with no enduring value that scales linearly as a service grows.',['sre_toil'],'Foundation'),
('Operations','Toil Reduction','Reducing toil means automating, eliminating, or redesigning repetitive operational work so engineering time can shift toward durable improvements.',['sre_toil'],'Intermediate'),
('Incidents','Incident Command','Structured incident response assigns clear roles and coordination responsibilities so technical work, communication, and decision-making can proceed in parallel.',['sre_incident'],'Intermediate'),
('Incidents','Incident Timeline','A factual incident timeline records important events, observations, actions, and decisions in chronological order to support coordination and later analysis.',['sre_post'],'Foundation'),
('Incidents','Blameless Postmortems','A blameless postmortem focuses on how systems and conditions produced an outcome rather than using the review to punish individuals for reasonable actions.',['sre_post'],'Foundation'),
('Incidents','Postmortem Action Items','Effective postmortems identify concrete follow-up actions that reduce recurrence or improve detection, mitigation, and response.',['sre_post'],'Intermediate'),
('Reliability','Cascading Failure','A cascading failure occurs when a failure or overload in one component increases stress on other components and propagates through the system.',['sre_cascade'],'Advanced'),
('Reliability','Graceful Degradation','Graceful degradation preserves a reduced but useful level of service when dependencies or capacity are impaired instead of failing every feature together.',['sre_cascade'],'Intermediate'),
('Capacity','Load Shedding','Load shedding deliberately rejects or de-prioritizes excess work when accepting it would threaten the health of the system.',['sre_overload'],'Intermediate'),
('Capacity','Queue Growth Under Overload','When incoming work persistently exceeds service capacity, queues and latency grow unless the system limits, sheds, or reduces work.',['sre_overload'],'Intermediate'),
('Operations','On-Call Readiness','An on-call system needs actionable alerts, clear escalation paths, access to operational context, and the authority to mitigate incidents.',['sre_incident'],'Intermediate'),
('Operations','Runbook Purpose','A runbook captures repeatable operational procedures and decision guidance so responders can execute known actions consistently.',['sre_incident'],'Foundation'),
('Reliability','Reliability Target Tradeoffs','Setting an SLO requires choosing a target that reflects user needs and business constraints rather than assuming maximum possible availability is always optimal.',['sre_slo'],'Intermediate'),
('Strategy','Reliability as a Product Property','Reliability objectives are most useful when they describe observable service behavior that matters to users, not internal component health alone.',['sre_slo'],'Foundation'),
('Recovery','Recovery Time Objective','A recovery time objective defines the maximum targeted duration for restoring a system or service after disruption.',['nist_dr'],'Foundation'),
('Recovery','Recovery Point Objective','A recovery point objective defines the targeted point in time to which data should be recovered after a disruption, expressing tolerated data loss.',['nist_dr'],'Foundation'),
('Recovery','Contingency Plan Testing','NIST contingency planning guidance calls for exercising and testing recovery plans so organizations can validate procedures and identify gaps before a real disruption.',['nist_dr'],'Intermediate'),
('Governance','Incident Response Governance','NIST incident-response guidance emphasizes integrating incident response into broader cybersecurity risk management and organizational governance.',['nist_61'],'Intermediate'),
('Lab','Lab: Spend an Error Budget','An SLO defines an allowed amount of unreliability over its measurement window; consuming that allowance faster than planned is a signal to reconsider risk and change.',['sre_slo'],'Intermediate'),
('Lab','Lab: Reconstruct an Incident Timeline','A postmortem timeline should distinguish observed facts, actions, and system behavior so the sequence can be analyzed without relying on memory alone.',['sre_post'],'Foundation'),
('Lab','Lab: Identify and Reduce Toil','Toil reduction begins by identifying repetitive, manual, automatable work and then measuring whether changes actually reduce the recurring operational burden.',['sre_toil'],'Foundation'),
]
math=[
('Algebra','Function Domain and Range','The domain of a function is the set of allowed inputs; the range is the set of outputs produced by those inputs.',['openstax_alg'],'Foundation'),
('Algebra','Exponential Functions','An exponential function has the variable in the exponent; for a positive base other than 1, repeated equal input steps multiply outputs by a constant factor.',['openstax_alg'],'Foundation'),
('Algebra','Logarithms as Inverses','A logarithm answers which exponent produces a given positive value for a chosen positive base not equal to 1, making logarithms inverse functions of exponentials.',['openstax_alg'],'Foundation'),
('Trigonometry','Radians','Radian measure defines an angle as arc length divided by radius, so a full revolution measures 2π radians.',['openstax_alg'],'Foundation'),
('Trigonometry','Unit Circle Coordinates','On the unit circle, the point at angle θ has coordinates (cos θ, sin θ).',['openstax_alg'],'Foundation'),
('Sequences','Arithmetic Sequences','An arithmetic sequence has a constant difference between consecutive terms.',['openstax_alg'],'Foundation'),
('Sequences','Geometric Sequences','A geometric sequence has a constant ratio between consecutive nonzero terms.',['openstax_alg'],'Foundation'),
('Calculus','Limit Laws','Limit laws allow limits of sums, products, quotients, powers, and other combinations to be computed from component limits when the stated conditions hold.',['openstax_calc'],'Foundation'),
('Calculus','Continuity at a Point','A function is continuous at a point when the function value is defined, the limit exists, and the limit equals the function value.',['openstax_calc'],'Foundation'),
('Calculus','Product Rule','The derivative of a product satisfies (fg)′ = f′g + fg′.',['openstax_calc'],'Foundation'),
('Calculus','Quotient Rule','For g(x) not equal to zero, the derivative of f/g is (f′g − fg′)/g².',['openstax_calc'],'Foundation'),
('Calculus','Chain Rule','The chain rule differentiates a composition by multiplying the derivative of the outer function evaluated at the inner function by the derivative of the inner function.',['openstax_calc'],'Intermediate'),
('Calculus','Implicit Differentiation','Implicit differentiation differentiates both sides of a relation with respect to the independent variable and applies the chain rule to dependent-variable terms.',['openstax_calc'],'Intermediate'),
('Calculus','Definite Integrals','A definite integral represents the signed accumulation of a quantity over an interval and can be defined as a limit of Riemann sums.',['openstax_calc'],'Foundation'),
('Calculus','Fundamental Theorem of Calculus','The Fundamental Theorem of Calculus connects accumulation by definite integrals with antiderivatives, allowing definite integrals to be evaluated from an antiderivative.',['openstax_calc'],'Intermediate'),
('Calculus','u-Substitution','Substitution rewrites an integral using a change of variable and is the integration counterpart of the chain rule for suitable integrands.',['openstax_calc'],'Intermediate'),
('Linear Algebra','Vector Addition','Vector addition combines vectors component by component and geometrically corresponds to placing one vector head-to-tail with another.',['mit_la'],'Foundation'),
('Linear Algebra','Matrix Transpose','The transpose of a matrix interchanges rows and columns, so the entry in row i and column j becomes the entry in row j and column i.',['mit_la'],'Foundation'),
('Linear Algebra','Matrix Multiplication','Matrix multiplication forms each output entry from a row of the left matrix and a column of the right matrix, so the inner dimensions must match.',['mit_la'],'Foundation'),
('Linear Algebra','Determinants','The determinant is a scalar associated with a square matrix and indicates, among other properties, whether the matrix is invertible: a zero determinant means it is singular.',['mit_la'],'Intermediate'),
('Lab','Lab: Test Linear Independence','A set of vectors is linearly independent when the only linear combination that equals the zero vector uses zero coefficients for every vector.',['mit_la'],'Intermediate'),
('Linear Algebra','Orthogonal Vectors','Two real vectors are orthogonal when their dot product is zero.',['mit_la'],'Foundation'),
('Probability','Expected Value','The expected value of a discrete random variable is the probability-weighted sum of its possible values when the sum is defined.',['openstax_stats'],'Foundation'),
('Probability','Variance','Variance measures expected squared deviation from a random variable’s mean and is nonnegative.',['openstax_stats'],'Intermediate'),
('Lab','Lab: Approximate an Integral','A Riemann-sum approximation partitions an interval and adds rectangle areas; refining the partition can approximate the definite integral when the function is integrable.',['openstax_calc'],'Foundation'),
('Lab','Lab: Explore Dot-Product Geometry','For nonzero real vectors, the dot product equals the product of their magnitudes times the cosine of the angle between them.',['mit_la'],'Intermediate'),
]
physics=[
('Mechanics','Displacement, Velocity, and Acceleration','Velocity is the time rate of change of position, and acceleration is the time rate of change of velocity.',['phys1'],'Foundation'),
('Mechanics','Constant-Acceleration Kinematics','For constant acceleration, position and velocity obey kinematic equations derived by integrating the constant acceleration over time.',['phys1'],'Foundation'),
('Mechanics','Newton’s First Law','An object remains at rest or in uniform straight-line motion unless acted on by a net external force.',['phys1'],'Foundation'),
('Mechanics','Newton’s Third Law','When two objects interact, the force of the first object on the second and the force of the second on the first are equal in magnitude and opposite in direction.',['phys1'],'Foundation'),
('Mechanics','Friction Forces','Friction acts parallel to a contact surface and opposes relative motion or the tendency for relative motion according to the applicable static or kinetic model.',['phys1'],'Foundation'),
('Energy','Work by a Force','Mechanical work is the integral of force along displacement; for a constant force it reduces to the dot product of force and displacement.',['phys1'],'Foundation'),
('Energy','Kinetic Energy','For a nonrelativistic particle of mass m and speed v, translational kinetic energy is one half m v squared.',['phys1'],'Foundation'),
('Energy','Potential Energy','Potential energy represents energy associated with position or configuration for conservative interactions and changes oppositely to the work done by the corresponding conservative force.',['phys1'],'Intermediate'),
('Momentum','Linear Momentum','Linear momentum is the vector product p = mv for a particle in classical mechanics.',['phys1'],'Foundation'),
('Momentum','Impulse-Momentum Theorem','Impulse, the time integral of net force, equals the change in linear momentum.',['phys1'],'Foundation'),
('Rotation','Torque','Torque measures the rotational effect of a force and is given by the cross product of the position vector from the axis or origin with the force.',['phys1'],'Intermediate'),
('Lab','Lab: Centripetal Acceleration','For uniform circular motion of radius r and speed v, centripetal acceleration has magnitude v²/r and points toward the center of the circle.',['phys1'],'Foundation'),
('Energy','Conservation of Mechanical Energy','When only conservative forces do work, the sum of kinetic and potential energy remains constant.',['phys1'],'Intermediate'),
('Waves','Traveling Wave Speed','For a periodic traveling wave, wave speed equals wavelength times frequency.',['phys1'],'Foundation'),
('Waves','Wave Superposition','When linear waves overlap, the resulting displacement is the algebraic sum of the individual wave displacements.',['phys1'],'Foundation'),
('Electricity','Electric Potential Difference','Electric potential difference is the change in electric potential energy per unit charge between two points.',['phys2'],'Foundation'),
('Electricity','Capacitance','Capacitance is defined as stored charge magnitude divided by potential difference for a capacitor under its defined geometry and medium.',['phys2'],'Foundation'),
('Electricity','Electric Current','Electric current is the rate at which electric charge passes through a surface.',['phys2'],'Foundation'),
('Electricity','Resistance and Ohm’s Law','For ohmic materials under conditions where resistance is constant, voltage, current, and resistance satisfy V = IR.',['phys2'],'Foundation'),
('Electricity','Kirchhoff Junction Rule','The algebraic sum of currents entering and leaving a circuit junction is zero, expressing conservation of charge.',['phys2'],'Intermediate'),
('Magnetism','Magnetic Force on a Charge','The magnetic force on a charge moving in a magnetic field is q times the cross product of velocity and magnetic field.',['phys2'],'Intermediate'),
('Magnetism','Faraday’s Law','Faraday’s law relates induced electromotive force around a closed loop to the time rate of change of magnetic flux through the loop.',['phys2'],'Intermediate'),
('Modern Physics','Photon Energy','Photon energy is proportional to frequency according to E = hf.',['phys3'],'Foundation'),
('Modern Physics','de Broglie Wavelength','The de Broglie relation associates wavelength λ = h/p with a particle of momentum p.',['phys3'],'Intermediate'),
('Lab','Lab: Build a Series Circuit','In an ideal series circuit the same current passes through each series element, while voltage drops across elements add to the source voltage.',['phys2'],'Foundation'),
('Lab','Lab: Explore Wave Interference','Linear superposition adds overlapping wave displacements, producing constructive or destructive interference depending on relative phase.',['phys1'],'Foundation'),
]

for domain,specs in [('cloud',cloud),('advanced',advanced),('software',software),('cyber',cyber),('leadership',leadership),('math',math),('physics',physics)]:
    assert len(specs)==26,(domain,len(specs))
    for cat,title,fact,keys,diff in specs:
        kind='Lab' if title.startswith('Lab:') else 'Quick Concept'
        interactive=None
        if title=='Lab: Learn a Switch MAC Table': interactive='switchlab'
        elif title=='Lab: Kubernetes Resource Scheduling': interactive='kubescheduler'
        elif title=='Lab: Match MPI Messages by Tag': interactive='mpimessage'
        elif title=='Lab: CUDA Block Synchronization': interactive='warpdiv'
        elif title=='Lab: Test Linear Independence': interactive='matrix'
        elif title=='Lab: Centripetal Acceleration': interactive='force'
        elif title=='Lab: Schedule a Kubernetes Pod': interactive='kubescheduler'
        elif title=='Lab: Explore Quorum Size': interactive='quorum'
        elif title=='Lab: Visualize SQL Joins': interactive='sqljoin'
        elif title=='Lab: Read a PostgreSQL Query Plan': interactive='btree'
        elif title=='Lab: Test HTTP Idempotence': interactive='api'
        elif title=='Lab: Build a Risk Matrix': interactive='riskmatrix'
        elif title=='Lab: Trace an OAuth Code Exchange': interactive='tls'
        elif title=='Lab: Make an Authorization Decision': interactive='rbac'
        elif title=='Lab: Spend an Error Budget': interactive='errorbudget'
        elif title=='Lab: Reconstruct an Incident Timeline': interactive='incident'
        elif title=='Lab: Identify and Reduce Toil': interactive='toilcalc'
        elif title=='Lab: Approximate an Integral': interactive='integral'
        elif title=='Lab: Explore Dot-Product Geometry': interactive='vector'
        elif title=='Lab: Build a Series Circuit': interactive='seriescircuit'
        elif title=='Lab: Explore Wave Interference': interactive='wave'
        # additional interactive quick concepts for richer lab gallery
        elif title in ('Kubernetes Service Abstraction','Kubernetes DNS Discovery'): interactive='kubereconcile' if 'Service' in title else 'dns'
        elif title=='Kubernetes Resource Requests and Limits': interactive='kubescheduler'
        elif title=='UDP: Datagram Transport': interactive='tcp'
        elif title=='Raft Leader Election': interactive='quorum'
        elif title=='MPI Collective Operations': interactive='mpimessage'
        elif title=='CUDA Grids and Blocks': interactive='warpdiv'
        elif title=='HTTP Status-Code Classes': interactive='api'
        elif title=='PostgreSQL Indexes': interactive='btree'
        elif title=='OAuth Authorization Code': interactive='tls'
        elif title=='Service Level Objective': interactive='errorbudget'
        elif title=='Definite Integrals': interactive='integral'
        elif title=='Resistance and Ohm’s Law': interactive='seriescircuit'
        add(domain,cat,title,fact,keys,diff,kind,interactive,version=(domain in ('cloud','software') and any(k.startswith(('k8s','aws','azure','terraform','pg_','python')) for k in keys)))

assert len(new)==182,len(new)
assert len(D['lessons'])==650,len(D['lessons'])
# 57 formal labs expected (36 existing + 21 new)
assert sum(l['kind']=='Lab' for l in D['lessons'])==57
# Add 8 curated paths = 48 total
bytitle={l['title']:l['id'] for l in D['lessons']}
paths=[
('network-protocols-deep','Network Protocols — Deep Core','cloud','Foundation → Intermediate',['UDP: Datagram Transport','Private IPv4 Address Space','IPv6 Neighbor Discovery','VXLAN Overlay Networks','SSH Protocol Architecture']),
('kubernetes-platform-core','Kubernetes Platform Core','cloud','Foundation → Intermediate',['Kubernetes Namespaces','Kubernetes Service Abstraction','Kubernetes DNS Discovery','Kubernetes Service Accounts','Kubernetes Node Affinity','Kubernetes Resource Requests and Limits','Lab: Schedule a Kubernetes Pod']),
('distributed-consensus-core','Distributed Consensus Core','advanced','Intermediate → Advanced',['Lamport Logical Clocks','Raft Leader Election','Raft Log Replication','Lab: Explore Quorum Size']),
('software-runtime-core','Software Runtime Core','software','Foundation → Intermediate',['Python Mutable and Immutable Types','Python Dictionaries','Python Exceptions','Python Iterators','Python Coroutines','asyncio Tasks']),
('web-security-core-v06','Web Security Core','cyber','Foundation → Advanced',['Authorization Deny by Default','Object-Level Authorization','Parameterized SQL Queries','Contextual Output Encoding','SSRF Allowlisting','Lab: Make an Authorization Decision']),
('sre-reliability-core-v06','SRE Reliability Core','leadership','Foundation → Advanced',['Service Level Indicator','Service Level Objective','Error Budget','The Four Golden Signals','Toil','Cascading Failure','Lab: Spend an Error Budget']),
('calculus-bridge-v06','Calculus Bridge II','math','Foundation → Intermediate',['Limit Laws','Continuity at a Point','Product Rule','Quotient Rule','Chain Rule','Definite Integrals','Fundamental Theorem of Calculus','Lab: Approximate an Integral']),
('classical-physics-core-v06','Classical Physics Core','physics','Foundation → Intermediate',['Displacement, Velocity, and Acceleration','Newton’s First Law','Newton’s Third Law','Work by a Force','Linear Momentum','Torque','Simple Harmonic Motion','Wave Superposition'])]
for pid,title,dom,level,titles in paths:
    D['paths'].append({'id':pid,'title':title,'domain':dom,'level':level,'description':'A source-verified sequence that moves from first principles into applied reasoning and hands-on practice.','lesson_ids':[bytitle[t] for t in titles]})
assert len(D['paths'])==48
# Expand glossary to 250 from new clear titles.
G=D['glossary']; terms={g['term'].lower() for g in G}
for l in D['lessons']:
    if len(G)>=250: break
    if l['id'] not in new: continue
    term=l['title'].replace('Lab: ','')
    if term.lower() in terms or len(term)>48: continue
    G.append({'term':term,'definition':l['summary'],'domain':l['domain'],'lesson_id':l['id']}); terms.add(term.lower())
assert len(G)==250,len(G)
# Remove published titles from atlas.
pub={re.sub(r'[^a-z0-9]+',' ',l['title'].lower()).strip() for l in D['lessons']}
for dom,items in D['atlas'].items(): D['atlas'][dom]=[x for x in items if re.sub(r'[^a-z0-9]+',' ',x.lower()).strip() not in pub]
D['version']='0.6.0';D['lastReviewed']=REVIEW
D['verificationPolicy']={'name':'Primary-Source Verification Gate','rule':'A published learning object must cite at least one primary standard, official project/vendor document, government source, peer-reviewed primary paper, or university/open textbook appropriate to the claim.','reviewed':REVIEW,'note':'Version-sensitive material is labeled and should be rechecked against the linked current source before operational use.'}
# validation
lesson_ids={l['id'] for l in D['lessons']}
assert len(lesson_ids)==650
for l in D['lessons']:
    assert l.get('references') and l.get('verification',{}).get('status')=='verified',l['id']
    assert all(len(r)==2 and r[0] and str(r[1]).startswith('https://') for r in l['references']),l['id']
    if l.get('quiz'): assert l['quiz']['answer'] < len(l['quiz']['options'])
for p in D['paths']: assert p['lesson_ids'] and all(x in lesson_ids for x in p['lesson_ids']),p['id']
for g in D['glossary']:
    if g.get('lesson_id'): assert g['lesson_id'] in lesson_ids
# write
(P/'knowledge-data.js').write_text('window.JR_KNOWLEDGE = '+json.dumps(D,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
manifest={'version':'0.6.0','reviewed':REVIEW,'policy':D['verificationPolicy'],'lessons':[{'id':l['id'],'title':l['title'],'domain':l['domain'],'category':l['category'],'versionSensitive':l.get('versionSensitive',False),'references':l['references']} for l in D['lessons']]}
(P/'verification-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
with (ROOT/'VERIFICATION_MANIFEST_v0.6.0.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['lesson_id','domain','category','title','kind','verification_status','reviewed','version_sensitive','source_count','sources'])
    for l in D['lessons']:w.writerow([l['id'],l['domain'],l['category'],l['title'],l['kind'],l['verification']['status'],l['verification']['reviewed'],l.get('versionSensitive',False),len(l['references']),' | '.join(f'{a} :: {b}' for a,b in l['references'])])
print('v0.6 data:',len(D['lessons']),'lessons',len(D['paths']),'paths',len(D['glossary']),'glossary',sum(l['kind']=='Lab' for l in D['lessons']),'labs',sum(bool(l.get('interactive')) for l in D['lessons']),'interactive')
