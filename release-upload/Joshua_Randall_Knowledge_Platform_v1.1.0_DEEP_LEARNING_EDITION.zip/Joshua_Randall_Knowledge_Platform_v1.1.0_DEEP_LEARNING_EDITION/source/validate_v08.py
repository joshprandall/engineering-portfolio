from pathlib import Path
import json,re,urllib.parse,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'public_html'
s=(P/'knowledge-data.js').read_text(encoding='utf-8');D=json.loads(s[s.index('{'):s.rfind('}')+1])
errors=[];lessons=D['lessons'];ids=[l['id'] for l in lessons];titles=[re.sub(r'\W+',' ',l['title'].lower()).strip() for l in lessons];idset=set(ids)
if D.get('version')!='0.8.0':errors.append('wrong version')
if len(lessons)!=1400:errors.append(f'lesson count {len(lessons)}')
if len(ids)!=len(set(ids)):errors.append('duplicate IDs')
if len(titles)!=len(set(titles)):errors.append('duplicate titles')
approved={'www.rfc-editor.org','www.intel.com','openstax.org','kubernetes.io','sre.google','docs.kernel.org','learn.microsoft.com','docs.nvidia.com','www.mpi-forum.org','docs.riscv.org','www.openmp.org','www.postgresql.org','www.nist.gov','quantum.cloud.ibm.com','docs.python.org','docs.redhat.com','dlmf.nist.gov','csrc.nist.gov','git-scm.com','cheatsheetseries.owasp.org','docs.aws.amazon.com','slurm.schedmd.com','www.gnu.org','pages.nist.gov','developer.hashicorp.com','www.usenix.org','ocw.mit.edu','www.freedesktop.org','systemd.io','www.cisa.gov','opentelemetry.io','lamport.azurewebsites.net','prometheus.io','www.iana.org','pubs.opengroup.org','escholarship.org','developer.download.nvidia.com'}
for l in lessons:
    if not l.get('verifiedClaims'):errors.append(l['id']+': no verified claim')
    if not l.get('references'):errors.append(l['id']+': no source')
    if l.get('verification',{}).get('status')!='verified':errors.append(l['id']+': not verified')
    for r in l.get('references',[]):
        u=urllib.parse.urlparse(r[1]);
        if u.scheme!='https' or u.netloc not in approved:errors.append(l['id']+': unapproved source '+r[1])
    for k in ('prereq','related'):
        for x in l.get(k,[]):
            if x not in idset:errors.append(l['id']+': bad '+k+' '+x)
    q=l.get('quiz');
    if q and (not q.get('options') or not isinstance(q.get('answer'),int) or q['answer']<0 or q['answer']>=len(q['options'])):errors.append(l['id']+': bad quiz')
for p in D['paths']:
    if not p.get('lesson_ids'):errors.append('empty path '+p.get('id','?'))
    for x in p.get('lesson_ids',[]):
        if x not in idset:errors.append('path missing '+x)
for g in D['glossary']:
    if g.get('lesson_id') not in idset:errors.append('glossary missing '+g.get('term','?'))
js=(P/'knowledge.js').read_text(encoding='utf-8');implemented=set(re.findall(r"type==='([^']+)'",js));implemented.update(['urljourney','dns','api','tls','tcp','vector','derivative','matrix','force','projectile','wave','doppler','ohm']);used={l['interactive'] for l in lessons if l.get('interactive')}
if used-implemented:errors.append('missing interactive types '+str(sorted(used-implemented)))
for f in P.glob('*.html'):
    t=f.read_text(encoding='utf-8');xs=re.findall(r'\bid=["\']([^"\']+)',t);dups={x for x in xs if xs.count(x)>1}
    if dups:errors.append(f.name+': duplicate IDs '+str(sorted(dups)))
try:subprocess.run(['node','--check',str(P/'knowledge.js')],check=True,capture_output=True,text=True)
except Exception as e:errors.append('JS syntax '+str(e))
M=json.loads((P/'verification-manifest.json').read_text(encoding='utf-8'))
if M.get('count')!=len(lessons) or len(M.get('records',[]))!=len(lessons):errors.append('manifest mismatch')
if not (P/'learn-mastery.html').exists():errors.append('mastery page missing')
print('VALIDATION','PASS' if not errors else 'FAIL');print('lessons',len(lessons),'paths',len(D['paths']),'glossary',len(D['glossary']),'labs',sum(l.get('kind')=='Lab' for l in lessons),'interactive',sum(bool(l.get('interactive')) for l in lessons),'types',len(used),'atlas',sum(len(v) for v in D['atlas'].values()))
if errors:
    print('\n'.join('ERROR: '+x for x in errors));sys.exit(1)
