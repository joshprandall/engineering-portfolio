#!/usr/bin/env python3
from pathlib import Path
import json,re,urllib.parse,subprocess,sys,collections,csv
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'public_html';errors=[]

def extract_obj(text):
    start=text.index('{');depth=0;ins=False;esc=False
    for i,ch in enumerate(text[start:],start):
        if ins:
            if esc:esc=False
            elif ch=='\\':esc=True
            elif ch=='"':ins=False
        else:
            if ch=='"':ins=True
            elif ch=='{':depth+=1
            elif ch=='}':
                depth-=1
                if depth==0:return json.loads(text[start:i+1])
    raise ValueError('No object')

D=extract_obj((P/'knowledge-data.js').read_text(encoding='utf-8'));L=D['lessons'];ids=[x['id'] for x in L];idset=set(ids)
titles=[re.sub(r'\W+',' ',x['title'].lower()).strip() for x in L]
expected={'cloud':1200,'advanced':1200,'software':1150,'cyber':1150,'leadership':1100,'math':1100,'physics':1100}
counts=collections.Counter(x['domain'] for x in L)
if D.get('version')!='1.1.0':errors.append('wrong version '+repr(D.get('version')))
if len(L)!=8000:errors.append(f'expected 8000, got {len(L)}')
if dict(counts)!=expected:errors.append('domain counts '+repr(dict(counts)))
if len(ids)!=len(set(ids)):errors.append('duplicate IDs')
if len(titles)!=len(set(titles)):errors.append('duplicate titles')
if D.get('deepLearning',{}).get('lessonCount')!=8000:errors.append('deepLearning metadata lesson count')
if D.get('deepLearning',{}).get('chunkCount')!=76:errors.append('deepLearning metadata chunk count')
if D.get('deepLearning',{}).get('audienceModes')!=['starter','general','technical']:errors.append('audience modes')

allowed=set('openstax.org sre.google www.nist.gov www.rfc-editor.org www.postgresql.org docs.python.org git-scm.com csrc.nist.gov www.intel.com dlmf.nist.gov kubernetes.io docs.nvidia.com docs.kernel.org learn.microsoft.com www.mpi-forum.org cheatsheetseries.owasp.org ocw.mit.edu www.openmp.org docs.riscv.org pages.nist.gov www.cisa.gov quantum.cloud.ibm.com docs.redhat.com developer.hashicorp.com www.usenix.org docs.aws.amazon.com opentelemetry.io www.gnu.org lamport.azurewebsites.net slurm.schedmd.com prometheus.io www.freedesktop.org systemd.io escholarship.org www.iana.org pubs.opengroup.org developer.download.nvidia.com'.split())
for x in L:
    if x.get('verification',{}).get('status')!='verified':errors.append(x['id']+': not verified')
    if not x.get('verifiedClaims'):errors.append(x['id']+': missing claim')
    if not x.get('references'):errors.append(x['id']+': missing evidence')
    for r in x.get('references',[]):
        u=urllib.parse.urlparse(r[1]);host=u.netloc.lower()
        if u.scheme!='https' or not host:errors.append(x['id']+': bad URL')
        if host not in allowed:errors.append(x['id']+': unapproved source '+host)
    for k in ('prereq','related'):
        for y in x.get(k,[]):
            if y not in idset:errors.append(x['id']+': bad '+k+' '+y)
    q=x.get('quiz')
    if q and (not q.get('options') or not isinstance(q.get('answer'),int) or not 0<=q['answer']<len(q['options'])):errors.append(x['id']+': bad quiz')

if len(D.get('paths',[]))!=300:errors.append('paths '+str(len(D.get('paths',[]))))
for path in D.get('paths',[]):
    if not path.get('lesson_ids'):errors.append('empty path '+path.get('id','?'))
    for y in path.get('lesson_ids',[]):
        if y not in idset:errors.append('path missing '+y)
if len(D.get('glossary',[]))!=1600:errors.append('glossary '+str(len(D.get('glossary',[]))))
for g in D.get('glossary',[]):
    if g.get('lesson_id') not in idset:errors.append('glossary missing '+g.get('term','?'))
labs=sum(x.get('kind')=='Lab' for x in L);inter=sum(1 for x in L if x.get('kind')=='Lab' or x.get('interactive'))
if labs!=3000:errors.append('labs '+str(labs))
if inter!=4000:errors.append('interactive union '+str(inter))

# Deep-learning chunks
slug=lambda s: re.sub(r'-+','-',re.sub(r'[^a-z0-9]+','-',s.lower())).strip('-') or 'general'
packs={};chunk_files=[]
for f in (P/'deep-learning').rglob('*.json'):
    if f.name in ('index.json','video-profiles.json'):continue
    chunk_files.append(f)
    try:chunk=json.loads(f.read_text(encoding='utf-8'))
    except Exception as e:errors.append(f'{f.name}: json {e}');continue
    for k,v in chunk.items():
        if k in packs:errors.append('duplicate deep pack '+k)
        packs[k]=v
if len(chunk_files)!=76:errors.append('deep chunk files '+str(len(chunk_files)))
if len(packs)!=8000:errors.append('deep packs '+str(len(packs)))
video_ids=set(); required_pack=('essentialQuestion','verifiedBoundary','analogy','starter','technical','reasoningSteps','memoryLadder','labPlan','vocabulary','video')
for l in L:
    expected_path=P/'deep-learning'/l['domain']/(slug(l.get('category','general'))+'.json')
    if not expected_path.exists():errors.append(l['id']+': expected chunk missing')
    g=packs.get(l['id'])
    if not g:continue
    for k in required_pack:
        if k not in g:errors.append(l['id']+': deep missing '+k)
    claim=(l.get('verifiedClaims') or [l.get('takeaway') or l.get('summary')])[0]
    if g.get('verifiedBoundary')!=claim:errors.append(l['id']+': deep boundary differs from verified claim')
    if len(g.get('reasoningSteps',[]))<6:errors.append(l['id']+': reasoning too short')
    if len(g.get('memoryLadder',[]))<6:errors.append(l['id']+': memory ladder too short')
    if len(g.get('labPlan',[]))<6:errors.append(l['id']+': lab plan too short')
    v=g.get('video',{});vid=v.get('youtubeId','');video_ids.add(vid)
    if not re.fullmatch(r'[A-Za-z0-9_-]{6,20}',vid):errors.append(l['id']+': bad video id')
    if l['title'] not in v.get('searchQuery',''):errors.append(l['id']+': exact-topic search missing title')
if '' in video_ids:errors.append('blank YouTube id')

# Manifest and pages
M=json.loads((P/'verification-manifest.json').read_text(encoding='utf-8'))
if M.get('version')!='1.1.0' or M.get('count')!=8000 or len(M.get('records',[]))!=8000:errors.append('manifest mismatch')
for name in ['learn.html','learn-browse.html','learn-paths.html','learn-practice.html','learn-labs.html','learn-glossary.html','learn-map.html','learn-mastery.html','learn-verify.html','index.html','projects.html','knowledge.js','knowledge.css','knowledge-data.js']:
    if not (P/name).exists():errors.append('missing '+name)
for f in P.glob('*.html'):
    t=f.read_text(encoding='utf-8');xs=re.findall(r'\bid=["\']([^"\']+)',t);dups=[k for k,v in collections.Counter(xs).items() if v>1]
    if dups:errors.append(f.name+': duplicate IDs '+repr(dups[:5]))
try:subprocess.run(['node','--check',str(P/'knowledge.js')],check=True,capture_output=True,text=True)
except Exception as e:errors.append('JS syntax '+str(e))
js=(P/'knowledge.js').read_text(encoding='utf-8')
for view in ['overview','explain','visual','video','lab','practice','review','evidence']:
    if f"['{view}'" not in js:errors.append('missing view '+view)
if 'youtube-nocookie.com/embed/' not in js:errors.append('privacy-enhanced YouTube embed absent')
if 'autoplay=1' in js:errors.append('YouTube autoplay found')
if 'Starter / young learner' not in js or 'Technical depth' not in js:errors.append('learner modes absent')
if 'concept-visual' not in js:errors.append('concept visual absent')
if 'TEACH-BACK STUDIO' not in js:errors.append('teachback absent')

csv_path=ROOT/'VERIFICATION_MANIFEST_v1.1.0.csv'
if not csv_path.exists():errors.append('top-level verification CSV missing')
else:
    with csv_path.open(encoding='utf-8',newline='') as fh: rows=sum(1 for _ in csv.reader(fh))-1
    if rows!=8000:errors.append('CSV rows '+str(rows))

print('VALIDATION','PASS' if not errors else 'FAIL')
print('lessons',len(L),'domains',dict(counts),'labs',labs,'paths',len(D.get('paths',[])),'glossary',len(D.get('glossary',[])),'interactive_experiences',inter)
print('deep_packs',len(packs),'chunks',len(chunk_files),'youtube_companions',sum(bool(packs.get(l['id'],{}).get('video',{}).get('youtubeId')) for l in L),'video_profiles',len(video_ids))
print('knowledge_data_bytes',(P/'knowledge-data.js').stat().st_size,'deep_learning_bytes',sum(f.stat().st_size for f in (P/'deep-learning').rglob('*') if f.is_file()))
if errors:
    print('\n'.join('ERROR: '+e for e in errors[:200]));sys.exit(1)
