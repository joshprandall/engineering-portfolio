from pathlib import Path
import json,re,urllib.parse,subprocess,sys,collections
ROOT=Path(__file__).resolve().parents[1]; P=ROOT/'public_html'
s=(P/'knowledge-data.js').read_text(encoding='utf-8'); D=json.loads(s[s.index('{'):s.rfind('}')+1])
errors=[]; L=D['lessons']; ids=[x['id'] for x in L]; titles=[re.sub(r'\W+',' ',x['title'].lower()).strip() for x in L]; idset=set(ids)
if D.get('version')!='0.9.0': errors.append('wrong version')
if len(L)!=4200: errors.append(f'expected 4200 lessons, got {len(L)}')
if len(ids)!=len(set(ids)): errors.append('duplicate lesson IDs')
if len(titles)!=len(set(titles)): errors.append('duplicate lesson titles')
expected={'cloud':650,'advanced':650,'software':600,'cyber':575,'leadership':575,'math':575,'physics':575}
counts=collections.Counter(x['domain'] for x in L)
if dict(counts)!=expected: errors.append('domain counts '+repr(dict(counts)))
for x in L:
    if x.get('verification',{}).get('status')!='verified': errors.append(x['id']+': not verified')
    if not x.get('verifiedClaims'): errors.append(x['id']+': missing verified claim')
    if not x.get('references'): errors.append(x['id']+': missing evidence')
    for r in x.get('references',[]):
        u=urllib.parse.urlparse(r[1])
        if u.scheme!='https' or not u.netloc: errors.append(x['id']+': invalid evidence URL')
    for k in ('prereq','related'):
        for y in x.get(k,[]):
            if y not in idset: errors.append(x['id']+': bad '+k+' '+y)
    q=x.get('quiz')
    if q and (not q.get('options') or not isinstance(q.get('answer'),int) or not 0<=q['answer']<len(q['options'])): errors.append(x['id']+': bad quiz')
for p in D.get('paths',[]):
    if not p.get('lesson_ids'): errors.append('empty path '+p.get('id','?'))
    for y in p.get('lesson_ids',[]):
        if y not in idset: errors.append('path missing '+y)
for g in D.get('glossary',[]):
    if g.get('lesson_id') not in idset: errors.append('glossary missing '+g.get('term','?'))
# all learning pages must exist; no gigantic single-page regression
for name in ['learn.html','learn-browse.html','learn-paths.html','learn-practice.html','learn-labs.html','learn-glossary.html','learn-map.html','learn-mastery.html','learn-verify.html']:
    if not (P/name).exists(): errors.append('missing page '+name)
# duplicate IDs
for f in P.glob('*.html'):
    t=f.read_text(encoding='utf-8'); xs=re.findall(r'\bid=["\']([^"\']+)',t); c=collections.Counter(xs); d=[k for k,v in c.items() if v>1]
    if d: errors.append(f.name+': duplicate HTML IDs '+repr(d[:5]))
try: subprocess.run(['node','--check',str(P/'knowledge.js')],check=True,capture_output=True,text=True)
except Exception as e: errors.append('JS syntax '+str(e))
M=json.loads((P/'verification-manifest.json').read_text(encoding='utf-8'))
if M.get('version')!='0.9.0' or M.get('count')!=4200 or len(M.get('records',[]))!=4200: errors.append('manifest mismatch')
if len(D.get('glossary',[]))<700: errors.append('glossary unexpectedly small')
if sum(1 for x in L if x.get('kind')=='Lab')<1500: errors.append('not enough labs')
print('VALIDATION', 'PASS' if not errors else 'FAIL')
print('lessons',len(L),'domains',dict(counts),'paths',len(D.get('paths',[])),'glossary',len(D.get('glossary',[])),'labs',sum(1 for x in L if x.get('kind')=='Lab'),'model_interactive',sum(bool(x.get('interactive')) for x in L),'lab_or_model',sum(1 for x in L if x.get('interactive') or x.get('kind')=='Lab'))
if errors:
    print('\n'.join('ERROR: '+e for e in errors[:100])); sys.exit(1)
