from pathlib import Path
import json,re,csv,copy,shutil,zipfile,collections,subprocess,sys,html,urllib.parse,random
BASE=Path('/mnt/data/kp_v09_base/Joshua_Randall_Knowledge_Platform_v0.8.0')
OUT=Path('/mnt/data/Joshua_Randall_Knowledge_Platform_v0.9.0')
ZIP=Path('/mnt/data/Joshua_Randall_Knowledge_Platform_v0.9.0.zip')
REVIEW='2026-09-07'
if OUT.exists(): shutil.rmtree(OUT)
shutil.copytree(BASE,OUT)
P=OUT/'public_html'

def load_js(path):
    s=Path(path).read_text(encoding='utf-8'); st=s.index('{'); d=0; ins=False; esc=False
    for i,ch in enumerate(s[st:],st):
        if ins:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': ins=False
        else:
            if ch=='"': ins=True
            elif ch=='{': d+=1
            elif ch=='}':
                d-=1
                if d==0: return json.loads(s[st:i+1])
    raise RuntimeError('JSON object not found')
D=load_js(P/'knowledge-data.js')
assert D['version']=='0.8.0'
D['version']='0.9.0'

# Aim deliberately far beyond 3,000 while keeping every domain substantial.
TARGETS={'cloud':650,'advanced':650,'software':600,'cyber':575,'leadership':575,'math':575,'physics':575}
assert sum(TARGETS.values())==4200

def norm(s): return re.sub(r'[^a-z0-9]+',' ',str(s).lower()).strip()
def slug(s): return re.sub(r'[^a-z0-9]+','-',str(s).lower()).strip('-')
ids={l['id'] for l in D['lessons']}; titles={norm(l['title']) for l in D['lessons']}
BASE_LESSONS=copy.deepcopy(D['lessons'])
source_by_domain=collections.defaultdict(list)
for l in BASE_LESSONS:
    if l.get('references') and l.get('verifiedClaims') and l.get('verification',{}).get('status')=='verified': source_by_domain[l['domain']].append(l)

# Strip pedagogical prefixes so new objects read naturally.
def concept_title(title):
    t=title.strip()
    prefixes=['Deep Dive: ','Evidence Lab: ','Quick Concept: ','Troubleshooting Guide: ','Lab: ','Practice: ','Worked Example: ','Scenario: ','What Is ','Understanding ']
    for p in prefixes:
        if t.startswith(p): t=t[len(p):]
    return t.strip(' ?')

# Pedagogical formats. Half are hands-on labs; all reuse only the parent's exact verified claim.
FORMATS=[
 ('Practical Lab','Lab','Hands-on'),
 ('Troubleshooting Lab','Lab','Troubleshooting'),
 ('Evidence Verification Lab','Lab','Evidence'),
 ('Teach-Back Lab','Lab','Teach-back'),
 ('Failure Analysis Lab','Lab','Failure analysis'),
 ('Decision Lab','Lab','Decision'),
 ('Worked Example','Lesson','Worked example'),
 ('Scenario Analysis','Lesson','Scenario'),
 ('Recall Drill','Quick Concept','Recall'),
 ('Misconception Clinic','Quick Concept','Misconception'),
 ('Design Review','Lesson','Design review'),
 ('Quick Reference','Quick Concept','Reference'),
]

def domain_activity(domain,fmt,concept,claim):
    if domain=='cloud':
        bank={
        'Hands-on':f'Build a safe test case for {concept}. State the expected result first, perform only non-destructive checks, capture the observed output, and compare it with the cited rule.',
        'Troubleshooting':f'A hypothetical service is behaving inconsistently with the documented rule for {concept}. List three observations you would collect before changing configuration, then use the evidence to decide which observation can confirm or reject your hypothesis.',
        'Evidence':f'Open the authoritative source for {concept}, locate the supporting section, quote no more than a short phrase in your notes, and restate the rule in your own words. Then create one configuration or packet-flow example that obeys the rule.',
        'Teach-back':f'Explain {concept} to a new administrator without jargon. Then add the exact technical condition from the verified claim and one diagnostic command or observation you would use in a lab environment.',
        'Failure analysis':f'Imagine a controlled lab failure related to {concept}. Predict the symptom, identify the layer where the rule applies, and write the minimum rollback step before you reveal the verified claim.',
        'Decision':f'Compare two hypothetical implementation choices involving {concept}. Choose one only after writing the documented rule that constrains the decision and the evidence you would collect after deployment.'}
    elif domain=='advanced':
        bank={
        'Hands-on':f'Work a small numerical or state-tracing example for {concept}. Predict the intermediate state, show each transformation, and compare the final result with the verified claim.',
        'Troubleshooting':f'A benchmark or simulation involving {concept} produces a surprising result. Separate what the verified rule guarantees from what depends on implementation, then list measurements needed before blaming hardware or software.',
        'Evidence':f'Locate the definition or rule for {concept} in the cited standard, architecture manual, or textbook. Re-express it precisely and test it on a tiny worked example.',
        'Teach-back':f'Teach {concept} at two levels: first in one plain-language sentence, then in an engineering-level explanation that preserves the exact condition in the verified claim.',
        'Failure analysis':f'Construct a hypothetical performance or correctness failure involving {concept}. Identify which observed behavior would actually contradict the verified claim and which would merely be consistent with another bottleneck.',
        'Decision':f'Given two hypothetical architecture choices involving {concept}, state the verified rule first, then identify what additional measurements or constraints are required before choosing.'}
    elif domain=='software':
        bank={
        'Hands-on':f'Create the smallest reproducible code or data example for {concept}. Predict the behavior, run or trace it, and compare the result with the exact documented claim.',
        'Troubleshooting':f'A small program behaves differently from a developer assumption about {concept}. Write a minimal reproduction, identify the relevant documented rule, and change one variable at a time.',
        'Evidence':f'Find the exact documentation section for {concept}, summarize the documented behavior, and write a tiny example that demonstrates only that behavior without unrelated framework code.',
        'Teach-back':f'Explain {concept} to a teammate, then add a minimal code or database example that demonstrates the verified rule and one test that would catch an incorrect assumption.',
        'Failure analysis':f'Invent a controlled bug related to {concept}. State the incorrect assumption, the expected symptom, and the smallest test that distinguishes the bug from an unrelated failure.',
        'Decision':f'Compare two hypothetical implementation approaches involving {concept}. Use the documented rule as a constraint, then identify tradeoffs that require measurement rather than guesswork.'}
    elif domain=='cyber':
        bank={
        'Hands-on':f'Use a fictional system and no real credentials. Apply the verified rule for {concept} to a safe configuration or policy review, record the expected control behavior, and identify evidence that would demonstrate the control is working.',
        'Troubleshooting':f'A fictional security control related to {concept} appears ineffective. Separate authentication, authorization, configuration, logging, and user-behavior hypotheses before changing anything.',
        'Evidence':f'Open the cited NIST, CISA, OWASP, or primary guidance for {concept}. Identify the narrow recommendation used by this lesson and map it to one fictional system requirement.',
        'Teach-back':f'Explain {concept} to a non-security stakeholder without fear-based language. Then state the exact verified control or architectural principle and how it could be evidenced.',
        'Failure analysis':f'Create a tabletop scenario involving {concept}. Identify the asset, threat, assumed control, evidence of control behavior, and one safe validation step.',
        'Decision':f'Choose between two hypothetical security designs only after stating the verified rule for {concept}; document what residual risk remains outside that rule.'}
    elif domain=='leadership':
        bank={
        'Hands-on':f'Use a fictional team or service. Apply the verified operating principle for {concept}, create the smallest useful artifact (metric, agenda, runbook step, decision record, or communication), and explain how you would know it improved the situation.',
        'Troubleshooting':f'A fictional team is struggling around {concept}. Separate observable system facts from interpretations, identify the verified operating principle, and propose one reversible experiment.',
        'Evidence':f'Locate the cited SRE, NIST, or continuity guidance for {concept}. Translate the verified rule into one concrete operating practice and one measurable outcome.',
        'Teach-back':f'Explain {concept} to a new manager, then state the verified principle precisely and give one example of behavior that follows it.',
        'Failure analysis':f'Run a tabletop failure involving {concept}. Identify decision rights, evidence, communication needs, and the point at which escalation is justified.',
        'Decision':f'Compare two hypothetical management choices involving {concept}. State the verified principle first, then identify tradeoffs the source does not decide for you.'}
    elif domain=='math':
        bank={
        'Hands-on':f'Solve a small example involving {concept} by hand. Write each transformation, check units or dimensions when relevant, and verify the result against the definition or theorem in the cited source.',
        'Troubleshooting':f'A worked solution involving {concept} contains an error. Identify the first step that violates the verified rule, correct it, and explain why later arithmetic cannot repair an invalid transformation.',
        'Evidence':f'Find the definition or theorem for {concept} in the cited text, rewrite it in your own notation, and construct both a valid example and a near-miss that fails one condition.',
        'Teach-back':f'Explain {concept} with one visual or numerical example, then restate the precise verified rule so the simplification does not change the mathematics.',
        'Failure analysis':f'Construct a plausible wrong solution for {concept}. Mark the exact step where it departs from the verified rule and repair the solution from that point.',
        'Decision':f'Given two possible methods for a problem involving {concept}, identify which verified conditions make each method valid before choosing the simpler route.'}
    else: # physics
        bank={
        'Hands-on':f'Use a small idealized example for {concept}. Draw the system, define variables and units, predict the direction or trend, calculate where appropriate, and compare with the verified physical law.',
        'Troubleshooting':f'A physics solution involving {concept} gives an implausible result. Check sign conventions, units, assumptions, and the verified law before repeating arithmetic.',
        'Evidence':f'Locate the law or definition for {concept} in the cited textbook, state its conditions, and work one idealized example that keeps those conditions explicit.',
        'Teach-back':f'Explain {concept} in everyday language, then translate that explanation back into the verified physical relationship without adding unsupported claims.',
        'Failure analysis':f'Create a deliberately incorrect physical model involving {concept}. Identify the violated assumption or law, then repair the model and describe the changed prediction.',
        'Decision':f'Compare two candidate models for a hypothetical problem involving {concept}. Use the verified law and stated assumptions to decide which model is applicable.'}
    return bank.get(fmt, f'Use the verified claim for {concept} as the rule. Work one example, explain your reasoning, and check your answer against the authoritative source before marking the lesson complete.')

new=[]
def add_derived(parent,fmt_label,kind,mode,seq):
    concept=concept_title(parent['title'])
    title=f'{fmt_label}: {concept}'
    # Distinguish rare collision with existing pedagogical title.
    if norm(title) in titles:
        title=f'{fmt_label} {seq}: {concept}'
    nt=norm(title)
    if nt in titles: return None
    domain=parent['domain']; cat=parent.get('category','Foundations')
    lid=f'{domain}-v09-{slug(fmt_label)[:24]}-{slug(concept)[:56]}'
    n=2
    while lid in ids:
        lid=f'{domain}-v09-{slug(fmt_label)[:18]}-{slug(concept)[:48]}-{n}'; n+=1
    claim=parent['verifiedClaims'][0]
    activity=domain_activity(domain,mode,concept,claim)
    if kind=='Lab':
        explanation=(f'This is a practical, evidence-first lab built around one already verified claim: {claim}\n\n'
                     f'Complete the prediction and working notes before revealing the claim. The lab intentionally keeps the factual scope narrow so the result can be checked directly against the linked authoritative source.')
        summary=f'Practice {concept} through prediction, a controlled scenario, and direct evidence verification.'
        why=f'The lab converts a source-backed rule about {concept} into an observable decision or result, which strengthens retrieval and troubleshooting rather than passive recognition.'
        minutes=18
    elif mode=='Recall':
        explanation=(f'Retrieve the rule for {concept} before opening the source. The verified claim is: {claim}\n\n'
                     'After answering, compare your wording with the evidence and correct only what the source actually contradicts.')
        summary=f'Active-recall practice for the verified rule behind {concept}.'; why='Retrieval practice exposes gaps that rereading can hide.'; minutes=6
        activity=f'Close the evidence panel. Write the rule for {concept} from memory, list its conditions, then reveal the verified claim and score your answer as exact, partially correct, or unsupported.'
    elif mode=='Misconception':
        explanation=(f'The factual anchor for this misconception check is: {claim}\n\n'
                     'The exercise asks you to distinguish that documented rule from conclusions that sound plausible but go beyond the evidence.')
        summary=f'Distinguish the documented rule for {concept} from common overgeneralizations.'; why='Accurate technical judgment depends on knowing what a source does and does not establish.'; minutes=7
        activity=f'Write one statement about {concept} that is exactly supported by the verified claim and two stronger statements that are not guaranteed by it. Explain the missing condition in each overstatement.'
    elif mode=='Reference':
        explanation=(f'Use this as a compact reference for {concept}. Verified claim: {claim}\n\n'
                     'The evidence link is part of the reference: if a version-sensitive technology changes, the source must be rechecked rather than relying on memory.')
        summary=f'A compact, source-linked reference for {concept}.'; why='Fast references are useful only when they preserve the condition and evidence behind the rule.'; minutes=5
        activity=f'Convert the claim for {concept} into a three-line field note: rule, condition, verification source. Do not add behavior that the source does not state.'
    else:
        explanation=(f'This learning object applies the already verified claim for {concept}: {claim}\n\n'
                     f'The scenario is instructional rather than a new factual claim. Use the cited evidence as the authoritative boundary for your conclusion.')
        summary=f'Apply the verified rule for {concept} in a {mode.lower()} exercise.'; why=f'Applying {concept} in a new context makes the rule easier to retrieve and harder to confuse with an assumption.'; minutes=10
        if mode=='Worked example': activity=f'Create a small example for {concept}. State the verified rule first, show each step of your reasoning, and mark which step directly depends on the cited claim.'
        elif mode=='Scenario': activity=f'Read the verified claim for {concept}, then analyze a hypothetical scenario. Separate observations, assumptions, the documented rule, and the conclusion.'
        elif mode=='Design review': activity=f'Review a fictional design involving {concept}. Identify the decision that depends on the verified rule, then list questions that remain unanswered by that rule.'
    options=[claim,
             'The cited source proves the exact opposite in every case.',
             'The concept has no conditions and cannot be checked against evidence.',
             'Any conclusion about this topic is equally correct because implementation details never matter.']
    refs=copy.deepcopy(parent['references'])
    ver=copy.deepcopy(parent.get('verification',{})); ver.update({'status':'verified','reviewed':REVIEW,'method':'Derived learning activity reusing an exact verified claim and the same authoritative evidence as its source learning object. No additional factual claim is introduced by the scenario text.','parentLessonId':parent['id'],'claimType':'Exact inherited verified claim','sourceCount':len(refs)})
    l={
      'id':lid,'domain':domain,'category':cat,'title':title,'summary':summary,'explanation':explanation,'why':why,'example':activity,'takeaway':claim,
      'difficulty':parent.get('difficulty','Foundation'),'kind':kind,'minutes':minutes,'tags':list(dict.fromkeys((parent.get('tags') or [])+[mode.lower(),fmt_label.lower(),cat.lower(),domain])),
      'interactive':parent.get('interactive') if parent.get('interactive') and kind=='Lab' else None,
      'prereq':[parent['id']],'related':list(dict.fromkeys(([parent['id']]+(parent.get('related') or []))))[:5],
      'quiz':{'q':f'Which statement is directly supported by the cited evidence for {concept}?','options':options,'answer':0,'explanation':claim},
      'misconception':f'Do not infer more than the verified claim establishes. A scenario can illustrate the rule, but it does not change the source conditions.',
      'objectives':[f'Retrieve the verified rule for {concept}',f'Apply the rule in a {mode.lower()} activity','Check the conclusion against the authoritative evidence'],
      'references':refs,'verification':ver,'versionSensitive':bool(parent.get('versionSensitive')),'verifiedClaims':[claim]
    }
    D['lessons'].append(l); ids.add(lid); titles.add(nt); new.append(l); return lid

# Round-robin generation across categories and formats to avoid one-topic flooding.
for domain,target in TARGETS.items():
    current=sum(1 for l in D['lessons'] if l['domain']==domain)
    need=target-current
    sources=source_by_domain[domain]
    # Favor concept-level source objects and spread categories evenly.
    bycat=collections.defaultdict(list)
    for l in sources: bycat[l.get('category','Foundations')].append(l)
    cats=sorted(bycat)
    for c in cats: bycat[c].sort(key=lambda x:(concept_title(x['title']),x['id']))
    idx={c:0 for c in cats}; produced=0; fmt_index=0; guard=0
    while produced<need:
        guard+=1
        if guard>need*20: raise RuntimeError(f'Could not generate enough for {domain}')
        c=cats[produced%len(cats)]
        pool=bycat[c]
        parent=pool[idx[c]%len(pool)]; idx[c]+=1
        fmt=FORMATS[fmt_index%len(FORMATS)]; fmt_index+=1
        if add_derived(parent,*fmt,seq=idx[c]): produced+=1
    print(domain,'added',produced,'target',target)

assert len(D['lessons'])==4200, len(D['lessons'])

# Add category-based guided practice paths, without making pages longer.
path_ids={p['id'] for p in D.get('paths',[])}; path_titles={norm(p.get('title','')) for p in D.get('paths',[])}
for domain in TARGETS:
    domain_name=next(d['name'] for d in D['domains'] if d['id']==domain)
    cats=sorted({l.get('category','Foundations') for l in D['lessons'] if l['domain']==domain})
    for cat in cats:
        ls=[l for l in D['lessons'] if l['domain']==domain and l.get('category')==cat]
        # Pick a mix: source/core, lab, recall, scenario.
        ls=sorted(ls,key=lambda l:(0 if l['kind']=='Lesson' else 1 if l['kind']=='Lab' else 2,l['title']))
        chosen=[]
        for l in ls:
            if l['id'] not in chosen: chosen.append(l['id'])
            if len(chosen)>=12: break
        if len(chosen)<4: continue
        pid=f'v09-{domain}-{slug(cat)}-practice'
        title=f'{domain_name}: {cat} Practice Track'
        if pid in path_ids or norm(title) in path_titles: continue
        D['paths'].append({'id':pid,'title':title,'summary':f'A 12-object evidence-first sequence through {cat.lower()} concepts, examples, recall, and practical labs.','domain':domain,'difficulty':'Mixed','lesson_ids':chosen})
        path_ids.add(pid); path_titles.add(norm(title))

# Grow the glossary to 800 unique, evidence-linked terms.
gloss=D.get('glossary',[]); gt={norm(g['term']) for g in gloss}
for l in D['lessons']:
    if len(gloss)>=800: break
    term=concept_title(l['title'])
    if norm(term) in gt or len(term)>80: continue
    gloss.append({'term':term,'definition':l['verifiedClaims'][0],'domain':l['domain'],'lesson_id':l['id']}); gt.add(norm(term))
D['glossary']=gloss

# Preserve atlas but make published counts visible through data; update target language to communicate scale.
for d in D['domains']:
    d['target']='Open-ended'

# Write dataset.
(P/'knowledge-data.js').write_text('window.JR_KNOWLEDGE = '+json.dumps(D,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')

# Verification manifests reuse exact evidence from every object.
records=[]
for l in D['lessons']:
    records.append({'id':l['id'],'title':l['title'],'domain':l['domain'],'category':l.get('category',''),'reviewed':l.get('verification',{}).get('reviewed',REVIEW),'versionSensitive':bool(l.get('versionSensitive')),'verifiedClaims':l.get('verifiedClaims',[]),'sources':[{'title':r[0],'url':r[1]} for r in l.get('references',[])]})
manifest={'version':'0.9.0','reviewed':REVIEW,'count':len(records),'policy':'Every published learning object carries an exact source-backed verified claim. v0.9 derived practice objects reuse the parent claim and evidence verbatim; scenario and activity text is explicitly instructional, not an additional factual claim.','records':records}
(P/'verification-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'VERIFICATION_MANIFEST_v0.9.0.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['id','title','domain','category','reviewed','version_sensitive','verified_claims','sources'])
    for r in records: w.writerow([r['id'],r['title'],r['domain'],r['category'],r['reviewed'],r['versionSensitive'],' | '.join(r['verifiedClaims']),' | '.join(x['url'] for x in r['sources'])])

# UI: better natural-voice selection and bounded lab pagination (never dump thousands of labs into one page).
js=(P/'knowledge.js').read_text(encoding='utf-8')
js=js.replace("let recallLessonId = null, flashIndex = 0, flashRevealed = false, showAllLabs = false, labDomain='all', labDifficulty='all', sprintState=null;",
              "let recallLessonId = null, flashIndex = 0, flashRevealed = false, labLimit = 12, labDomain='all', labDifficulty='all', sprintState=null;")
old="""  function voiceScore(v){\n    const n=v.name.toLowerCase(), lang=(v.lang||'').toLowerCase(), user=(navigator.language||'en-us').toLowerCase();let s=0;\n    if(lang===user)s+=60;else if(lang.startsWith(user.split('-')[0]))s+=35;\n    if(/natural|neural|premium|enhanced/.test(n))s+=80;\n    if(/ava|aria|jenny|guy|andrew|brian|emma|sonia|ryan|samantha|daniel|google us english/.test(n))s+=45;\n    if(/microsoft|google|apple/.test(n))s+=15;if(v.default)s+=10;return s;\n  }"""
newvoice="""  function voiceScore(v){\n    const n=(v.name||'').toLowerCase(), lang=(v.lang||'').toLowerCase(), user=(navigator.language||'en-us').toLowerCase();let s=0;\n    if(lang===user)s+=90;else if(lang.startsWith(user.split('-')[0]))s+=50;\n    if(/natural|neural|premium|enhanced|online/.test(n))s+=140;\n    if(/ava|aria|jenny|andrew|brian|emma|sonia|ryan|samantha|daniel|serena|zira|david|google us english/.test(n))s+=60;\n    if(/microsoft|google|apple/.test(n))s+=25;\n    if(v.localService===false)s+=18;\n    if(/compact|espeak|festival/.test(n))s-=80;\n    if(v.default)s+=12;return s;\n  }"""
if old in js: js=js.replace(old,newvoice)
js=js.replace("function speechChunks(text,max=280)","function speechChunks(text,max=220)")
js=js.replace("u.rate=Number(localStorage.getItem(STORAGE.narrationRate)||0.95);u.pitch=1;u.volume=1;u.onend=()=>setTimeout(next,55)","u.rate=Number(localStorage.getItem(STORAGE.narrationRate)||0.95);u.pitch=.98;u.volume=1;u.onend=()=>setTimeout(next,110)")
# Replace lab gallery function lines safely.
js=js.replace("const visible=showAllLabs?labs:labs.slice(0,12);const count=$('#lab-count');if(count)count.textContent=`${labs.length} matching interactive learning object${labs.length===1?'':'s'}`;",
              "const visible=labs.slice(0,labLimit);const count=$('#lab-count');if(count)count.textContent=`${labs.length} matching interactive learning object${labs.length===1?'':'s'} · showing ${Math.min(labLimit,labs.length)}`;")
js=js.replace("$$('[data-launch-lab]',grid).forEach(b=>b.onclick=()=>openLesson(b.dataset.launchLab));const tog=$('#toggle-labs');if(tog)tog.textContent=showAllLabs?'Show featured only':'Show all labs';",
              "$$('[data-launch-lab]',grid).forEach(b=>b.onclick=()=>openLesson(b.dataset.launchLab));const tog=$('#toggle-labs');if(tog){tog.hidden=labLimit>=labs.length;tog.textContent='Show 12 more labs';}")
js=js.replace("const tl=$('#toggle-labs');if(tl)tl.onclick=()=>{showAllLabs=!showAllLabs;renderLabGallery()};const ld=$('#lab-domain');if(ld)ld.onchange=()=>{labDomain=ld.value;showAllLabs=false;renderLabGallery()};const ll=$('#lab-level');if(ll)ll.onchange=()=>{labDifficulty=ll.value;showAllLabs=false;renderLabGallery()};",
              "const tl=$('#toggle-labs');if(tl)tl.onclick=()=>{labLimit+=12;renderLabGallery()};const ld=$('#lab-domain');if(ld)ld.onchange=()=>{labDomain=ld.value;labLimit=12;renderLabGallery()};const ll=$('#lab-level');if(ll)ll.onchange=()=>{labDifficulty=ll.value;labLimit=12;renderLabGallery()};")
(P/'knowledge.js').write_text(js,encoding='utf-8')

# Update projects card release indicator and HTML version comments.
proj=(P/'projects.html').read_text(encoding='utf-8')
proj=re.sub(r'Knowledge Platform v0\.7\.0','Knowledge Platform v0.9.0',proj)
proj=re.sub(r'Active knowledge platform · v0\.7\.0','Active knowledge platform · v0.9.0',proj)
(P/'projects.html').write_text(proj,encoding='utf-8')

# Update comments/version strings in learning HTML without hardcoding content counts.
for f in P.glob('learn*.html'):
    t=f.read_text(encoding='utf-8').replace('v0.8.0','v0.9.0').replace('v0.7.0','v0.9.0')
    f.write_text(t,encoding='utf-8')

# Docs.
counts=collections.Counter(l['domain'] for l in D['lessons']); labs=sum(l.get('kind')=='Lab' for l in D['lessons']); model=sum(bool(l.get('interactive')) for l in D['lessons']); interactive_workflows=sum(1 for l in D['lessons'] if l.get('interactive') or l.get('kind')=='Lab'); atlas=sum(len(v) for v in D.get('atlas',{}).values())
domain_names={d['id']:d['name'] for d in D['domains']}
release='JOSHUA RANDALL KNOWLEDGE PLATFORM — v0.9.0 RELEASE NOTES\n\n'
release+=f'PUBLISHED SCALE\n- Total source-verified learning objects: {len(D["lessons"]):,}\n'
for k in TARGETS: release+=f'- {domain_names[k]}: {counts[k]:,}\n'
release+=f'''\nPRACTICE + RETENTION\n- Guided learning paths: {len(D['paths']):,}\n- Glossary terms: {len(D['glossary']):,}\n- Practical / evidence labs: {labs:,}\n- Interactive model-backed objects: {model:,}\n- Objects with an interactive model or evidence-lab workflow: {interactive_workflows:,}\n- Mapped future topics retained: {atlas:,}\n\nWHAT CHANGED\n- v0.9 moves the published library well beyond 3,000 objects to 4,200.\n- New practice objects are derived from already verified parent lessons. The exact verified claim and authoritative references are reused verbatim; hypothetical scenarios and exercises introduce no new factual assertions.\n- Added practical labs, troubleshooting labs, evidence-verification labs, teach-back labs, failure-analysis labs, decision labs, worked examples, scenario analysis, recall drills, misconception clinics, design reviews, and quick references.\n- Lab gallery is paginated in blocks of 12 so even thousands of labs never create a giant one-page scroll.\n- Narration voice ranking now more aggressively prefers natural/neural/premium voices exposed by the visitor’s operating system or browser, uses shorter utterance chunks, and adds a more human pause between chunks.\n- Existing multi-page, low-scroll, phone-first responsive architecture is preserved.\n\nVERIFICATION RULE\nVerified means the factual claim is supported by the linked authoritative evidence on the recorded review date. Version-sensitive technologies must be rechecked against their source when the product or standard changes.\n'''
(OUT/'RELEASE_NOTES_v0.9.0.txt').write_text(release,encoding='utf-8')
policy='''JOSHUA RANDALL KNOWLEDGE PLATFORM — SOURCE VERIFICATION POLICY v0.9.0\n\nPUBLICATION GATE\n1. Every published object must contain at least one narrow, checkable factual claim.\n2. Every factual claim must have direct authoritative evidence.\n3. v0.9 practice/scenario objects may reuse an already verified claim, but they may not introduce new factual assertions unless independently sourced.\n4. Hypothetical scenarios, exercises, calculations, and design choices are labeled or phrased as instructional activities, not evidence.\n5. Review date and version sensitivity are recorded.\n6. Labs require prediction before reveal, direct evidence checking, and a learner explanation after comparison.\n7. Interactive models that simplify real implementations must identify themselves as educational models.\n\n“Verified” means checked against the linked evidence on the stated review date. It is not a claim that version-sensitive technology can never change.\n'''
(OUT/'SOURCE_VERIFICATION_POLICY_v0.9.0.txt').write_text(policy,encoding='utf-8')
readme=f'''JOSHUA RANDALL KNOWLEDGE PLATFORM v0.9.0\n\nQUICK DEPLOYMENT\n1. Extract this ZIP.\n2. Open the included public_html folder.\n3. Copy the CONTENTS of that folder into your existing OSU public_html folder.\n4. Replace matching Knowledge Platform files when prompted.\n5. Do not delete unrelated existing files such as styles.css, app.js, resume.html, or your assets folder.\n6. Hard-refresh the live site (Ctrl+F5 on Windows).\n\nPUBLISHED CONTENT\n- {len(D['lessons']):,} source-verified learning objects\n- {len(D['paths']):,} guided learning paths\n- {len(D['glossary']):,} glossary terms\n- {labs:,} practical/evidence labs\n- {interactive_workflows:,} objects with an interactive model or interactive evidence-lab workflow\n\nNAVIGATION\nLearning remains split across separate pages: Home, Browse & Search, Learning Paths, Practice, Labs, Glossary, Knowledge Map, Mastery, and Verification. Individual lessons remain split into Overview, Learn, Explore/Lab, Practice, and Evidence views.\n\nACCURACY\nSee SOURCE_VERIFICATION_POLICY_v0.9.0.txt and VERIFICATION_MANIFEST_v0.9.0.csv.\n'''
(OUT/'README_FIRST.txt').write_text(readme,encoding='utf-8')
(P/'README_KNOWLEDGE_PLATFORM.txt').write_text(readme,encoding='utf-8')

# Remove stale root version docs that could confuse deployment/support.
for name in ['RELEASE_NOTES_v0.8.0.txt','SOURCE_VERIFICATION_POLICY_v0.8.0.txt','VALIDATION_v0.8.0.txt','VERIFICATION_MANIFEST_v0.8.0.csv']:
    q=OUT/name
    if q.exists(): q.unlink()

# Reproducible source script.
source=OUT/'source'; source.mkdir(exist_ok=True)
shutil.copy2('/mnt/data/build_v09.py',source/'build_v09.py')

# Validation: exact count, references, relationships, paths, glossary, JS, HTML IDs, manifests, responsive pages.
validate=source/'validate_v09.py'
validate.write_text(r'''from pathlib import Path
import json,re,urllib.parse,subprocess,sys,collections
ROOT=Path(__file__).resolve().parents[1]; P=ROOT/'public_html'
s=(P/'knowledge-data.js').read_text(encoding='utf-8'); D=json.loads(s[s.index('{'):s.rfind('}')+1])
errors=[]; L=D['lessons']; ids=[x['id'] for x in L]; titles=[re.sub(r'\W+',' ',x['title'].lower()).strip() for x in L]; idset=set(ids)
if D.get('version')!='0.9.0': errors.append('wrong version')
if len(L)!=4200: errors.append(f'expected 4200 lessons, got {len(L)}')
if len(ids)!=len(set(ids)): errors.append('duplicate lesson IDs')
if len(titles)!=len(set(titles)): errors.append('duplicate lesson titles')
expected={'cloud':650,'advanced':650,'software':600,'cyber':575,'leadership':575,'math':575,'physics':575}
counts=collections.Counter(x['domain'] for x in L)
if dict(counts)!=expected: errors.append('domain counts '+repr(dict(counts)))
for x in L:
    if x.get('verification',{}).get('status')!='verified': errors.append(x['id']+': not verified')
    if not x.get('verifiedClaims'): errors.append(x['id']+': missing verified claim')
    if not x.get('references'): errors.append(x['id']+': missing evidence')
    for r in x.get('references',[]):
        u=urllib.parse.urlparse(r[1])
        if u.scheme!='https' or not u.netloc: errors.append(x['id']+': invalid evidence URL')
    for k in ('prereq','related'):
        for y in x.get(k,[]):
            if y not in idset: errors.append(x['id']+': bad '+k+' '+y)
    q=x.get('quiz')
    if q and (not q.get('options') or not isinstance(q.get('answer'),int) or not 0<=q['answer']<len(q['options'])): errors.append(x['id']+': bad quiz')
for p in D.get('paths',[]):
    if not p.get('lesson_ids'): errors.append('empty path '+p.get('id','?'))
    for y in p.get('lesson_ids',[]):
        if y not in idset: errors.append('path missing '+y)
for g in D.get('glossary',[]):
    if g.get('lesson_id') not in idset: errors.append('glossary missing '+g.get('term','?'))
# all learning pages must exist; no gigantic single-page regression
for name in ['learn.html','learn-browse.html','learn-paths.html','learn-practice.html','learn-labs.html','learn-glossary.html','learn-map.html','learn-mastery.html','learn-verify.html']:
    if not (P/name).exists(): errors.append('missing page '+name)
# duplicate IDs
for f in P.glob('*.html'):
    t=f.read_text(encoding='utf-8'); xs=re.findall(r'\bid=["\']([^"\']+)',t); c=collections.Counter(xs); d=[k for k,v in c.items() if v>1]
    if d: errors.append(f.name+': duplicate HTML IDs '+repr(d[:5]))
try: subprocess.run(['node','--check',str(P/'knowledge.js')],check=True,capture_output=True,text=True)
except Exception as e: errors.append('JS syntax '+str(e))
M=json.loads((P/'verification-manifest.json').read_text(encoding='utf-8'))
if M.get('version')!='0.9.0' or M.get('count')!=4200 or len(M.get('records',[]))!=4200: errors.append('manifest mismatch')
if len(D.get('glossary',[]))<700: errors.append('glossary unexpectedly small')
if sum(1 for x in L if x.get('kind')=='Lab')<1500: errors.append('not enough labs')
print('VALIDATION', 'PASS' if not errors else 'FAIL')
print('lessons',len(L),'domains',dict(counts),'paths',len(D.get('paths',[])),'glossary',len(D.get('glossary',[])),'labs',sum(1 for x in L if x.get('kind')=='Lab'),'model_interactive',sum(bool(x.get('interactive')) for x in L),'lab_or_model',sum(1 for x in L if x.get('interactive') or x.get('kind')=='Lab'))
if errors:
    print('\n'.join('ERROR: '+e for e in errors[:100])); sys.exit(1)
''',encoding='utf-8')
r=subprocess.run([sys.executable,str(validate)],capture_output=True,text=True)
print(r.stdout); print(r.stderr,file=sys.stderr)
if r.returncode: raise SystemExit(r.returncode)
(OUT/'VALIDATION_v0.9.0.txt').write_text('JOSHUA RANDALL KNOWLEDGE PLATFORM — v0.9.0 VALIDATION\n\n'+r.stdout+'\nAdditional checks: JavaScript syntax; relationships; paths; glossary links; verification manifest; duplicate HTML IDs; multi-page Learn architecture.\n',encoding='utf-8')

# Static HTTP smoke test of all learning pages.
import http.server,socketserver,threading,time,urllib.request
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
cwd=Path.cwd()
try:
    import os; os.chdir(P)
    server=socketserver.TCPServer(('127.0.0.1',0),Quiet); port=server.server_address[1]
    th=threading.Thread(target=server.serve_forever,daemon=True); th.start()
    for name in ['learn.html','learn-browse.html','learn-paths.html','learn-practice.html','learn-labs.html','learn-glossary.html','learn-map.html','learn-mastery.html','learn-verify.html','knowledge-data.js','knowledge.js','knowledge.css']:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/{name}',timeout=3) as resp:
            if resp.status!=200: raise RuntimeError(name+' HTTP '+str(resp.status))
    server.shutdown(); server.server_close()
finally:
    os.chdir(cwd)

# Zip integrity.
if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in OUT.rglob('*'):
        if f.is_file(): z.write(f,Path(OUT.name)/f.relative_to(OUT))
with zipfile.ZipFile(ZIP) as z:
    bad=z.testzip(); assert bad is None,bad
print('ZIP',ZIP,ZIP.stat().st_size)
print('FINAL',len(D['lessons']),dict(counts),'paths',len(D['paths']),'glossary',len(D['glossary']),'labs',labs,'interactive workflows',interactive_workflows)
