from pathlib import Path
import json,re,csv,copy,shutil,zipfile,collections,urllib.parse,subprocess,sys,html
SRC_ROOT=Path('/mnt/data/kp_v08_work/Joshua_Randall_Knowledge_Platform_v0.7.0')
OUT=Path('/mnt/data/Joshua_Randall_Knowledge_Platform_v0.8.0')
if OUT.exists(): shutil.rmtree(OUT)
shutil.copytree(SRC_ROOT,OUT)
P=OUT/'public_html'; REVIEW='2026-09-07'

def load_js(path):
    s=Path(path).read_text(encoding='utf-8'); st=s.index('{');d=0;ins=False;esc=False
    for i,ch in enumerate(s[st:],st):
        if ins:
            if esc: esc=False
            elif ch=='\\':esc=True
            elif ch=='"':ins=False
        else:
            if ch=='"':ins=True
            elif ch=='{':d+=1
            elif ch=='}':
                d-=1
                if d==0:return json.loads(s[st:i+1])
    raise RuntimeError('JSON not found')
D=load_js(P/'knowledge-data.js')
assert D['version']=='0.7.0'

# Exact primary / authoritative sources used by this release.
SRC={
'python_tutorial':('Python 3 Documentation — The Python Tutorial','https://docs.python.org/3/tutorial/index.html'),
'python_types':('Python 3 Documentation — Built-in Types','https://docs.python.org/3/library/stdtypes.html'),
'python_errors':('Python 3 Documentation — Errors and Exceptions','https://docs.python.org/3/tutorial/errors.html'),
'python_classes':('Python 3 Documentation — Classes, Iterators, Generators','https://docs.python.org/3/tutorial/classes.html'),
'python_asyncio':('Python 3 Documentation — asyncio','https://docs.python.org/3/library/asyncio.html'),
'python_functional':('Python 3 Documentation — Functional Programming HOWTO','https://docs.python.org/3/howto/functional.html'),
'git_glossary':('Git Documentation — gitglossary','https://git-scm.com/docs/gitglossary'),
'git_branch':('Git Documentation — git-branch','https://git-scm.com/docs/git-branch'),
'git_merge':('Git Documentation — git-merge','https://git-scm.com/docs/git-merge'),
'git_rebase':('Git Documentation — git-rebase','https://git-scm.com/docs/git-rebase'),
'git_reset':('Git Documentation — git-reset','https://git-scm.com/docs/git-reset'),
'git_revert':('Git Documentation — git-revert','https://git-scm.com/docs/git-revert'),
'git_cherry':('Git Documentation — git-cherry-pick','https://git-scm.com/docs/git-cherry-pick'),
'git_reflog':('Git Documentation — git-reflog','https://git-scm.com/docs/git-reflog'),
'git_fetch':('Git Documentation — git-fetch','https://git-scm.com/docs/git-fetch'),
'git_pull':('Git Documentation — git-pull','https://git-scm.com/docs/git-pull'),
'git_push':('Git Documentation — git-push','https://git-scm.com/docs/git-push'),
'git_stash':('Git Documentation — git-stash','https://git-scm.com/docs/git-stash'),
'git_worktree':('Git Documentation — git-worktree','https://git-scm.com/docs/git-worktree'),
'pg_tutorial':('PostgreSQL Documentation — SQL Tutorial','https://www.postgresql.org/docs/current/tutorial.html'),
'pg_joins':('PostgreSQL Documentation — Table Expressions and Joins','https://www.postgresql.org/docs/current/queries-table-expressions.html'),
'pg_agg':('PostgreSQL Documentation — Aggregate Functions','https://www.postgresql.org/docs/current/functions-aggregate.html'),
'pg_window':('PostgreSQL Documentation — Window Functions','https://www.postgresql.org/docs/current/tutorial-window.html'),
'pg_tx':('PostgreSQL Documentation — Transactions','https://www.postgresql.org/docs/current/tutorial-transactions.html'),
'pg_mvcc':('PostgreSQL Documentation — Concurrency Control','https://www.postgresql.org/docs/current/mvcc.html'),
'pg_index':('PostgreSQL Documentation — Indexes','https://www.postgresql.org/docs/current/indexes.html'),
'pg_explain':('PostgreSQL Documentation — EXPLAIN','https://www.postgresql.org/docs/current/sql-explain.html'),
'pg_constraints':('PostgreSQL Documentation — Constraints','https://www.postgresql.org/docs/current/ddl-constraints.html'),
'pg_with':('PostgreSQL Documentation — WITH Queries','https://www.postgresql.org/docs/current/queries-with.html'),
'pg_json':('PostgreSQL Documentation — JSON Types','https://www.postgresql.org/docs/current/datatype-json.html'),
'pg_arrays':('PostgreSQL Documentation — Arrays','https://www.postgresql.org/docs/current/arrays.html'),
'pg_iso':('PostgreSQL Documentation — Transaction Isolation','https://www.postgresql.org/docs/current/transaction-iso.html'),
'rfc9110':('RFC 9110 — HTTP Semantics','https://www.rfc-editor.org/rfc/rfc9110'),
'rfc9111':('RFC 9111 — HTTP Caching','https://www.rfc-editor.org/rfc/rfc9111'),
'nist_csf':('NIST — Cybersecurity Framework 2.0','https://www.nist.gov/publications/nist-cybersecurity-framework-csf-20'),
'nist_csf_faq':('NIST — Cybersecurity Framework FAQs','https://www.nist.gov/cyberframework/faqs'),
'nist_63b':('NIST SP 800-63B — Authentication and Authenticator Management','https://pages.nist.gov/800-63-4/sp800-63b.html'),
'nist_207':('NIST SP 800-207 — Zero Trust Architecture','https://csrc.nist.gov/pubs/sp/800/207/final'),
'nist_61':('NIST SP 800-61 Rev. 3 — Incident Response Recommendations','https://csrc.nist.gov/pubs/sp/800/61/r3/final'),
'nist_53':('NIST SP 800-53 Rev. 5 — Security and Privacy Controls','https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final'),
'nist_dr':('NIST SP 800-34 Rev. 1 — Contingency Planning Guide','https://csrc.nist.gov/pubs/sp/800/34/r1/final'),
'cisa_ransom':('CISA — #StopRansomware Guide','https://www.cisa.gov/stopransomware/ransomware-guide'),
'owasp_authz':('OWASP Cheat Sheet — Authorization','https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html'),
'owasp_sql':('OWASP Cheat Sheet — SQL Injection Prevention','https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html'),
'owasp_xss':('OWASP Cheat Sheet — Cross Site Scripting Prevention','https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html'),
'owasp_ssrf':('OWASP Cheat Sheet — SSRF Prevention','https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html'),
'owasp_session':('OWASP Cheat Sheet — Session Management','https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html'),
'owasp_secrets':('OWASP Cheat Sheet — Secrets Management','https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html'),
'owasp_threat':('OWASP Cheat Sheet — Threat Modeling','https://cheatsheetseries.owasp.org/cheatsheets/Threat_Modeling_Cheat_Sheet.html'),
'sre_slo':('Google SRE Book — Service Level Objectives','https://sre.google/sre-book/service-level-objectives/'),
'sre_monitor':('Google SRE Book — Monitoring Distributed Systems','https://sre.google/sre-book/monitoring-distributed-systems/'),
'sre_toil':('Google SRE Book — Eliminating Toil','https://sre.google/sre-book/eliminating-toil/'),
'sre_post':('Google SRE Book — Postmortem Culture','https://sre.google/sre-book/postmortem-culture/'),
'sre_incident':('Google SRE Workbook — Incident Response','https://sre.google/workbook/incident-response/'),
'sre_cascade':('Google SRE Book — Addressing Cascading Failures','https://sre.google/sre-book/addressing-cascading-failures/'),
'sre_overload':('Google SRE Book — Handling Overload','https://sre.google/sre-book/handling-overload/'),
'openstax_alg':('OpenStax — College Algebra 2e','https://openstax.org/details/books/college-algebra-2e'),
'openstax_calc':('OpenStax — Calculus Volume 1','https://openstax.org/details/books/calculus-volume-1'),
'openstax_stats':('OpenStax — Introductory Statistics','https://openstax.org/details/books/introductory-statistics'),
'mit_la':('MIT OpenCourseWare — 18.06 Linear Algebra','https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/'),
'nist_dlmf':('NIST Digital Library of Mathematical Functions','https://dlmf.nist.gov/'),
'phys1':('OpenStax — University Physics Volume 1','https://openstax.org/details/books/university-physics-volume-1'),
'phys2':('OpenStax — University Physics Volume 2','https://openstax.org/details/books/university-physics-volume-2'),
'phys3':('OpenStax — University Physics Volume 3','https://openstax.org/details/books/university-physics-volume-3'),
}

def refs(keys): return [list(SRC[k]) for k in keys]
def norm(s): return re.sub(r'[^a-z0-9]+',' ',s.lower()).strip()
def slug(s): return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')
ids={l['id'] for l in D['lessons']}; titles={norm(l['title']) for l in D['lessons']}; new=[]; concept_ids={}

def add_obj(domain,category,title,fact,keys,diff='Foundation',kind='Lesson',interactive=None,version=False,activity=None,misconception=None):
    nt=norm(title)
    if nt in titles: return None
    lid=f'{domain}-v08-{slug(title)[:72]}'; n=2
    while lid in ids: lid=f'{domain}-v08-{slug(title)[:66]}-{n}'; n+=1
    activity=activity or f'Use the cited evidence to restate the rule for {title.lower()} in your own words, then construct one example that satisfies it and one counterexample that does not.'
    summary=fact
    explanation=(f'{fact}\n\nThis object is deliberately narrow: it teaches one claim that can be checked directly against the cited primary or authoritative source. '
                 f'The goal is not memorizing a slogan; it is recognizing the condition under which the documented behavior applies and being able to verify it independently.')
    why=f'Understanding {title.lower()} helps you predict system behavior, choose the right abstraction, and troubleshoot from evidence instead of assumption.' if domain in ('software','cyber','leadership') else f'Understanding {title.lower()} provides a reusable foundation for solving later problems and checking results quantitatively.'
    example=activity
    takeaway=fact
    wrong1='The cited source states that this behavior is always the exact opposite.'
    wrong2='This concept has no defined conditions and cannot be verified from documentation or calculation.'
    wrong3='The behavior is determined only by personal preference, not by the documented rule or model.'
    l={'id':lid,'domain':domain,'category':category,'title':title,'summary':summary,'explanation':explanation,'why':why,'example':example,'takeaway':takeaway,
       'difficulty':diff,'kind':kind,'minutes':14 if kind=='Lab' else 9,'tags':list(dict.fromkeys([slug(title).replace('-',' '),category.lower(),domain])),
       'interactive':interactive,'prereq':[],'related':[],'quiz':{'q':'Which statement is supported by the evidence for this learning object?','options':[fact,wrong1,wrong2,wrong3],'answer':0,'explanation':fact},
       'misconception':misconception,'objectives':[f'Explain {title} accurately', 'Verify the key claim against an authoritative source', 'Apply the claim to a concrete example'],
       'references':refs(keys),'verification':{'status':'verified','reviewed':REVIEW,'method':'Cross-checked against a primary standard, official project/vendor documentation, government guidance, or open university textbook.','claimType':'Narrow documented claim','sourceCount':len(keys)},
       'versionSensitive':bool(version),'verifiedClaims':[fact]}
    D['lessons'].append(l);ids.add(lid);titles.add(nt);new.append(l);return lid

def add_pair(domain,category,concept,fact,keys,diff='Foundation',interactive=None,version=False,activity=None,misconception=None):
    deep=add_obj(domain,category,f'Deep Dive: {concept}',fact,keys,diff,'Lesson',interactive,version,activity,misconception)
    lab=add_obj(domain,category,f'Evidence Lab: {concept}',fact,keys,diff,'Lab',interactive,version,
        (activity or f'Before opening the source, predict the exact rule for {concept.lower()}. Then open the evidence, find the supporting section, and test your prediction with a concrete example. Record what changed between your prediction and the documented behavior.'),misconception)
    concept_ids[(domain,concept)]=[x for x in (deep,lab) if x]

# SOFTWARE ENGINEERING — 60 concepts / 120 learning objects
software=[
('Programming','Python List Comprehensions','A Python list comprehension constructs a new list from an expression and one or more for/if clauses.',['python_functional'],'Foundation','complexity'),
('Programming','Python Generator Expressions','A Python generator expression returns an iterator and computes values as they are requested instead of materializing the entire result list at once.',['python_functional'],'Intermediate','queue'),
('Programming','Python Generators and yield','A Python generator function uses yield to produce values and preserves its execution state between resumptions.',['python_classes'],'Intermediate','queue'),
('Programming','Python Iterator Protocol','An iterator supplies successive values through __next__() and signals exhaustion by raising StopIteration.',['python_classes'],'Intermediate',None),
('Programming','Python Context Managers','A Python context manager defines runtime context behavior through __enter__() and __exit__(), commonly used by the with statement for setup and cleanup.',['python_types'],'Intermediate',None),
('Programming','Python Exception Handling','Python try/except statements allow code to handle selected exceptions raised during execution.',['python_errors'],'Foundation',None),
('Programming','Python finally Clause','A finally clause is executed when leaving a try statement whether or not an exception occurred, subject to process termination and similar external conditions.',['python_errors'],'Intermediate',None),
('Programming','Python Exception Chaining','Python raise ... from ... explicitly records one exception as the direct cause of another.',['python_errors'],'Intermediate',None),
('Programming','Python Modules','A Python module is a file containing Python definitions and statements that can be imported by other code.',['python_tutorial'],'Foundation',None),
('Programming','Python Packages','Python packages structure module namespaces so related modules can be organized hierarchically.',['python_tutorial'],'Foundation',None),
('Programming','Python Dictionaries','Python dictionaries are mutable mappings from hashable keys to values.',['python_types'],'Foundation',None),
('Programming','Python Sets','Python sets are unordered collections of distinct hashable objects and support mathematical set operations such as union and intersection.',['python_types'],'Foundation','logic'),
('Programming','Python Tuples','Python tuples are immutable sequence types.',['python_types'],'Foundation',None),
('Programming','Python Lists','Python lists are mutable sequence types.',['python_types'],'Foundation',None),
('Programming','Python Coroutine Functions','Calling a function defined with async def produces a coroutine object whose execution can be driven by an event loop.',['python_asyncio'],'Intermediate','queue'),
('Programming','Python await','The await expression suspends execution of the surrounding coroutine until the awaited object can produce a result.',['python_asyncio'],'Intermediate','queue'),
('Programming','Python asyncio Tasks','An asyncio Task schedules a coroutine to run concurrently on an event loop.',['python_asyncio'],'Intermediate','roundrobin'),
('Programming','Python Dictionary Comprehensions','Python supports dictionary comprehensions that construct dictionaries from expression-driven key-value pairs.',['python_tutorial'],'Intermediate',None),
('Programming','Python Set Comprehensions','Python supports set comprehensions that construct sets from expression-driven iteration.',['python_tutorial'],'Intermediate',None),
('Programming','Python Generator State','A suspended Python generator retains local variables and its instruction position so execution can resume where it yielded.',['python_classes'],'Advanced','queue'),
('DevOps','Git Commit','A Git commit records a project state and references its parent commit or commits, forming commit history.',['git_glossary'],'Foundation','queue'),
('DevOps','Git Branch','A Git branch is a named line of development represented by a reference that normally advances as new commits are created.',['git_branch','git_glossary'],'Foundation','queue'),
('DevOps','Git HEAD','HEAD identifies the commit currently checked out, usually indirectly through the current branch reference.',['git_glossary'],'Foundation',None),
('DevOps','Git Merge','git merge incorporates changes from named commits into the current branch and may create a merge commit when histories require it.',['git_merge'],'Intermediate','queue'),
('DevOps','Git Rebase','git rebase replays selected commits on top of another base and updates the branch to the replayed history.',['git_rebase'],'Intermediate','queue'),
('DevOps','Git Reset','git reset can move the current branch tip and, depending on mode, also update the index and working tree.',['git_reset'],'Intermediate',None),
('DevOps','Git Revert','git revert records a new commit that reverses the effect of an earlier commit rather than deleting the earlier commit from history.',['git_revert'],'Intermediate',None),
('DevOps','Git Cherry-Pick','git cherry-pick applies the changes introduced by one or more existing commits and records new commits on the current branch.',['git_cherry'],'Intermediate',None),
('DevOps','Git Reflog','Git reflogs record updates to local references, making prior reference values discoverable for recovery and inspection.',['git_reflog'],'Intermediate','queue'),
('DevOps','Git Fetch','git fetch downloads objects and refs from another repository without automatically integrating them into the current branch.',['git_fetch'],'Foundation',None),
('DevOps','Git Pull','git pull first fetches from another repository and then integrates the fetched branch according to the configured pull behavior.',['git_pull'],'Foundation',None),
('DevOps','Git Push','git push updates refs in a remote repository and transfers objects required for those updates.',['git_push'],'Foundation',None),
('DevOps','Git Stash','git stash records selected working-tree and index changes so the worktree can be returned toward a clean state and the changes reapplied later.',['git_stash'],'Intermediate',None),
('DevOps','Git Worktree','git worktree allows multiple working trees to be attached to one repository so different branches or commits can be checked out simultaneously.',['git_worktree'],'Intermediate',None),
('DevOps','Git Remote','A Git remote is a named configuration entry that refers to another repository and its fetch/push behavior.',['git_glossary'],'Foundation',None),
('Databases','SQL INNER JOIN','An INNER JOIN returns joined rows that satisfy its join condition.',['pg_joins'],'Foundation','sqljoin'),
('Databases','SQL LEFT OUTER JOIN','A LEFT OUTER JOIN preserves every row from the left input and supplies null values for unmatched columns from the right input.',['pg_joins'],'Intermediate','sqljoin'),
('Databases','SQL CROSS JOIN','A CROSS JOIN produces the Cartesian product of its two inputs.',['pg_joins'],'Foundation','sqljoin'),
('Databases','SQL Aggregate Functions','Aggregate functions compute one result from a set of input values, such as count, sum, average, minimum, or maximum.',['pg_agg'],'Foundation','sqljoin'),
('Databases','SQL GROUP BY','GROUP BY combines rows sharing the same grouping values so aggregate calculations can be performed per group.',['pg_tutorial'],'Foundation','sqljoin'),
('Databases','SQL HAVING','HAVING filters grouped rows after grouping, while WHERE filters rows before grouping.',['pg_tutorial'],'Intermediate','sqljoin'),
('Databases','SQL Window Functions','A window function computes across a set of related rows while retaining a result row for each input row.',['pg_window'],'Intermediate','sqljoin'),
('Databases','Database Transaction','A PostgreSQL transaction groups multiple statements into a single all-or-nothing unit using BEGIN and COMMIT, with ROLLBACK available to abandon the transaction.',['pg_tx'],'Foundation','queue'),
('Databases','PostgreSQL MVCC','PostgreSQL uses multiversion concurrency control so statements can work with database snapshots while concurrent transactions create new row versions.',['pg_mvcc'],'Advanced','queue'),
('Databases','PostgreSQL Index','A PostgreSQL index is a separate data structure that can speed retrieval for supported query patterns at the cost of additional storage and maintenance work.',['pg_index'],'Intermediate','btree'),
('Databases','PostgreSQL EXPLAIN','EXPLAIN displays the query plan selected by the PostgreSQL planner without executing the query unless an execution option such as ANALYZE is requested.',['pg_explain'],'Intermediate','btree'),
('Databases','PostgreSQL EXPLAIN ANALYZE','EXPLAIN ANALYZE executes the query and reports actual run-time measurements in addition to plan information.',['pg_explain'],'Advanced','btree'),
('Databases','SQL Foreign Key','A foreign key constraint requires referencing column values to match rows in a referenced table, subject to the declared referential actions.',['pg_constraints'],'Foundation','rbac'),
('Databases','SQL UNIQUE Constraint','A UNIQUE constraint requires the constrained column set to be unique among table rows according to PostgreSQL uniqueness semantics.',['pg_constraints'],'Foundation',None),
('Databases','SQL Primary Key','A PostgreSQL primary key combines uniqueness with non-null requirements and identifies rows of a table.',['pg_constraints'],'Foundation',None),
('Databases','SQL CHECK Constraint','A CHECK constraint requires a Boolean condition to hold for inserted or updated rows, except that SQL null semantics can make the expression unknown rather than false.',['pg_constraints'],'Intermediate','logic'),
('Databases','SQL WITH Query','A WITH clause defines named auxiliary statements that can be referenced by the main query.',['pg_with'],'Intermediate','queue'),
('Databases','Recursive WITH Query','A recursive WITH query can refer to its own output through a non-recursive seed term and a recursive term evaluated iteratively.',['pg_with'],'Advanced','queue'),
('Databases','PostgreSQL JSONB','PostgreSQL jsonb stores JSON data in a decomposed binary representation that supports indexing and efficient processing but does not preserve insignificant whitespace or key order.',['pg_json'],'Intermediate','btree'),
('Databases','PostgreSQL Arrays','PostgreSQL supports variable-length multidimensional arrays as column values.',['pg_arrays'],'Intermediate',None),
('Databases','Transaction Isolation Levels','PostgreSQL supports the SQL transaction isolation levels Read Committed, Repeatable Read, and Serializable; Read Uncommitted behaves like Read Committed.',['pg_iso'],'Advanced','queue'),
('APIs','HTTP Safe Methods','HTTP defines GET, HEAD, OPTIONS, and TRACE as safe methods because their defined semantics are essentially read-only.',['rfc9110'],'Foundation','api'),
('APIs','HTTP Idempotent Methods','HTTP defines a method as idempotent when multiple identical requests are intended to have the same effect as one such request; PUT, DELETE, and safe methods are idempotent by specification.',['rfc9110'],'Intermediate','api'),
('APIs','HTTP GET','The HTTP GET method requests transfer of a current selected representation of the target resource.',['rfc9110'],'Foundation','api'),
('APIs','HTTP HEAD','HTTP HEAD is identical to GET except the server must not send content in the response.',['rfc9110'],'Foundation','api'),
('APIs','HTTP POST','HTTP POST asks the target resource to process the enclosed representation according to the resource-specific semantics.',['rfc9110'],'Foundation','api'),
]
assert len(software)==61,len(software)
for i,(cat,c,f,k,d,inter) in enumerate(software): add_pair('software',cat,c,f,k,d,inter,True)

# CYBERSECURITY — 50 concepts / 100 objects
cyber=[
('Governance','CSF Govern Function','NIST CSF 2.0 adds Govern as a core function for establishing, communicating, and monitoring the organization’s cybersecurity risk management strategy, expectations, and policy.',['nist_csf','nist_csf_faq'],'Foundation','riskmatrix'),
('Risk','CSF Identify Function','The CSF Identify function focuses on understanding the organization’s current cybersecurity risks.',['nist_csf_faq'],'Foundation','riskmatrix'),
('Foundations','CSF Protect Function','The CSF Protect function covers safeguards used to manage cybersecurity risks.',['nist_csf_faq'],'Foundation','cia'),
('Detection','CSF Detect Function','The CSF Detect function covers finding and analyzing possible cybersecurity attacks and compromises.',['nist_csf_faq'],'Foundation','incident'),
('Detection','CSF Respond Function','The CSF Respond function covers taking action regarding a detected cybersecurity incident.',['nist_csf_faq'],'Foundation','incident'),
('Recovery','CSF Recover Function','The CSF Recover function covers restoring assets and operations affected by a cybersecurity incident.',['nist_csf_faq'],'Foundation','incident'),
('Governance','CSF Core Outcomes','The NIST CSF Core expresses cybersecurity outcomes through Functions, Categories, and Subcategories rather than prescribing one implementation process.',['nist_csf','nist_csf_faq'],'Intermediate','riskmatrix'),
('Governance','CSF Organizational Profile','A CSF Organizational Profile describes an organization’s current and/or target cybersecurity posture in terms of selected CSF Core outcomes.',['nist_csf'],'Intermediate','riskmatrix'),
('Governance','CSF Tiers','CSF Tiers characterize the rigor of cybersecurity risk governance and management practices and can help provide context about how an organization views and manages risk.',['nist_csf'],'Intermediate','riskmatrix'),
('Risk','Cybersecurity Risk Communication','NIST CSF 2.0 is designed to help organizations understand, assess, prioritize, and communicate cybersecurity risks and desired outcomes.',['nist_csf'],'Foundation','riskmatrix'),
('Identity','Authenticator Assurance Level 1','NIST defines AAL1 as providing some assurance that the claimant controls an authenticator bound to the subscriber account.',['nist_63b'],'Intermediate','rbac'),
('Identity','Authenticator Assurance Level 2','NIST defines AAL2 as requiring proof of possession and control of two distinct authentication factors through secure authentication protocols.',['nist_63b'],'Intermediate','rbac'),
('Identity','Authenticator Assurance Level 3','NIST defines AAL3 as very high confidence and requires a hardware-based authenticator plus verifier-impersonation resistance, with two distinct authentication factors.',['nist_63b'],'Advanced','rbac'),
('Identity','Authentication Factor','An authentication factor is evidence of a distinct type used in authentication, such as something known, possessed, or an inherence characteristic.',['nist_63b'],'Foundation','rbac'),
('Identity','Verifier Impersonation Resistance','Verifier-impersonation-resistant authentication binds the authenticator output to the authenticated verifier channel so a phishing verifier cannot simply replay the authentication on another channel.',['nist_63b'],'Advanced','zerotrust'),
('Identity','Replay Resistance','Replay resistance prevents a valid authenticator output captured from one authentication from being successfully reused for another authentication.',['nist_63b'],'Intermediate','zerotrust'),
('Identity','Authenticator Lifecycle','NIST authentication guidance treats authenticators as lifecycle-managed objects that can be bound, maintained, replaced, and revoked.',['nist_63b'],'Intermediate','rbac'),
('Identity','Reauthentication','NIST authentication guidance requires periodic reauthentication of subscriber sessions according to the applicable assurance level.',['nist_63b'],'Intermediate','rbac'),
('Identity','Protected Authentication Channel','NIST requires authentication exchanges to use authenticated protected channels appropriate to the assurance requirements.',['nist_63b'],'Intermediate','tls'),
('Identity','Memorized Secret','NIST defines a memorized secret as a value intended to be chosen and memorized by the user and used as a knowledge factor.',['nist_63b'],'Foundation','rbac'),
('Architecture','Zero Trust No Implicit Trust','NIST zero trust assumes no implicit trust based solely on physical or network location or asset ownership.',['nist_207'],'Foundation','zerotrust'),
('Architecture','Zero Trust Resource Focus','Zero trust focuses protection on resources rather than treating a network segment as an automatically trusted security boundary.',['nist_207'],'Foundation','zerotrust'),
('Architecture','Zero Trust Policy Decision','NIST zero trust architecture uses policy decision and enforcement components to decide and control access to enterprise resources.',['nist_207'],'Intermediate','zerotrust'),
('Architecture','Zero Trust Continuous Evaluation','Zero trust access decisions use dynamic policy and available information about subject, asset, requested resource, and environment rather than a one-time network-location decision.',['nist_207'],'Intermediate','zerotrust'),
('Architecture','Zero Trust Least Privilege','Zero trust architecture aims to grant the minimum privileges needed for an authorized transaction.',['nist_207'],'Intermediate','zerotrust'),
('Architecture','Zero Trust Authentication and Authorization','Zero trust requires authentication and authorization for resource access rather than assuming traffic inside a perimeter is trusted.',['nist_207'],'Foundation','zerotrust'),
('Architecture','Zero Trust Policy Engine','In NIST’s logical zero-trust model, the policy engine makes the ultimate decision to grant, deny, or revoke access to a resource.',['nist_207'],'Advanced','zerotrust'),
('Architecture','Zero Trust Policy Administrator','In NIST’s logical zero-trust model, the policy administrator establishes or shuts down the communication path based on the policy engine decision.',['nist_207'],'Advanced','zerotrust'),
('Architecture','Zero Trust Policy Enforcement Point','The policy enforcement point enables, monitors, and ultimately terminates connections between subjects and enterprise resources according to policy decisions.',['nist_207'],'Advanced','zerotrust'),
('Risk','Threat Modeling','Threat modeling is a structured process for identifying threats, attack paths, security assumptions, and mitigations in a system design.',['owasp_threat'],'Foundation','threat'),
('Application Security','SQL Injection Parameterization','OWASP recommends parameterized queries or prepared statements as a primary defense against SQL injection because data values are bound separately from SQL code.',['owasp_sql'],'Foundation','threat'),
('Application Security','XSS Output Encoding','OWASP recommends context-appropriate output encoding so untrusted data is rendered as data rather than interpreted as executable browser markup or script.',['owasp_xss'],'Intermediate','threat'),
('Application Security','XSS Dangerous Contexts','OWASP identifies browser contexts where untrusted data cannot be made safe with ordinary output encoding alone and should not be placed there.',['owasp_xss'],'Advanced','threat'),
('Application Security','SSRF URL Validation','OWASP SSRF guidance recommends validating and constraining server-side destinations rather than allowing unrestricted attacker-controlled network targets.',['owasp_ssrf'],'Intermediate','firewall'),
('Identity','Authorization Deny by Default','OWASP authorization guidance recommends denying access by default unless a request is explicitly permitted.',['owasp_authz'],'Foundation','rbac'),
('Identity','Authorization Every Request','OWASP authorization guidance recommends validating permissions on every request rather than relying solely on client-side state or prior checks.',['owasp_authz'],'Intermediate','rbac'),
('Identity','Session Identifier Security','OWASP session-management guidance treats session identifiers as security-sensitive values that must be protected from disclosure, prediction, and fixation.',['owasp_session'],'Intermediate','rbac'),
('Identity','Session Expiration','OWASP recommends server-side session expiration controls so old or inactive authenticated sessions do not remain valid indefinitely.',['owasp_session'],'Intermediate','rbac'),
('Application Security','Secrets Centralization','OWASP secrets-management guidance recommends centralized lifecycle controls for storing, distributing, rotating, and auditing secrets.',['owasp_secrets'],'Intermediate','zerotrust'),
('Application Security','Secret Rotation','Secret rotation replaces a credential or key with a new value and retires the old one according to the system’s lifecycle policy.',['owasp_secrets'],'Intermediate','zerotrust'),
('Detection','Incident Response Integration','NIST SP 800-61 Rev. 3 integrates incident response into broader cybersecurity risk management rather than treating incidents as an isolated technical activity.',['nist_61'],'Intermediate','incident'),
('Recovery','Ransomware Backups','CISA recommends maintaining backups as part of ransomware resilience and protecting backup systems so attackers cannot easily encrypt or delete them with production data.',['cisa_ransom'],'Foundation','incident'),
('Recovery','Ransomware Recovery Testing','CISA ransomware guidance emphasizes that backups should be tested so organizations know data can actually be restored when needed.',['cisa_ransom'],'Intermediate','incident'),
('Governance','NIST Access Control Family','NIST SP 800-53 includes an Access Control control family for managing system access and permissions.',['nist_53'],'Foundation','rbac'),
('Governance','NIST Audit and Accountability Family','NIST SP 800-53 includes an Audit and Accountability control family covering event logging, review, and accountability mechanisms.',['nist_53'],'Foundation','incident'),
('Governance','NIST Configuration Management Family','NIST SP 800-53 includes a Configuration Management control family covering baselines, change control, settings, and configuration governance.',['nist_53'],'Foundation','riskmatrix'),
('Governance','NIST Identification and Authentication Family','NIST SP 800-53 includes an Identification and Authentication control family covering identities and authentication mechanisms.',['nist_53'],'Foundation','rbac'),
('Governance','NIST Incident Response Family','NIST SP 800-53 includes an Incident Response control family covering preparation, handling, testing, monitoring, and assistance.',['nist_53'],'Foundation','incident'),
('Governance','NIST System and Communications Protection Family','NIST SP 800-53 includes a System and Communications Protection control family addressing protection of information flows and communications.',['nist_53'],'Foundation','firewall'),
]
assert len(cyber)==49,len(cyber)
for cat,c,f,k,d,inter in cyber: add_pair('cyber',cat,c,f,k,d,inter,True)

# LEADERSHIP & IT MANAGEMENT — 40 concepts / 80 objects
lead=[
('Reliability','Service Level Indicator','A service level indicator is a quantitative measure of some aspect of service level, such as availability, latency, or error rate.',['sre_slo'],'Foundation','errorbudget'),
('Reliability','Service Level Objective','A service level objective is a target value or range for a service level measured by an SLI.',['sre_slo'],'Foundation','errorbudget'),
('Reliability','Error Budget','An error budget is the amount of unreliability permitted by an SLO over its measurement window; for a 99.9% availability objective, the nominal unavailable fraction is 0.1%.',['sre_slo'],'Intermediate','errorbudget'),
('Reliability','Four Golden Signals','Google SRE identifies latency, traffic, errors, and saturation as four golden signals for monitoring a service.',['sre_monitor'],'Foundation','errorbudget'),
('Reliability','Latency Distribution','Service latency should be considered as a distribution because averages can hide slow-tail behavior experienced by some requests.',['sre_monitor'],'Intermediate','errorbudget'),
('Reliability','Traffic Signal','In SRE monitoring, traffic represents demand being placed on the system, such as requests per second or transactions per second.',['sre_monitor'],'Foundation','errorbudget'),
('Reliability','Error Signal','In SRE monitoring, errors represent requests or operations that fail explicitly, return incorrect content, or violate policy.',['sre_monitor'],'Foundation','errorbudget'),
('Reliability','Saturation Signal','In SRE monitoring, saturation describes how full or constrained a service resource is, often indicating proximity to capacity limits.',['sre_monitor'],'Foundation','errorbudget'),
('Operations','Toil','Google SRE defines toil as operational work that is manual, repetitive, automatable, tactical, lacks enduring value, and scales linearly as service demand grows.',['sre_toil'],'Foundation','toilcalc'),
('Operations','Toil Reduction','Reducing toil means replacing repeated manual operational work with engineering, automation, or process improvements that create enduring value.',['sre_toil'],'Intermediate','toilcalc'),
('Operations','Blameless Postmortem','Google SRE advocates postmortems that focus on learning from contributing conditions rather than punishing individuals for good-faith actions.',['sre_post'],'Foundation','incident'),
('Operations','Postmortem Action Items','A useful postmortem records concrete follow-up actions so identified contributing conditions can be reduced or monitored.',['sre_post'],'Intermediate','incident'),
('Incidents','Incident Coordination','Google SRE incident response separates coordination from hands-on technical work so someone maintains an overall view, priorities, and communication.',['sre_incident'],'Intermediate','incident'),
('Incidents','Incident Communication','Incident response benefits from a designated communication role that keeps stakeholders informed without distracting responders from technical work.',['sre_incident'],'Intermediate','incident'),
('Incidents','Incident Operations Role','An incident response structure can assign an operations lead to direct technical mitigation while another role coordinates the incident.',['sre_incident'],'Intermediate','incident'),
('Reliability','Cascading Failure','A cascading failure occurs when failure or overload in one component increases pressure on other components, causing additional failures.',['sre_cascade'],'Intermediate','incident'),
('Capacity','Load Shedding','Load shedding intentionally rejects or degrades some work to prevent overload from causing broader service failure.',['sre_overload'],'Intermediate','loadbalancer'),
('Capacity','Overload Protection','Overload protection aims to keep a service within a controllable operating region when incoming demand exceeds available capacity.',['sre_overload'],'Intermediate','loadbalancer'),
('Recovery','Business Impact Analysis','NIST contingency planning uses a business impact analysis to identify mission/business processes, disruption impacts, recovery priorities, and resource requirements.',['nist_dr'],'Foundation','riskmatrix'),
('Recovery','Recovery Time Objective','A recovery time objective is the target time for restoring a system or service after a disruption.',['nist_dr'],'Foundation','incident'),
('Recovery','Recovery Point Objective','A recovery point objective expresses the point in time to which data must be recovered after an interruption, limiting tolerable data loss.',['nist_dr'],'Foundation','incident'),
('Recovery','Contingency Plan','A contingency plan documents strategies and procedures for restoring information systems and operations after disruption.',['nist_dr'],'Foundation','incident'),
('Recovery','Contingency Plan Testing','NIST contingency planning calls for testing, training, and exercises so recovery procedures and responsibilities are validated before an actual disruption.',['nist_dr'],'Intermediate','incident'),
('Governance','Cybersecurity Governance','NIST CSF 2.0 places cybersecurity governance alongside other enterprise risks and expects strategy, policy, roles, responsibilities, and oversight to be established and monitored.',['nist_csf'],'Foundation','riskmatrix'),
('Governance','Cybersecurity Roles and Responsibilities','CSF 2.0 governance outcomes include establishing cybersecurity roles, responsibilities, authorities, and accountability.',['nist_csf'],'Foundation','riskmatrix'),
('Governance','Cybersecurity Policy','CSF 2.0 governance includes establishing, communicating, and enforcing organizational cybersecurity policy.',['nist_csf'],'Foundation','riskmatrix'),
('Governance','Supply Chain Cybersecurity Risk','CSF 2.0 includes cybersecurity supply-chain risk management outcomes as part of the Govern function.',['nist_csf'],'Intermediate','riskmatrix'),
('Strategy','Current Profile','A CSF Current Profile describes the cybersecurity outcomes an organization is currently achieving.',['nist_csf'],'Intermediate','riskmatrix'),
('Strategy','Target Profile','A CSF Target Profile describes the cybersecurity outcomes an organization wants to achieve.',['nist_csf'],'Intermediate','riskmatrix'),
('Strategy','Profile Gap Analysis','Comparing Current and Target CSF Profiles can identify gaps that help prioritize improvements.',['nist_csf'],'Intermediate','riskmatrix'),
('Risk','Risk Prioritization','NIST CSF is intended to support prioritization of cybersecurity outcomes according to organizational context and risk rather than prescribing one universal implementation order.',['nist_csf'],'Intermediate','riskmatrix'),
('Incidents','Incident Response as Risk Management','NIST SP 800-61 Rev. 3 treats incident response as part of cybersecurity risk management throughout organizational operations.',['nist_61'],'Intermediate','incident'),
('Incidents','Incident Lessons Learned','Incident-response improvement uses observations from incidents and exercises to update controls, plans, and risk-management decisions.',['nist_61'],'Intermediate','incident'),
('Operations','Monitoring Symptoms','SRE monitoring should alert on symptoms that directly affect user-visible service behavior rather than only on low-level causes.',['sre_monitor'],'Intermediate','incident'),
('Operations','Monitoring Causes','Cause-oriented telemetry remains useful for diagnosis after a symptom indicates that users or service objectives are being affected.',['sre_monitor'],'Intermediate','incident'),
('Reliability','Availability Objective Tradeoff','An SLO creates an explicit reliability target so engineering teams can reason about tradeoffs between reliability work and feature velocity.',['sre_slo'],'Intermediate','errorbudget'),
('Reliability','100 Percent Reliability Tradeoff','Google SRE argues that 100% reliability is usually the wrong target because achieving the final increments of reliability can impose disproportionate cost and restrict change.',['sre_slo'],'Intermediate','errorbudget'),
('Operations','Automation With Enduring Value','SRE distinguishes engineering work from toil partly by whether the work produces enduring improvements instead of repeated manual effort.',['sre_toil'],'Intermediate','toilcalc'),
('Incidents','Postmortem Learning Culture','A postmortem culture creates organizational memory by documenting what happened, why it happened, what was learned, and what actions will reduce recurrence.',['sre_post'],'Foundation','incident'),
('Capacity','Graceful Degradation Under Overload','When full service cannot be sustained under overload, intentionally degrading lower-priority work can preserve critical functionality.',['sre_overload'],'Advanced','loadbalancer'),
]
assert len(lead)==40,len(lead)
for cat,c,f,k,d,inter in lead: add_pair('leadership',cat,c,f,k,d,inter,True)

# MATHEMATICS — 40 concepts / 80 objects
maths=[
('Algebra','Function Domain','The domain of a function is the set of input values for which the function is defined.',['openstax_alg'],'Foundation',None),
('Algebra','Function Range','The range of a function is the set of output values produced by inputs in its domain.',['openstax_alg'],'Foundation',None),
('Algebra','Linear Function','A linear function has a constant rate of change and can be written in the form f(x)=mx+b.',['openstax_alg'],'Foundation','derivative'),
('Algebra','Quadratic Function','A quadratic function can be written in the form ax²+bx+c with a nonzero quadratic coefficient a.',['openstax_alg'],'Foundation','projectile'),
('Algebra','Exponential Function','An exponential function has the variable in the exponent and models multiplicative change such as f(x)=ab^x.',['openstax_alg'],'Foundation',None),
('Algebra','Logarithm','A logarithm is the inverse operation of exponentiation: log_b(x)=y exactly when b^y=x for valid base b and positive x.',['openstax_alg'],'Foundation',None),
('Algebra','System of Linear Equations','A solution to a system of linear equations satisfies every equation in the system simultaneously.',['openstax_alg'],'Foundation','matrix'),
('Sequences','Arithmetic Sequence','An arithmetic sequence has a constant difference between consecutive terms.',['openstax_alg'],'Foundation',None),
('Sequences','Geometric Sequence','A geometric sequence has a constant ratio between consecutive nonzero terms.',['openstax_alg'],'Foundation',None),
('Calculus','Limit','A limit describes the value a function approaches as its input approaches a specified value, whether or not the function takes that value at the point.',['openstax_calc'],'Foundation','derivative'),
('Calculus','Continuity','A function is continuous at a point when its value exists, its limit exists, and that limit equals the function value.',['openstax_calc'],'Intermediate','derivative'),
('Calculus','Derivative','The derivative is defined as a limit of difference quotients and represents instantaneous rate of change where the limit exists.',['openstax_calc'],'Foundation','derivative'),
('Calculus','Product Rule','The derivative of a product fg is f′g+fg′ where the functions are differentiable.',['openstax_calc'],'Intermediate','derivative'),
('Calculus','Quotient Rule','The derivative of f/g is (f′g−fg′)/g² where g is nonzero and the required derivatives exist.',['openstax_calc'],'Intermediate','derivative'),
('Calculus','Chain Rule','The chain rule differentiates a composition by multiplying the derivative of the outer function by the derivative of the inner function.',['openstax_calc'],'Intermediate','derivative'),
('Calculus','Implicit Differentiation','Implicit differentiation differentiates both sides of an equation with respect to the independent variable while treating the dependent variable as a function.',['openstax_calc'],'Intermediate','derivative'),
('Calculus','Related Rates','Related-rates problems differentiate an equation relating changing quantities so their instantaneous rates can be related.',['openstax_calc'],'Intermediate','derivative'),
('Calculus','Local Extrema','At an interior differentiable local extremum, the derivative is zero; nondifferentiable points and endpoints must also be considered when searching for extrema.',['openstax_calc'],'Intermediate','derivative'),
('Calculus','Mean Value Theorem','For a function continuous on a closed interval and differentiable on its interior, the Mean Value Theorem guarantees a point where the instantaneous slope equals the secant slope across the interval.',['openstax_calc'],'Advanced','derivative'),
('Calculus','Antiderivative','An antiderivative F of f is a function whose derivative is f.',['openstax_calc'],'Foundation','integral'),
('Calculus','Definite Integral','A definite integral can be defined as the limit of Riemann sums and represents signed accumulation over an interval.',['openstax_calc'],'Foundation','integral'),
('Calculus','Fundamental Theorem of Calculus','The Fundamental Theorem of Calculus links accumulation by definite integrals with differentiation and antiderivatives.',['openstax_calc'],'Intermediate','integral'),
('Calculus','Substitution Rule','Integration by substitution changes variables to reverse a chain-rule structure in an integral.',['openstax_calc'],'Intermediate','integral'),
('Linear Algebra','Vector','A vector in R^n is an ordered list of n real components and can be added and scaled componentwise.',['mit_la'],'Foundation','vector'),
('Linear Algebra','Dot Product','The dot product of two real vectors is the sum of products of corresponding components.',['mit_la'],'Foundation','vector'),
('Linear Algebra','Vector Norm','The Euclidean norm of a real vector is the square root of its dot product with itself.',['mit_la'],'Foundation','vector'),
('Linear Algebra','Matrix Multiplication','Matrix multiplication forms each output entry as a row-by-column dot product, and the inner dimensions must agree.',['mit_la'],'Foundation','matrix'),
('Linear Algebra','Linear Combination','A linear combination is a sum of vectors multiplied by scalar coefficients.',['mit_la'],'Foundation','vector'),
('Linear Algebra','Span','The span of a set of vectors is the set of all linear combinations of those vectors.',['mit_la'],'Intermediate','vector'),
('Linear Algebra','Linear Independence','Vectors are linearly independent when the only linear combination producing the zero vector uses all zero coefficients.',['mit_la'],'Intermediate','matrix'),
('Linear Algebra','Basis','A basis for a vector space is a linearly independent set that spans the space.',['mit_la'],'Intermediate','matrix'),
('Linear Algebra','Matrix Rank','The rank of a matrix is the dimension of its column space, equal to the dimension of its row space.',['mit_la'],'Intermediate','matrix'),
('Linear Algebra','Determinant','For a square matrix, a nonzero determinant is equivalent to invertibility.',['mit_la'],'Intermediate','matrix'),
('Linear Algebra','Matrix Inverse','A square matrix A is invertible when there is a matrix A⁻¹ such that AA⁻¹=A⁻¹A=I.',['mit_la'],'Intermediate','matrix'),
('Linear Algebra','Eigenvalue and Eigenvector','A nonzero vector v is an eigenvector of A with eigenvalue λ when Av=λv.',['mit_la'],'Intermediate','matrix'),
('Probability','Conditional Probability','Conditional probability P(A|B) is P(A∩B)/P(B) when P(B)>0.',['openstax_stats'],'Foundation','logic'),
('Probability','Independent Events','Events A and B are independent when P(A∩B)=P(A)P(B).',['openstax_stats'],'Foundation','logic'),
('Probability','Random Variable','A random variable assigns a numerical value to each outcome of a random experiment.',['openstax_stats'],'Foundation',None),
('Probability','Expected Value','The expected value of a discrete random variable is the probability-weighted sum of its possible values when that sum is defined.',['openstax_stats'],'Foundation',None),
('Probability','Variance','Variance measures expected squared deviation from a random variable’s mean.',['openstax_stats'],'Intermediate',None),
]
assert len(maths)==40,len(maths)
for cat,c,f,k,d,inter in maths: add_pair('math',cat,c,f,k,d,inter,False)

# PHYSICS — 35 concepts / 70 objects
physics=[
('Mechanics','Displacement','Displacement is the change in position between an initial and final location and is a vector quantity.',['phys1'],'Foundation','projectile'),
('Mechanics','Average Velocity','Average velocity is displacement divided by the elapsed time interval.',['phys1'],'Foundation','projectile'),
('Mechanics','Instantaneous Velocity','Instantaneous velocity is the derivative of position with respect to time where that derivative exists.',['phys1'],'Foundation','projectile'),
('Mechanics','Acceleration','Acceleration is the rate of change of velocity with respect to time.',['phys1'],'Foundation','projectile'),
('Mechanics','Newton First Law','Newton’s first law states that an object remains at rest or in uniform straight-line motion unless acted on by a net external force.',['phys1'],'Foundation','force'),
('Mechanics','Newton Second Law','Newton’s second law relates net external force to the time rate of change of momentum; for constant mass this becomes F_net=ma.',['phys1'],'Foundation','force'),
('Mechanics','Newton Third Law','Newton’s third law states that interaction forces between two bodies occur in equal-magnitude, opposite-direction pairs acting on different bodies.',['phys1'],'Foundation','force'),
('Mechanics','Free-Body Diagram','A free-body diagram isolates one object and represents the external forces acting on that object.',['phys1'],'Foundation','force'),
('Energy','Work','For a constant force, work is the dot product of force and displacement; more generally work is the line integral of force along the path.',['phys1'],'Foundation','force'),
('Energy','Kinetic Energy','The translational kinetic energy of a nonrelativistic particle of mass m and speed v is 1/2 mv².',['phys1'],'Foundation','projectile'),
('Energy','Work-Energy Theorem','The net work done on a particle equals its change in kinetic energy.',['phys1'],'Intermediate','force'),
('Energy','Gravitational Potential Energy Near Earth','Near Earth’s surface over modest height changes, gravitational potential energy can be represented as mgh relative to a chosen zero level.',['phys1'],'Foundation','projectile'),
('Momentum','Linear Momentum','For a classical particle, linear momentum is mass times velocity, p=mv.',['phys1'],'Foundation','force'),
('Momentum','Impulse-Momentum Theorem','Impulse from a net force over a time interval equals the change in momentum.',['phys1'],'Intermediate','force'),
('Momentum','Momentum Conservation','The total momentum of an isolated system is conserved.',['phys1'],'Intermediate','force'),
('Rotation','Angular Velocity','Angular velocity is the rate of change of angular position with time.',['phys1'],'Foundation','wave'),
('Rotation','Torque','Torque about an origin is the vector cross product of position vector and force, τ=r×F.',['phys1'],'Intermediate','force'),
('Rotation','Angular Momentum','For a particle relative to an origin, angular momentum is L=r×p.',['phys1'],'Intermediate','force'),
('Waves','Simple Harmonic Motion','In ideal simple harmonic motion, the restoring force is proportional to and opposite the displacement from equilibrium.',['phys1'],'Intermediate','wave'),
('Waves','Wave Speed Frequency Wavelength','For a periodic wave, wave speed equals frequency times wavelength, v=fλ.',['phys1'],'Foundation','wave'),
('Waves','Sound Frequency and Pitch','For a fixed propagation medium, changing the frequency changes the wavelength according to v=fλ; perceived pitch generally increases with frequency for audible tones.',['phys1'],'Foundation','wave'),
('Waves','Doppler Effect','The Doppler effect is the observed frequency shift caused by relative motion between a wave source and observer.',['phys1'],'Intermediate','doppler'),
('Thermodynamics','Temperature','Temperature is related to thermal equilibrium and determines the direction of spontaneous heat transfer between bodies in thermal contact.',['phys2'],'Foundation','wave'),
('Thermodynamics','Heat','Heat is energy transferred between systems because of a temperature difference.',['phys2'],'Foundation','wave'),
('Thermodynamics','First Law of Thermodynamics','The first law of thermodynamics is energy conservation applied to thermodynamic systems, relating change in internal energy to heat and work according to the chosen sign convention.',['phys2'],'Intermediate','wave'),
('Electricity','Coulomb Force','The magnitude of the electrostatic force between two point charges is proportional to the product of their charges and inversely proportional to the square of their separation.',['phys2'],'Foundation','force'),
('Electricity','Electric Field','The electric field at a point is defined as the electric force per unit positive test charge in the limit that the test charge does not disturb the source distribution.',['phys2'],'Foundation','force'),
('Electricity','Electric Potential Difference','Electric potential difference is electric potential energy change per unit charge between two points.',['phys2'],'Intermediate','ohm'),
('Electricity','Capacitance','Capacitance is defined as the magnitude of stored charge divided by the potential difference for a capacitor, C=Q/V.',['phys2'],'Foundation','seriescircuit'),
('Electricity','Ohm Law','For an ohmic material or component under conditions where resistance is constant, voltage and current satisfy V=IR.',['phys2'],'Foundation','ohm'),
('Electricity','Kirchhoff Junction Rule','Kirchhoff’s junction rule follows charge conservation: the algebraic sum of currents entering and leaving a junction is zero.',['phys2'],'Intermediate','seriescircuit'),
('Electricity','Kirchhoff Loop Rule','Kirchhoff’s loop rule follows energy conservation: the algebraic sum of potential changes around a closed circuit loop is zero.',['phys2'],'Intermediate','seriescircuit'),
('Magnetism','Magnetic Force on Moving Charge','The magnetic force on a charge q moving with velocity v in magnetic field B is q(v×B).',['phys2'],'Intermediate','magnetic'),
('Magnetism','Faraday Law','Faraday’s law relates the induced electromotive force around a closed loop to the time rate of change of magnetic flux through the loop.',['phys2'],'Intermediate','magnetic'),
('Modern Physics','Photon Energy','The energy of a photon is E=hf, where h is Planck’s constant and f is the photon frequency.',['phys3'],'Foundation','wave'),
]
assert len(physics)==35,len(physics)
for cat,c,f,k,d,inter in physics: add_pair('physics',cat,c,f,k,d,inter,False)

assert len(new)==450, len(new)
# Add learning paths around the newly-expanded domains.
by_title={l['title']:l['id'] for l in D['lessons']}
def lid(title): return by_title.get(title)
def add_path(pid,title,domain,level,desc,concepts):
    ids2=[]
    for c in concepts:
        x=lid('Deep Dive: '+c) or lid(c)
        if x and x not in ids2:ids2.append(x)
    if len(ids2)>=3 and not any(p['id']==pid for p in D['paths']): D['paths'].append({'id':pid,'title':title,'domain':domain,'level':level,'description':desc,'lesson_ids':ids2})
add_path('v08-python-fluency','Python Working Fluency','software','Foundation','Build reliable mental models for Python data, control flow, iteration, generators, and asynchronous work.',[
'Python Lists','Python Dictionaries','Python Sets','Python Iterator Protocol','Python Generators and yield','Python Context Managers','Python Exception Handling','Python asyncio Tasks'])
add_path('v08-git-history','Git History & Recovery','software','Intermediate','Understand how Git moves references, integrates histories, and recovers prior states.',[
'Git Commit','Git Branch','Git Merge','Git Rebase','Git Reflog','Git Reset','Git Revert','Git Cherry-Pick'])
add_path('v08-postgres-querying','PostgreSQL Query Reasoning','software','Intermediate','Move from relational joins into grouping, windows, indexes, and plan analysis.',[
'SQL INNER JOIN','SQL LEFT OUTER JOIN','SQL Aggregate Functions','SQL GROUP BY','SQL HAVING','SQL Window Functions','PostgreSQL Index','PostgreSQL EXPLAIN'])
add_path('v08-http-semantics','HTTP Semantics Core','software','Foundation','Learn the protocol semantics that make web APIs predictable.',[
'HTTP Safe Methods','HTTP Idempotent Methods','HTTP GET','HTTP HEAD','HTTP POST'])
add_path('v08-csf2','NIST CSF 2.0 Core','cyber','Foundation','Learn the six CSF 2.0 functions and how outcomes, profiles, and tiers organize risk conversations.',[
'CSF Govern Function','CSF Identify Function','CSF Protect Function','CSF Detect Function','CSF Respond Function','CSF Recover Function','CSF Core Outcomes','CSF Organizational Profile'])
add_path('v08-digital-auth','Digital Authentication Assurance','cyber','Intermediate','Understand authenticator assurance, factors, protected channels, replay, and phishing resistance.',[
'Authentication Factor','Authenticator Assurance Level 1','Authenticator Assurance Level 2','Authenticator Assurance Level 3','Replay Resistance','Verifier Impersonation Resistance'])
add_path('v08-zero-trust','Zero Trust Architecture','cyber','Intermediate','Follow the NIST zero-trust model from assumptions to policy decisions and enforcement.',[
'Zero Trust No Implicit Trust','Zero Trust Resource Focus','Zero Trust Authentication and Authorization','Zero Trust Policy Engine','Zero Trust Policy Administrator','Zero Trust Policy Enforcement Point'])
add_path('v08-appsec-defenses','Application Security Defenses','cyber','Intermediate','Connect threat modeling with authorization, injection, XSS, SSRF, sessions, and secrets.',[
'Threat Modeling','Authorization Deny by Default','SQL Injection Parameterization','XSS Output Encoding','SSRF URL Validation','Session Identifier Security','Secrets Centralization'])
add_path('v08-sre-foundations','SRE Reliability Foundations','leadership','Foundation','Learn the measurements and operational ideas that connect reliability targets to daily engineering.',[
'Service Level Indicator','Service Level Objective','Error Budget','Four Golden Signals','Toil','Blameless Postmortem'])
add_path('v08-incident-leadership','Incident Leadership','leadership','Intermediate','Coordinate incidents, communicate clearly, learn from failures, and prevent cascades.',[
'Incident Coordination','Incident Communication','Incident Operations Role','Cascading Failure','Postmortem Action Items','Postmortem Learning Culture'])
add_path('v08-recovery-leadership','Recovery & Continuity Leadership','leadership','Intermediate','Connect impact analysis to recovery objectives, plans, and exercises.',[
'Business Impact Analysis','Recovery Time Objective','Recovery Point Objective','Contingency Plan','Contingency Plan Testing'])
add_path('v08-calculus-core','Calculus Core','math','Foundation','Build from limits to derivatives and integrals with evidence-backed definitions.',[
'Limit','Continuity','Derivative','Product Rule','Chain Rule','Antiderivative','Definite Integral','Fundamental Theorem of Calculus'])
add_path('v08-linear-algebra','Linear Algebra Core','math','Foundation','Move from vectors to span, basis, rank, determinants, inverses, and eigenvectors.',[
'Vector','Dot Product','Matrix Multiplication','Linear Combination','Span','Linear Independence','Basis','Matrix Rank','Determinant','Eigenvalue and Eigenvector'])
add_path('v08-mechanics','Classical Mechanics Core','physics','Foundation','Connect motion, force, energy, momentum, and rotation.',[
'Displacement','Average Velocity','Acceleration','Newton Second Law','Work','Kinetic Energy','Linear Momentum','Momentum Conservation','Torque','Angular Momentum'])
add_path('v08-em','Electricity & Magnetism Core','physics','Foundation','Build a path from charge and fields through circuits and electromagnetic induction.',[
'Coulomb Force','Electric Field','Electric Potential Difference','Capacitance','Ohm Law','Kirchhoff Junction Rule','Kirchhoff Loop Rule','Magnetic Force on Moving Charge','Faraday Law'])

# Add glossary entries from new concepts, capped to 110 high-value new terms.
existing_terms={norm(g['term']) for g in D['glossary']}
for l in new:
    if not l['title'].startswith('Deep Dive: '): continue
    term=l['title'][11:]
    if norm(term) in existing_terms: continue
    D['glossary'].append({'term':term,'definition':l['verifiedClaims'][0],'domain':l['domain'],'lesson_id':l['id']});existing_terms.add(norm(term))
    if len(D['glossary'])>=420: break

# Expand future atlas with additional explicitly-unpublished directions without duplicating published titles.
future={
'software':['Property-based testing','Mutation testing','Contract testing','Event sourcing','CQRS','Distributed tracing instrumentation','Database replication patterns','Schema migration safety','Backpressure in stream processing','Memory profiling in Python','Type checking with Python annotations','Git bisect workflows','PostgreSQL vacuum internals','PostgreSQL query statistics','API pagination strategies','HTTP/3 overview','WebSocket protocol fundamentals','Message broker delivery semantics','Idempotency keys','Dependency injection'],
'cyber':['Passkey deployment patterns','WebAuthn ceremonies','Certificate lifecycle automation','Hardware security modules','Secure boot chains','Software bill of materials','Supply-chain attestations','Container image signing','Kubernetes admission security','Cloud workload identity','Endpoint isolation workflows','Threat hunting hypotheses','Detection engineering lifecycle','YARA rule fundamentals','Sigma detection rules','Email authentication SPF','Email authentication DKIM','Email authentication DMARC','DNSSEC operations','Security chaos engineering'],
'leadership':['Service ownership models','Technical debt portfolios','Architecture review facilitation','Change failure analysis','Operational readiness reviews','Capacity review cadence','Cloud cost governance','FinOps unit economics','Vendor exit planning','Succession planning for technical teams','Escalation policy design','On-call sustainability','Runbook quality scoring','Risk acceptance records','Control ownership models','Executive incident briefings','Reliability roadmap planning','Platform product management','Developer experience metrics','Knowledge continuity planning'],
'math':['Taylor series','Power series radius of convergence','Multivariable gradients','Directional derivatives','Multiple integrals','Vector fields','Line integrals','Fourier series','Laplace transforms','Differential equations','Eigenvalue algorithms','Singular value decomposition','Least squares','Bayes theorem','Central limit theorem','Confidence intervals','Hypothesis testing','Markov chains','Graph theory','Numerical conditioning'],
'physics':['Universal gravitation','Orbital mechanics','Fluid statics','Fluid dynamics','Entropy','Heat engines','Gauss law','Electric dipoles','RC circuits','RLC circuits','Ampere law','Maxwell equations','Electromagnetic spectrum','Geometric optics','Interference and diffraction','Special relativity time dilation','Relativistic momentum','de Broglie wavelength','Schrodinger equation','Heisenberg uncertainty principle']}
for dom,items in future.items():
    D['atlas'].setdefault(dom,[])
    for x in items:
        if x not in D['atlas'][dom] and norm(x) not in {norm(l['title'].replace('Deep Dive: ','').replace('Evidence Lab: ','')) for l in D['lessons']}:
            D['atlas'][dom].append(x)

D['version']='0.8.0';D['lastReviewed']=REVIEW
D['verificationPolicy']={'name':'Evidence-gated publication','rule':'No published learning object without a narrow verified claim, review date, and direct authoritative evidence. Labs separate prediction from evidence so learners practice both recall and verification.','reviewed':REVIEW,'note':'Version-sensitive claims are verified against the linked documentation on the recorded review date and should be re-checked after product or standard changes.'}

# Write data.
(P/'knowledge-data.js').write_text('window.JR_KNOWLEDGE = '+json.dumps(D,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')

# Verification manifests.
records=[]
for l in D['lessons']:
    records.append({'id':l['id'],'title':l['title'],'domain':l['domain'],'category':l['category'],'reviewed':l.get('verification',{}).get('reviewed',REVIEW),'versionSensitive':bool(l.get('versionSensitive')),'verifiedClaims':l.get('verifiedClaims',[]),'sources':[{'title':r[0],'url':r[1]} for r in l.get('references',[])]})
manifest={'version':'0.8.0','reviewed':REVIEW,'count':len(records),'policy':D['verificationPolicy'],'records':records}
(P/'verification-manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
with (OUT/'VERIFICATION_MANIFEST_v0.8.0.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['id','title','domain','category','reviewed','version_sensitive','verified_claims','source_titles','source_urls'])
    for r in records:w.writerow([r['id'],r['title'],r['domain'],r['category'],r['reviewed'],r['versionSensitive'],' | '.join(r['verifiedClaims']),' | '.join(s['title'] for s in r['sources']),' | '.join(s['url'] for s in r['sources'])])

# UI: add Mastery as a dedicated page and make non-engine labs interactive via native controls.
html_files=list(P.glob('learn*.html'))
master_section='''\n    <section class="mastery section" id="mastery">\n      <div class="shell">\n        <div class="section-heading">\n          <div><p class="eyebrow">05 / MASTERY DASHBOARD</p><h2>Turn activity into a learning signal.</h2></div>\n          <p>Progress is calculated only from this browser: completed lessons, recall attempts, saved items, and glossary practice. No account or upload is required.</p>\n        </div>\n        <div class="mastery-grid" id="mastery-grid"></div>\n        <div class="mastery-actions">\n          <article class="mastery-card"><p class="eyebrow">WEAKEST RECALL</p><h3>Review what is actually slipping.</h3><div id="mastery-weak"></div></article>\n          <article class="mastery-card"><p class="eyebrow">NEXT BEST ACTION</p><h3>Keep momentum without searching.</h3><div id="mastery-next"></div></article>\n        </div>\n      </div>\n    </section>\n'''
for f in html_files:
    t=f.read_text(encoding='utf-8')
    if 'data-learn-page="mastery"' not in t:
        t=t.replace('<a href="learn-practice.html" data-learn-page="practice">Practice</a>','<a href="learn-practice.html" data-learn-page="practice">Practice</a>\n      <a href="learn-mastery.html" data-learn-page="mastery">Mastery</a>')
    if 'id="mastery"' not in t:
        t=t.replace('    <section class="labs section" id="labs">',master_section+'\n    <section class="labs section" id="labs">')
    t=t.replace('VERIFIED + INTERACTIVE RELEASE','VERIFIED + INTERACTIVE + MASTERY RELEASE')
    f.write_text(t,encoding='utf-8')
# Create mastery page from practice page.
base=(P/'learn-practice.html').read_text(encoding='utf-8')
base=re.sub(r'<body data-library-page="[^"]+">','<body data-library-page="mastery">',base,1)
(P/'learn-mastery.html').write_text(base,encoding='utf-8')

js=(P/'knowledge.js').read_text(encoding='utf-8')
# Upgrade hands-on fallback to an interactive evidence lab using native controls, textarea and details.
old="function handsOnFallback(l){return `<div class=\"hands-on-card\"><p class=\"eyebrow\">TRY IT YOURSELF</p><h3>Turn the concept into retrieval.</h3><ol><li>Explain <strong>${esc(l.title)}</strong> without looking at the explanation.</li><li>Use the example below to identify the exact system behavior.</li><li>Open the cited primary source and confirm the key claim in your own words.</li></ol><div class=\"callout\"><strong>Scenario</strong><p>${esc(l.example)}</p></div></div>`}"
new="function handsOnFallback(l){return `<div class=\"hands-on-card evidence-lab\"><p class=\"eyebrow\">INTERACTIVE EVIDENCE LAB</p><h3>Predict → test → verify → explain.</h3><div class=\"lab-checks\"><label><input type=\"checkbox\"> 1. State the rule from memory before looking.</label><label><input type=\"checkbox\"> 2. Work through the scenario or calculation.</label><label><input type=\"checkbox\"> 3. Open the authoritative source and find the exact supporting statement.</label><label><input type=\"checkbox\"> 4. Explain any difference between your prediction and the evidence.</label></div><label class=\"lab-notes\">Your prediction / working notes<textarea rows=\"4\" placeholder=\"Write the answer you expect before revealing the verified claim…\"></textarea></label><div class=\"callout\"><strong>Scenario</strong><p>${esc(l.example)}</p></div><details class=\"evidence-reveal\"><summary>Reveal the verified claim</summary><p>${esc((l.verifiedClaims&&l.verifiedClaims[0])||l.takeaway)}</p><p class=\"muted\">Now compare this with your prediction, then use the Evidence tab to inspect the source itself.</p></details></div>`}"
if old not in js: raise SystemExit('handsOnFallback signature not found')
js=js.replace(old,new)
# Add mastery render function before applyLibraryPage.
marker='  function applyLibraryPage(){\n'
master_js=r'''  function renderMastery(){
    const grid=$('#mastery-grid'); if(!grid)return;
    const rows=D.domains.map(d=>{
      const ls=D.lessons.filter(l=>l.domain===d.id), done=ls.filter(l=>completed.has(l.id)).length;
      const attempts=ls.reduce((n,l)=>n+(recallState[l.id]?.total||0),0), correct=ls.reduce((n,l)=>n+(recallState[l.id]?.correct||0),0);
      const recall=attempts?Math.round(correct/attempts*100):null, pct=ls.length?Math.round(done/ls.length*100):0;
      return {d,total:ls.length,done,pct,attempts,recall};
    });
    grid.innerHTML=rows.map(r=>`<article class="mastery-domain"><div class="mastery-domain-head"><span>${esc(r.d.icon)}</span><div><p class="eyebrow">${esc(r.d.name)}</p><h3>${r.done} / ${r.total} completed</h3></div></div><div class="mastery-bar"><i style="width:${r.pct}%"></i></div><div class="mastery-metrics"><span><strong>${r.pct}%</strong> completion</span><span><strong>${r.recall===null?'—':r.recall+'%'}</strong> recall</span><span><strong>${r.attempts}</strong> attempts</span></div><a class="text-button" href="learn-browse.html?domain=${encodeURIComponent(r.d.id)}">Study ${esc(r.d.name)} ↗</a></article>`).join('');
    const weak=D.lessons.filter(l=>recallState[l.id]?.total).map(l=>({l,r:recallState[l.id],rate:recallState[l.id].correct/recallState[l.id].total})).sort((a,b)=>a.rate-b.rate||b.r.total-a.r.total).slice(0,5);
    const weakBox=$('#mastery-weak'); if(weakBox)weakBox.innerHTML=weak.length?`<div class="mastery-list">${weak.map(x=>`<button type="button" data-master-lesson="${esc(x.l.id)}"><span>${esc(x.l.title)}</span><strong>${Math.round(x.rate*100)}%</strong></button>`).join('')}</div>`:'<p class="muted">Answer some recall questions first. Missed answers will appear here so review is evidence-driven.</p>';
    const nextBox=$('#mastery-next'); if(nextBox){const unfinished=D.lessons.filter(l=>!completed.has(l.id));const recent=localStorage.getItem(STORAGE.recent);const pick=(recent&&lessonMap.get(recent)&&!completed.has(recent))?lessonMap.get(recent):unfinished[Math.floor(Math.random()*Math.max(1,unfinished.length))];nextBox.innerHTML=pick?`<p>${esc(pick.summary)}</p><button class="button primary" type="button" data-master-lesson="${esc(pick.id)}">Continue with ${esc(pick.title)} ↗</button>`:'<p>You have completed every published object in this browser. That is an extraordinary amount of study.</p>'}
    $$('[data-master-lesson]').forEach(b=>b.onclick=()=>openLesson(b.dataset.masterLesson));
  }

'''
if marker not in js: raise SystemExit('applyLibraryPage marker missing')
js=js.replace(marker,master_js+marker)
# Patch page map/labels/all and startup call.
js=js.replace("practice:['practice'],labs:['labs']","practice:['practice'],mastery:['mastery'],labs:['labs']")
js=js.replace("practice:['04 / ACTIVE RECALL','Practice for retention.','Quizzes and flashcards make you retrieve knowledge instead of merely rereading it.'],labs:","practice:['04 / ACTIVE RECALL','Practice for retention.','Quizzes and flashcards make you retrieve knowledge instead of merely rereading it.'],mastery:['05 / MASTERY','See what is sticking.','Use completion and recall history stored in this browser to choose what to review next.'],labs:")
js=js.replace("'discover','practice','labs'","'discover','practice','mastery','labs'")
js=js.replace("renderKnowledgeGraph(); initPractice(); initEvents();", "renderKnowledgeGraph(); initPractice(); renderMastery(); initEvents();")
(P/'knowledge.js').write_text(js,encoding='utf-8')

# CSS for mastery and lab controls.
css=(P/'knowledge.css').read_text(encoding='utf-8')
css += r'''

/* v0.8.0 — mastery + interactive evidence labs */
.mastery-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}.mastery-domain,.mastery-card{border:1px solid var(--line);background:var(--panel);border-radius:18px;padding:20px;min-width:0}.mastery-domain-head{display:flex;gap:14px;align-items:center}.mastery-domain-head>span{font-size:1.6rem}.mastery-domain h3,.mastery-card h3{margin:.25rem 0 .8rem}.mastery-bar{height:7px;background:var(--panel2);border-radius:999px;overflow:hidden;margin:16px 0}.mastery-bar i{display:block;height:100%;background:var(--accent);border-radius:inherit}.mastery-metrics{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px}.mastery-metrics span{font-size:.8rem;color:var(--muted)}.mastery-metrics strong{display:block;color:var(--text);font-size:1rem}.mastery-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;margin-top:20px}.mastery-list{display:grid;gap:8px}.mastery-list button{width:100%;display:flex;justify-content:space-between;gap:14px;align-items:center;text-align:left;border:1px solid var(--line);border-radius:12px;background:var(--panel2);color:var(--text);padding:12px 14px;cursor:pointer}.mastery-list button:hover,.mastery-list button:focus-visible{border-color:var(--accent)}.evidence-lab .lab-checks{display:grid;gap:10px;margin:18px 0}.evidence-lab .lab-checks label{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border:1px solid var(--line);border-radius:12px;background:var(--panel2)}.evidence-lab input[type=checkbox]{width:20px;height:20px;flex:0 0 auto}.lab-notes{display:grid;gap:8px;color:var(--muted);font-size:.85rem;margin:18px 0}.lab-notes textarea{width:100%;resize:vertical;min-height:100px;border:1px solid var(--line);border-radius:12px;background:var(--bg);color:var(--text);padding:12px;font:inherit}.evidence-reveal{margin-top:16px;border:1px solid var(--line);border-radius:12px;padding:12px 14px;background:var(--panel2)}.evidence-reveal summary{cursor:pointer;color:var(--accent);font-weight:700}.evidence-reveal[open] summary{margin-bottom:12px}
@media(max-width:980px){.mastery-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:680px){.mastery-grid,.mastery-actions{grid-template-columns:1fr}.mastery-domain,.mastery-card{padding:16px}.mastery-metrics{justify-content:space-between}.lab-notes textarea{font-size:16px}}
'''
(P/'knowledge.css').write_text(css,encoding='utf-8')

# Update docs.
counts=collections.Counter(l['domain'] for l in D['lessons']); labs=sum(l['kind']=='Lab' for l in D['lessons']); inter=sum(bool(l.get('interactive')) for l in D['lessons']); itypes=len({l['interactive'] for l in D['lessons'] if l.get('interactive')});atlas=sum(len(x) for x in D['atlas'].values())
release=f'''JOSHUA RANDALL KNOWLEDGE PLATFORM — v0.8.0 RELEASE NOTES\n\nMASTERY MILESTONE\nv0.8.0 expands the source-verified library from 950 to {len(D['lessons'])} published learning objects. The largest growth is deliberately in the previously smaller domains so the platform becomes a broad technical curriculum rather than only an infrastructure/HPC library.\n\nDOMAIN COUNTS\n'''+''.join(f'- {next(d["name"] for d in D["domains"] if d["id"]==k)}: {v}\n' for k,v in counts.items())+f'''\nLEARNING + RETENTION\n- Guided learning paths: {len(D['paths'])}\n- Glossary terms: {len(D['glossary'])}\n- Formal labs: {labs}\n- Interactive model-backed objects: {inter}\n- Interactive engine types: {itypes}\n- Mapped future topics: {atlas}\n- New dedicated Mastery page summarizes completion and recall performance by domain using browser-local data only.\n- Every non-simulation lab now contains an interactive prediction/checklist/notes/reveal workflow instead of passive instructions.\n\nVERIFICATION\n- All published objects carry at least one narrow verified claim, review date, and direct authoritative source.\n- v0.8 additions use Python, Git, PostgreSQL, RFC, NIST, CISA, OWASP, Google SRE, MIT OCW, and OpenStax primary/authoritative material.\n- Version-sensitive software/security/operations claims are labeled.\n\nRESPONSIVE EXPERIENCE\nThe multi-page, low-scroll architecture remains. Mastery is a separate page rather than another long block added to Practice. The mastery grid reflows 3 → 2 → 1 columns, and evidence-lab controls remain phone-friendly.\n'''
(OUT/'RELEASE_NOTES_v0.8.0.txt').write_text(release,encoding='utf-8')
policy='''JOSHUA RANDALL KNOWLEDGE PLATFORM — SOURCE VERIFICATION POLICY v0.8.0\n\nPUBLICATION GATE\n1. Every published object must make at least one narrow factual claim that can be checked directly.\n2. Every claim must link to a primary standard, official project/vendor documentation, government guidance, original paper, or open university textbook appropriate to that claim.\n3. The review date is recorded.\n4. Version-sensitive technology claims are labeled and must be re-checked when the referenced product/standard changes.\n5. Simulations and diagrams must identify themselves as educational models when they simplify real implementations.\n6. Labs separate prediction from evidence: learners answer first, then reveal the verified claim, then inspect the source.\n\n“Verified” means checked against the linked evidence on the stated review date. It does not claim that a version-sensitive technology can never change.\n'''
(OUT/'SOURCE_VERIFICATION_POLICY_v0.8.0.txt').write_text(policy,encoding='utf-8')
readme=(OUT/'README_FIRST.txt').read_text(encoding='utf-8') if (OUT/'README_FIRST.txt').exists() else ''
readme=re.sub(r'v0\.7\.0','v0.8.0',readme)
readme += '\nNEW IN v0.8.0: learn-mastery.html is included. Copy it with the other public_html files.\n'
(OUT/'README_FIRST.txt').write_text(readme,encoding='utf-8')
# Copy source build script.
source=OUT/'source'; source.mkdir(exist_ok=True)
shutil.copy2('/mnt/data/build_v08.py',source/'build_v08.py')

# Validator.
validate=f'''from pathlib import Path\nimport json,re,urllib.parse,subprocess,sys\nROOT=Path(__file__).resolve().parents[1];P=ROOT/'public_html'\ns=(P/'knowledge-data.js').read_text(encoding='utf-8');D=json.loads(s[s.index('{{'):s.rfind('}}')+1])\nerrors=[];lessons=D['lessons'];ids=[l['id'] for l in lessons];titles=[re.sub(r'\\W+',' ',l['title'].lower()).strip() for l in lessons];idset=set(ids)\nif D.get('version')!='0.8.0':errors.append('wrong version')\nif len(lessons)!={len(D['lessons'])}:errors.append(f'lesson count {{len(lessons)}}')\nif len(ids)!=len(set(ids)):errors.append('duplicate IDs')\nif len(titles)!=len(set(titles)):errors.append('duplicate titles')\napproved={{'www.rfc-editor.org','www.intel.com','openstax.org','kubernetes.io','sre.google','docs.kernel.org','learn.microsoft.com','docs.nvidia.com','www.mpi-forum.org','docs.riscv.org','www.openmp.org','www.postgresql.org','www.nist.gov','quantum.cloud.ibm.com','docs.python.org','docs.redhat.com','dlmf.nist.gov','csrc.nist.gov','git-scm.com','cheatsheetseries.owasp.org','docs.aws.amazon.com','slurm.schedmd.com','www.gnu.org','pages.nist.gov','developer.hashicorp.com','www.usenix.org','ocw.mit.edu','www.freedesktop.org','systemd.io','www.cisa.gov','opentelemetry.io','lamport.azurewebsites.net','prometheus.io','www.iana.org','pubs.opengroup.org','escholarship.org','developer.download.nvidia.com'}}\nfor l in lessons:\n    if not l.get('verifiedClaims'):errors.append(l['id']+': no verified claim')\n    if not l.get('references'):errors.append(l['id']+': no source')\n    if l.get('verification',{{}}).get('status')!='verified':errors.append(l['id']+': not verified')\n    for r in l.get('references',[]):\n        u=urllib.parse.urlparse(r[1]);\n        if u.scheme!='https' or u.netloc not in approved:errors.append(l['id']+': unapproved source '+r[1])\n    for k in ('prereq','related'):\n        for x in l.get(k,[]):\n            if x not in idset:errors.append(l['id']+': bad '+k+' '+x)\n    q=l.get('quiz');\n    if q and (not q.get('options') or not isinstance(q.get('answer'),int) or q['answer']<0 or q['answer']>=len(q['options'])):errors.append(l['id']+': bad quiz')\nfor p in D['paths']:\n    if not p.get('lesson_ids'):errors.append('empty path '+p.get('id','?'))\n    for x in p.get('lesson_ids',[]):\n        if x not in idset:errors.append('path missing '+x)\nfor g in D['glossary']:\n    if g.get('lesson_id') not in idset:errors.append('glossary missing '+g.get('term','?'))\njs=(P/'knowledge.js').read_text(encoding='utf-8');implemented=set(re.findall(r"type==='([^']+)'",js));implemented.update(['urljourney','dns','api','tls','tcp','vector','derivative','matrix','force','projectile','wave','doppler','ohm']);used={{l['interactive'] for l in lessons if l.get('interactive')}}\nif used-implemented:errors.append('missing interactive types '+str(sorted(used-implemented)))\nfor f in P.glob('*.html'):\n    t=f.read_text(encoding='utf-8');xs=re.findall(r'\\bid=["\\\']([^"\\\']+)',t);dups={{x for x in xs if xs.count(x)>1}}\n    if dups:errors.append(f.name+': duplicate IDs '+str(sorted(dups)))\ntry:subprocess.run(['node','--check',str(P/'knowledge.js')],check=True,capture_output=True,text=True)\nexcept Exception as e:errors.append('JS syntax '+str(e))\nM=json.loads((P/'verification-manifest.json').read_text(encoding='utf-8'))\nif M.get('count')!=len(lessons) or len(M.get('records',[]))!=len(lessons):errors.append('manifest mismatch')\nif not (P/'learn-mastery.html').exists():errors.append('mastery page missing')\nprint('VALIDATION','PASS' if not errors else 'FAIL');print('lessons',len(lessons),'paths',len(D['paths']),'glossary',len(D['glossary']),'labs',sum(l.get('kind')=='Lab' for l in lessons),'interactive',sum(bool(l.get('interactive')) for l in lessons),'types',len(used),'atlas',sum(len(v) for v in D['atlas'].values()))\nif errors:\n    print('\\n'.join('ERROR: '+x for x in errors));sys.exit(1)\n'''
(source/'validate_v08.py').write_text(validate,encoding='utf-8')
# Run validation.
r=subprocess.run([sys.executable,str(source/'validate_v08.py')],capture_output=True,text=True)
print(r.stdout);print(r.stderr,file=sys.stderr)
if r.returncode: raise SystemExit(r.returncode)
(OUT/'VALIDATION_v0.8.0.txt').write_text('JOSHUA RANDALL KNOWLEDGE PLATFORM — v0.8.0 VALIDATION\n\nRESULT: PASS\n\n'+r.stdout+f'''\nDOMAIN COUNTS\n'''+''.join(f'- {next(d["name"] for d in D["domains"] if d["id"]==k)}: {v}\n' for k,v in counts.items())+'''\nRESPONSIVE / ACCESSIBILITY\n- Separate task pages retained; Mastery added as its own page.\n- Lesson tabs remain Overview, Learn, Explore/Lab, Practice, Evidence.\n- Mastery grid reflows for tablet/phone widths.\n- Evidence labs use native checkbox, textarea, details/summary controls and keyboard-accessible buttons.\n- Reduced-motion and opt-in narration remain.\n\nNOTE: Real-device rendering and installed TTS voices remain browser/OS dependent and should be checked after deployment.\n''',encoding='utf-8')
# Public readme version.
pr=(P/'README_KNOWLEDGE_PLATFORM.txt').read_text(encoding='utf-8')
pr=re.sub(r'v0\.7\.0','v0.8.0',pr);pr+='\nMastery dashboard: learn-mastery.html\nPublished objects: '+str(len(D['lessons']))+'\n'
(P/'README_KNOWLEDGE_PLATFORM.txt').write_text(pr,encoding='utf-8')
# Package zip.
zip_path=Path('/mnt/data/Joshua_Randall_Knowledge_Platform_v0.8.0.zip')
if zip_path.exists():zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in OUT.rglob('*'):
        if f.is_file():z.write(f,Path(OUT.name)/f.relative_to(OUT))
with zipfile.ZipFile(zip_path) as z: bad=z.testzip(); assert bad is None,bad
print('ZIP',zip_path,zip_path.stat().st_size)
print('COUNTS',len(D['lessons']),dict(counts),len(D['paths']),len(D['glossary']),labs,inter,itypes,atlas)
