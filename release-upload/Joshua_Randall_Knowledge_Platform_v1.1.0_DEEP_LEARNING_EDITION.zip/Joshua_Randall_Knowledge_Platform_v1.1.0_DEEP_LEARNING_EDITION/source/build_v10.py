from pathlib import Path
import json,re,csv,copy,shutil,zipfile,collections,subprocess,sys,urllib.parse,os,http.server,socketserver,threading

BASE=Path('/mnt/data/kp_v10_build/Joshua_Randall_Knowledge_Platform_v0.9.0')
OUT=Path('/mnt/data/Joshua_Randall_Knowledge_Platform_v1.0.0_FULL_REPLACEMENT')
ZIP=Path('/mnt/data/Joshua_Randall_Knowledge_Platform_v1.0.0_FULL_REPLACEMENT.zip')
BUILD_DATE='2026-09-13'
VERSION='1.0.0'
if OUT.exists(): shutil.rmtree(OUT)
shutil.copytree(BASE,OUT)
P=OUT/'public_html'

# Remove stale root release docs. Keep older source scripts for reproducibility.
for q in list(OUT.glob('RELEASE_NOTES_v*.txt'))+list(OUT.glob('SOURCE_VERIFICATION_POLICY_v*.txt'))+list(OUT.glob('VALIDATION_v*.txt'))+list(OUT.glob('VERIFICATION_MANIFEST_v*.csv')):
    q.unlink()

def load_js(path):
    s=Path(path).read_text(encoding='utf-8'); st=s.index('{'); d=0; ins=False; esc=False
    for i,ch in enumerate(s[st:],st):
        if ins:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': ins=False
        else:
            if ch=='"': ins=True
            elif ch=='{': d+=1
            elif ch=='}':
                d-=1
                if d==0:return json.loads(s[st:i+1])
    raise RuntimeError('JSON object not found')

D=load_js(P/'knowledge-data.js')
assert D['version']=='0.9.0'
assert len(D['lessons'])==4200
D['version']=VERSION
D['buildDate']=BUILD_DATE

TARGETS={'cloud':1200,'advanced':1200,'software':1150,'cyber':1150,'leadership':1100,'math':1100,'physics':1100}
assert sum(TARGETS.values())==8000
LAB_QUOTA={'cloud':185,'advanced':185,'software':185,'cyber':195,'leadership':178,'math':178,'physics':178}
NONLAB_INTERACTIVE_QUOTA={'cloud':110,'advanced':110,'software':110,'cyber':115,'leadership':98,'math':98,'physics':99}
assert sum(LAB_QUOTA.values())==1284
assert sum(NONLAB_INTERACTIVE_QUOTA.values())==740

def norm(s): return re.sub(r'[^a-z0-9]+',' ',str(s).lower()).strip()
def slug(s): return re.sub(r'[^a-z0-9]+','-',str(s).lower()).strip('-')
def concept_title(title):
    t=title.strip()
    prefixes=['Deep Dive: ','Evidence Lab: ','Quick Concept: ','Troubleshooting Guide: ','Lab: ','Practice: ','Worked Example: ','Scenario: ','What Is ','Understanding ',
              'Practical Lab: ','Troubleshooting Lab: ','Evidence Verification Lab: ','Teach-Back Lab: ','Failure Analysis Lab: ','Decision Lab: ',
              'Recall Drill: ','Misconception Clinic: ','Design Review: ','Quick Reference: ']
    changed=True
    while changed:
        changed=False
        for p in prefixes:
            if t.startswith(p): t=t[len(p):].strip(); changed=True
    return t.strip(' ?')

ids={l['id'] for l in D['lessons']}; titles={norm(l['title']) for l in D['lessons']}
# Only derive from 1,400 factual/core objects, not earlier pedagogical derivatives.
CORE=[copy.deepcopy(l) for l in D['lessons'] if 'parentLessonId' not in l.get('verification',{})]
assert len(CORE)==1400, len(CORE)
source_by_domain=collections.defaultdict(list)
for l in CORE:
    assert l.get('references') and l.get('verifiedClaims') and l.get('verification',{}).get('status')=='verified'
    source_by_domain[l['domain']].append(l)

LAB_FORMATS=[
 ('Configuration Lab','configuration'),('Diagnostic Lab','diagnostic'),('Trace Lab','trace'),('Fault-Isolation Lab','fault isolation'),
 ('Prediction Lab','prediction'),('Counterexample Lab','counterexample'),('Measurement Lab','measurement'),('Runbook Lab','runbook'),
 ('Verification Lab','verification'),('Recovery Lab','recovery'),('Boundary-Condition Lab','boundary conditions'),('Transfer Lab','transfer'),
 ('Checklist Lab','checklist'),('Decision-Matrix Lab','decision matrix'),('Concept-Mapping Lab','concept mapping'),('Hypothesis Lab','hypothesis')
]
NONLAB_FORMATS=[
 ('Retrieval Ladder','retrieval'),('Worked Walkthrough','walkthrough'),('Explain-Back Challenge','explain back'),('Compare & Contrast','comparison'),
 ('Scenario Brief','scenario'),('Mistake Hunt','mistake hunt'),('Design Critique','design critique'),('Evidence Reading','evidence reading'),
 ('Field Note','field note'),('Flash Review','flash review'),('Transfer Challenge','transfer'),('Reasoning Check','reasoning'),
 ('Decision Brief','decision'),('Concept Connection','connection'),('Exam-Style Practice','exam practice'),('Confidence Calibration','calibration')
]
GENERIC_ENGINES=['evidenceworkbench','faulttree','sequencebuilder','decisionmatrix','conceptmap','hypothesis','teachback','checklistbuilder']

# Instruction text is deliberately procedural/hypothetical; the only factual statement is the inherited verified claim.
def activity_text(mode,concept,domain):
    lead={
      'cloud':'Use a safe sandbox, disposable configuration, packet trace, command output, or architecture sketch; do not change a production system.',
      'advanced':'Use a tiny trace, calculation, state table, benchmark hypothesis, or schematic model before scaling the idea up.',
      'software':'Use the smallest reproducible program, query, test, or state trace that isolates the concept.',
      'cyber':'Use a fictional system, lab tenant, or intentionally vulnerable training target; never use real credentials or unauthorized systems.',
      'leadership':'Use a fictional team/service and separate observations, assumptions, decisions, owners, and measurable outcomes.',
      'math':'Write each transformation and check the result against the cited definition, theorem, or worked relationship.',
      'physics':'State assumptions, draw or describe the model, keep units visible, and compare the result with the cited physical relationship.'
    }[domain]
    prompts={
      'configuration':f'Create a reversible lab configuration around {concept}. Predict the result, record the change, observe the result, then revert it.',
      'diagnostic':f'Invent one symptom related to {concept}. Write three competing hypotheses and one observation that can eliminate each hypothesis.',
      'trace':f'Trace {concept} step by step using a sequence, table, packet/state path, equation chain, or event timeline. Mark where the verified rule constrains the trace.',
      'fault isolation':f'Construct a fictional failure around {concept}. Narrow it from broad layer/category to one testable cause without changing multiple variables at once.',
      'prediction':f'Before opening the evidence, predict the outcome of a small {concept} scenario. Then reveal the verified claim and explain any mismatch.',
      'counterexample':f'Write one statement that the verified claim supports and one stronger statement it does not guarantee. Build a hypothetical counterexample to the overstatement.',
      'measurement':f'Define what you would measure to evaluate a {concept} hypothesis. Separate the measurement from the conclusion and state what result would change your mind.',
      'runbook':f'Write a short runbook for checking {concept}: precondition, observation, decision point, safe action, rollback, and evidence link.',
      'verification':f'Open the authoritative source for {concept}, locate the supporting section, restate the rule in your own words, and connect it to one small example.',
      'recovery':f'Design a recovery drill involving {concept}. Define the starting state, failure condition, expected recovery evidence, and stop/rollback criteria.',
      'boundary conditions':f'List the conditions under which the verified rule for {concept} applies. Then create one scenario inside the boundary and one scenario outside it.',
      'transfer':f'Apply the verified rule for {concept} to a new hypothetical context. Identify which parts transfer directly and which require new evidence.',
      'checklist':f'Build a five-item checklist for evaluating {concept}. Every item must map either to the verified claim or to an explicitly labeled observation/question.',
      'decision matrix':f'Compare two hypothetical choices involving {concept}. Use the verified claim as one constraint and label all other criteria as assumptions or local requirements.',
      'concept mapping':f'Draw a concept map with {concept} in the center. Link prerequisites, consequences, adjacent concepts, and the authoritative evidence; label relationship verbs.',
      'hypothesis':f'Write a falsifiable hypothesis involving {concept}, the observation that would support it, and the observation that would refute it.',
      'retrieval':f'Without looking, write the rule for {concept}. Then reveal the verified claim, correct your wording, wait briefly, and retrieve it a second time.',
      'walkthrough':f'Work through a small {concept} example. Mark each reasoning step and identify exactly which step depends on the verified claim.',
      'explain back':f'Explain {concept} first to a beginner, then to a technical peer. Both explanations must preserve the condition in the verified claim.',
      'comparison':f'Compare {concept} with the nearest related concept in the lesson graph. List similarities, differences, and one distinction directly supported by evidence.',
      'scenario':f'Analyze a hypothetical {concept} scenario using four headings: observations, assumptions, verified rule, conclusion.',
      'mistake hunt':f'Write a plausible but incorrect explanation of {concept}. Find the first sentence that exceeds or contradicts the verified claim, then repair it.',
      'design critique':f'Review a fictional design involving {concept}. Identify what is supported by the verified rule and what still requires measurements, requirements, or additional sources.',
      'evidence reading':f'Read the cited source for {concept}. Identify the exact section supporting the claim and write one question the source does not answer.',
      'field note':f'Create a compact field note for {concept}: rule, condition, quick check, evidence source, and one warning against overgeneralization.',
      'flash review':f'Summarize {concept} in no more than three lines, then compare it with the verified claim and remove anything the evidence does not support.',
      'reasoning':f'Start from the verified claim for {concept} and write a short chain of reasoning to a hypothetical conclusion. Label every added assumption.',
      'decision':f'Write a one-paragraph decision brief involving {concept}: decision, verified constraint, unknowns, evidence needed, and reversible next step.',
      'connection':f'Connect {concept} to two prerequisite or related lessons. Explain the connection without adding a factual statement not supported by one of the linked evidence sets.',
      'exam practice':f'Answer a short exam-style prompt about {concept}, then grade your answer only against the verified claim and cited evidence.',
      'calibration':f'Rate your confidence in explaining {concept} from 0–100 before retrieval, answer from memory, verify the claim, then rate confidence again.'
    }
    return lead+' '+prompts[mode]

new=[]
def create_obj(parent,label,mode,kind,seq,interactive_type=None):
    concept=concept_title(parent['title'])
    title=f'{label}: {concept}'
    if norm(title) in titles: title=f'{label} {seq}: {concept}'
    nt=norm(title)
    if nt in titles: return None
    lid=f"{parent['domain']}-v10-{slug(label)[:22]}-{slug(concept)[:52]}"
    n=2
    while lid in ids:
        lid=f"{parent['domain']}-v10-{slug(label)[:18]}-{slug(concept)[:44]}-{n}"; n+=1
    claim=parent['verifiedClaims'][0]
    refs=copy.deepcopy(parent['references'])
    reviewed=parent.get('verification',{}).get('reviewed') or D.get('lastReviewed') or '2026-09-07'
    explanation=(f'This learning object practices one already source-verified claim about {concept}: {claim}\n\n'
                 'The exercise is pedagogical. Hypothetical scenarios, prompts, and learner-created examples are not additional factual claims. '
                 'Use the linked source as the evidence boundary and label any assumption you introduce.')
    summary=f'Practice {concept} with a {mode} activity grounded in the same authoritative evidence as the source lesson.'
    why='Active retrieval, explanation, prediction, and feedback require the learner to use the verified rule rather than merely recognize it.'
    activity=activity_text(mode,concept,parent['domain'])
    ver=copy.deepcopy(parent.get('verification',{}))
    ver.update({'status':'verified','reviewed':reviewed,'derivedOn':BUILD_DATE,
                'method':'Derived pedagogical object. The factual claim and authoritative evidence are inherited verbatim from the source lesson; the activity text is instructional/hypothetical and introduces no additional factual assertion.',
                'parentLessonId':parent['id'],'claimType':'Exact inherited verified claim','sourceCount':len(refs)})
    options=[claim,
             'A stronger statement that is not established by the cited evidence.',
             'A statement that removes the conditions from the verified claim.',
             'A conclusion that cannot be checked against the linked evidence.']
    l={'id':lid,'domain':parent['domain'],'category':parent.get('category','Foundations'),'title':title,'summary':summary,
       'explanation':explanation,'why':why,'example':activity,'takeaway':claim,'difficulty':parent.get('difficulty','Foundation'),
       'kind':kind,'minutes':20 if kind=='Lab' else 9,
       'tags':list(dict.fromkeys((parent.get('tags') or [])+[mode,label.lower(),'active learning','evidence-first'])),
       'interactive':interactive_type,'prereq':[parent['id']],
       'related':list(dict.fromkeys([parent['id']]+(parent.get('related') or [])))[:5],
       'quiz':{'q':f'Which statement is directly supported by the cited evidence for {concept}?','options':options,'answer':0,'explanation':claim},
       'misconception':'A useful exercise can help you reason about a claim, but it does not make a broader factual statement true. Keep the source conditions intact.',
       'objectives':[f'Retrieve the verified rule for {concept}',f'Apply it using a {mode} activity','Separate evidence from assumptions','Explain the result in your own words'],
       'references':refs,'verification':ver,'versionSensitive':bool(parent.get('versionSensitive')),'verifiedClaims':[claim]}
    D['lessons'].append(l); ids.add(lid); titles.add(nt); new.append(l); return l

# Generate exact final domain counts; exact lab and non-lab-interactive quotas.
for domain,target in TARGETS.items():
    current=sum(1 for l in D['lessons'] if l['domain']==domain)
    need=target-current
    lab_need=LAB_QUOTA[domain]; nli_need=NONLAB_INTERACTIVE_QUOTA[domain]
    nonlab_need=need-lab_need
    sources=source_by_domain[domain]
    bycat=collections.defaultdict(list)
    for l in sources: bycat[l.get('category','Foundations')].append(l)
    cats=sorted(bycat)
    for c in cats: bycat[c].sort(key=lambda x:(concept_title(x['title']),x['id']))
    idx={c:0 for c in cats}
    made_lab=made_non=made_nli=0; seq=0; guard=0
    # Interleave categories while first satisfying lab quota, then non-lab quota.
    while made_lab<lab_need or made_non<nonlab_need:
        guard+=1
        if guard>need*40: raise RuntimeError(f'generation guard {domain}')
        want_lab = made_lab<lab_need and (made_non>=nonlab_need or (made_lab/(lab_need or 1) <= made_non/(nonlab_need or 1)))
        c=cats[seq%len(cats)]; pool=bycat[c]; parent=pool[idx[c]%len(pool)]; idx[c]+=1; seq+=1
        if want_lab:
            label,mode=LAB_FORMATS[made_lab%len(LAB_FORMATS)]
            eng=GENERIC_ENGINES[made_lab%len(GENERIC_ENGINES)]
            if create_obj(parent,label,mode,'Lab',idx[c],eng): made_lab+=1
        else:
            label,mode=NONLAB_FORMATS[made_non%len(NONLAB_FORMATS)]
            eng=GENERIC_ENGINES[made_nli%len(GENERIC_ENGINES)] if made_nli<nli_need else None
            if create_obj(parent,label,mode,'Lesson' if made_non%3 else 'Quick Concept',idx[c],eng):
                made_non+=1
                if eng: made_nli+=1
    assert made_lab==lab_need and made_non==nonlab_need and made_nli==nli_need,(domain,made_lab,made_non,made_nli)
    print(domain,'added',need,'labs',made_lab,'nonlab interactive',made_nli)

assert len(D['lessons'])==8000,len(D['lessons'])
# Exact targets: 3,000 labs and 4,000 unique lab/model interactive experiences.
lab_count=sum(l.get('kind')=='Lab' for l in D['lessons'])
interactive_union=sum(1 for l in D['lessons'] if l.get('kind')=='Lab' or l.get('interactive'))
assert lab_count==3000,lab_count
assert interactive_union==4000,interactive_union

# Build exactly 300 guided curricula. Preserve existing 151, add 149 evidence-first mastery paths.
paths=D.get('paths',[]); path_ids={p['id'] for p in paths}; path_titles={norm(p.get('title','')) for p in paths}
domain_names={d['id']:d['name'] for d in D['domains']}
for domain in TARGETS:
    cats=sorted({l.get('category','Foundations') for l in D['lessons'] if l['domain']==domain})
    for cat in cats:
        if len(paths)>=300: break
        pool=[l for l in D['lessons'] if l['domain']==domain and l.get('category')==cat]
        # Mix core, lab, interactive, recall-style content.
        core=[l for l in pool if 'parentLessonId' not in l.get('verification',{})]
        labs=[l for l in pool if l.get('kind')=='Lab']
        inter=[l for l in pool if l.get('interactive') and l.get('kind')!='Lab']
        others=[l for l in pool if l not in core and l not in labs and l not in inter]
        chosen=[]
        for group,limit in [(core,5),(labs,5),(inter,4),(others,4)]:
            for l in sorted(group,key=lambda x:x['title'])[:limit]:
                if l['id'] not in chosen: chosen.append(l['id'])
        if len(chosen)<8: continue
        pid=f'v10-{domain}-{slug(cat)}-mastery'
        title=f'{domain_names[domain]} · {cat} Mastery'
        if pid in path_ids or norm(title) in path_titles: continue
        paths.append({'id':pid,'title':title,'summary':f'An evidence-first mastery sequence through {cat}: core explanation, practical labs, interactive work, retrieval, and verification.','domain':domain,'difficulty':'Mixed','lesson_ids':chosen[:18]})
        path_ids.add(pid); path_titles.add(norm(title))
    if len(paths)>=300: break
# If category paths are insufficient, add deterministic numbered domain mastery arcs.
arc=1
while len(paths)<300:
    for domain in TARGETS:
        if len(paths)>=300: break
        pool=sorted([l for l in D['lessons'] if l['domain']==domain],key=lambda x:(x.get('category',''),x['title']))
        # offset creates distinct curated slices
        start=((arc-1)*13)%max(1,len(pool)-18)
        chosen=[l['id'] for l in pool[start:start+18]]
        pid=f'v10-{domain}-mastery-arc-{arc}'
        title=f'{domain_names[domain]} Mastery Arc {arc}'
        if pid not in path_ids:
            paths.append({'id':pid,'title':title,'summary':'A mixed sequence of verified concepts, practical labs, and retrieval work designed for transfer and retention.','domain':domain,'difficulty':'Mixed','lesson_ids':chosen})
            path_ids.add(pid); path_titles.add(norm(title))
    arc+=1
D['paths']=paths[:300]
assert len(D['paths'])==300

# Exactly 1,600 glossary concepts. Prefer core technical names, then domain/category-qualified concepts.
gloss=D.get('glossary',[]); gt={norm(g['term']) for g in gloss}
core_sorted=sorted(CORE,key=lambda l:(l['domain'],l.get('category',''),concept_title(l['title'])))
def add_gloss(term,l):
    n=norm(term)
    if not term or n in gt or len(term)>100:return False
    gloss.append({'term':term,'definition':l['verifiedClaims'][0],'domain':l['domain'],'lesson_id':l['id']});gt.add(n);return True
for l in core_sorted:
    if len(gloss)>=1600:break
    add_gloss(concept_title(l['title']),l)
# Qualify legitimate concept contexts to fill remaining slots without inventing factual definitions.
qualifiers=[('troubleshooting','Troubleshooting'),('verification','Verification'),('design','Design'),('measurement','Measurement'),('operations','Operations'),('practice','Practice')]
for suffix,label in qualifiers:
    if len(gloss)>=1600:break
    for l in core_sorted:
        if len(gloss)>=1600:break
        term=f'{concept_title(l["title"])} — {label}'
        add_gloss(term,l)
D['glossary']=gloss[:1600]
assert len(D['glossary'])==1600

# Update policy metadata.
D['lastBuilt']=BUILD_DATE
D['verificationPolicy']='Every published object exposes at least one checkable claim and direct authoritative evidence. Derived practice objects inherit the exact verified claim and evidence from a core source lesson; hypothetical activities are not additional factual claims.'
for d in D['domains']: d['target']='Open-ended'

(P/'knowledge-data.js').write_text('window.JR_KNOWLEDGE = '+json.dumps(D,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')

# Verification manifest. Review dates remain the actual inherited source-review date; build date is separate.
records=[]
for l in D['lessons']:
    records.append({'id':l['id'],'title':l['title'],'domain':l['domain'],'category':l.get('category',''),'reviewed':l.get('verification',{}).get('reviewed',''),'derivedOn':l.get('verification',{}).get('derivedOn',''),'versionSensitive':bool(l.get('versionSensitive')),'verifiedClaims':l.get('verifiedClaims',[]),'sources':[{'title':r[0],'url':r[1]} for r in l.get('references',[])]})
manifest={'version':VERSION,'built':BUILD_DATE,'count':len(records),'policy':D['verificationPolicy'],'records':records}
(P/'verification-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'VERIFICATION_MANIFEST_v1.0.0.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['id','title','domain','category','reviewed','derived_on','version_sensitive','verified_claims','sources'])
    for r in records:w.writerow([r['id'],r['title'],r['domain'],r['category'],r['reviewed'],r['derivedOn'],r['versionSensitive'],' | '.join(r['verifiedClaims']),' | '.join(x['url'] for x in r['sources'])])

# UI: generic interactive engines for evidence-first practice at scale.
js=(P/'knowledge.js').read_text(encoding='utf-8')
# Add generic titles.
needle="bellpair:'Bell-pair circuit + measurement'"
replace=needle+",evidenceworkbench:'Evidence workbench',faulttree:'Fault-isolation tree',sequencebuilder:'Sequence builder',decisionmatrix:'Decision matrix',conceptmap:'Concept-map builder',hypothesis:'Hypothesis tester',teachback:'Teach-back studio',checklistbuilder:'Checklist builder'"
if needle in js: js=js.replace(needle,replace,1)
# Insert generic handlers before math/physics delegation.
marker="    if(['vector','derivative','matrix','force','projectile','wave','doppler','ohm'].includes(type)) return mountMathPhysics(type,stage,controls);"
generic=r'''    if(type==='evidenceworkbench'){
      const claim=(l.verifiedClaims&&l.verifiedClaims[0])||l.takeaway||'';
      stage.innerHTML='<div class="workflow-grid"><article><span>1</span><h4>Predict</h4><textarea rows="3" data-wb-predict placeholder="Write what you think is true before revealing evidence."></textarea></article><article><span>2</span><h4>Test / reason</h4><textarea rows="3" data-wb-test placeholder="Record the observation, calculation, trace, or reasoning step."></textarea></article><article><span>3</span><h4>Compare</h4><div data-wb-claim class="workflow-claim" hidden></div></article><article><span>4</span><h4>Explain</h4><textarea rows="3" data-wb-explain placeholder="Explain the difference between your prediction and the evidence."></textarea></article></div>';
      controls.innerHTML='<button class="button primary" type="button" data-wb-reveal>Reveal verified claim</button><button class="button" type="button" data-wb-reset>Reset</button><span class="muted" data-wb-status>Prediction first; evidence second.</span>';
      $('[data-wb-reveal]',controls).onclick=()=>{const el=$('[data-wb-claim]',stage);el.hidden=false;el.textContent=claim;$('[data-wb-status]',controls).textContent='Now compare your reasoning with the verified claim.';ping(620)};$('[data-wb-reset]',controls).onclick=()=>{$$('textarea',stage).forEach(x=>x.value='');$('[data-wb-claim]',stage).hidden=true;$('[data-wb-status]',controls).textContent='Prediction first; evidence second.'};return;
    }
    if(type==='faulttree'){
      const claim=(l.verifiedClaims&&l.verifiedClaims[0])||l.takeaway||'';
      stage.innerHTML='<div class="fault-tree"><div class="fault-root">Observed symptom</div><div class="fault-branches"><button type="button" data-fault="A">Hypothesis A</button><button type="button" data-fault="B">Hypothesis B</button><button type="button" data-fault="C">Hypothesis C</button></div><p class="muted" data-fault-out>Select a hypothesis, then define the observation that would eliminate it.</p><textarea rows="3" data-fault-note placeholder="What observation would falsify this hypothesis?"></textarea></div>';
      controls.innerHTML='<button class="button primary" type="button" data-fault-claim>Reveal evidence boundary</button><span class="muted" data-fault-claimtext hidden></span>';
      $$('[data-fault]',stage).forEach(b=>b.onclick=()=>{$$('[data-fault]',stage).forEach(x=>x.classList.remove('selected'));b.classList.add('selected');$('[data-fault-out]',stage).textContent=`${b.textContent}: write a test that can reject it, not merely confirm it.`});$('[data-fault-claim]',controls).onclick=()=>{const e=$('[data-fault-claimtext]',controls);e.hidden=false;e.textContent=claim;ping(560)};return;
    }
    if(type==='sequencebuilder'){
      let steps=[];stage.innerHTML='<div class="sequence-strip" data-seq-list><span class="muted">No steps yet.</span></div><p class="muted">Build a reasoning, event, packet, equation, or state sequence. Then compare the step that depends on the verified claim.</p>';
      controls.innerHTML='<input type="text" data-seq-input maxlength="80" placeholder="Add a step"><button class="button primary" type="button" data-seq-add>Add step</button><button class="button" type="button" data-seq-undo>Undo</button><button class="button" type="button" data-seq-clear>Clear</button>';
      const draw=()=>{$('[data-seq-list]',stage).innerHTML=steps.length?steps.map((s,i)=>`<span><b>${i+1}</b>${esc(s)}</span>`).join(''):'<span class="muted">No steps yet.</span>'};$('[data-seq-add]',controls).onclick=()=>{const i=$('[data-seq-input]',controls),v=i.value.trim();if(v){steps.push(v);i.value='';draw();ping(600)}};$('[data-seq-undo]',controls).onclick=()=>{steps.pop();draw()};$('[data-seq-clear]',controls).onclick=()=>{steps=[];draw()};return;
    }
    if(type==='decisionmatrix'){
      stage.innerHTML='<div class="decision-grid"><div></div><b>Choice A</b><b>Choice B</b><span>Fits verified constraint</span><button type="button" data-dm="a-rule">?</button><button type="button" data-dm="b-rule">?</button><span>Reversible</span><button type="button" data-dm="a-rev">?</button><button type="button" data-dm="b-rev">?</button><span>Needs more evidence</span><button type="button" data-dm="a-ev">?</button><button type="button" data-dm="b-ev">?</button></div><p class="muted" data-dm-out>Tap each cell to cycle Yes → No → Unknown. Only the verified constraint is evidence-backed; other criteria are your scenario assumptions.</p>';
      controls.innerHTML='<button class="button primary" type="button" data-dm-claim>Show verified constraint</button><span class="muted" data-dm-claimtext hidden></span>';const vals=['?','Yes','No'];$$('[data-dm]',stage).forEach(b=>{let i=0;b.onclick=()=>{i=(i+1)%3;b.textContent=vals[i];b.dataset.state=vals[i].toLowerCase()}});$('[data-dm-claim]',controls).onclick=()=>{const x=$('[data-dm-claimtext]',controls);x.hidden=false;x.textContent=(l.verifiedClaims&&l.verifiedClaims[0])||l.takeaway||'';ping(600)};return;
    }
    if(type==='conceptmap'){
      stage.innerHTML='<div class="concept-map"><div class="concept-center">'+esc(l.title.replace(/^[^:]+:\s*/,''))+'</div><div class="concept-slots"><input aria-label="Prerequisite" placeholder="Prerequisite"><input aria-label="Related concept" placeholder="Related concept"><input aria-label="Consequence or use" placeholder="Consequence / use"><input aria-label="Question" placeholder="Open question"></div></div><p class="muted">Use relationship words in your notes: requires, constrains, produces, measures, depends on, differs from.</p>';
      controls.innerHTML='<button class="button primary" type="button" data-cm-evidence>Anchor to verified claim</button><span class="muted" data-cm-out></span>';$('[data-cm-evidence]',controls).onclick=()=>{$('[data-cm-out]',controls).textContent=(l.verifiedClaims&&l.verifiedClaims[0])||l.takeaway||'';ping(640)};return;
    }
    if(type==='hypothesis'){
      stage.innerHTML='<div class="workflow-grid"><article><span>H</span><h4>Hypothesis</h4><textarea rows="3" data-hyp-h placeholder="If…, then…"></textarea></article><article><span>+</span><h4>Supporting observation</h4><textarea rows="3" placeholder="What observation would support it?"></textarea></article><article><span>−</span><h4>Falsifying observation</h4><textarea rows="3" placeholder="What observation would refute it?"></textarea></article><article><span>E</span><h4>Evidence boundary</h4><div data-hyp-e class="workflow-claim" hidden></div></article></div>';
      controls.innerHTML='<button class="button primary" type="button" data-hyp-reveal>Reveal verified claim</button>';$('[data-hyp-reveal]',controls).onclick=()=>{const x=$('[data-hyp-e]',stage);x.hidden=false;x.textContent=(l.verifiedClaims&&l.verifiedClaims[0])||l.takeaway||'';ping(600)};return;
    }
    if(type==='teachback'){
      stage.innerHTML='<div class="teachback"><label>Explain it to a beginner<textarea rows="4" data-tb-simple></textarea></label><label>Explain it to a technical peer<textarea rows="4" data-tb-tech></textarea></label><div class="workflow-claim" data-tb-claim hidden></div></div>';
      controls.innerHTML='<button class="button primary" type="button" data-tb-reveal>Reveal verified claim</button><button class="button" type="button" data-tb-clear>Clear</button>';$('[data-tb-reveal]',controls).onclick=()=>{const x=$('[data-tb-claim]',stage);x.hidden=false;x.textContent=(l.verifiedClaims&&l.verifiedClaims[0])||l.takeaway||'';ping(620)};$('[data-tb-clear]',controls).onclick=()=>{$$('textarea',stage).forEach(x=>x.value='');$('[data-tb-claim]',stage).hidden=true};return;
    }
    if(type==='checklistbuilder'){
      stage.innerHTML='<div class="check-builder" data-cb-list></div><p class="muted">Write observable checks, not vague goals. Label assumptions separately from verified constraints.</p>';
      controls.innerHTML='<input type="text" data-cb-input maxlength="90" placeholder="Add an observable check"><button class="button primary" type="button" data-cb-add>Add</button><button class="button" type="button" data-cb-claim>Show verified constraint</button><span class="muted" data-cb-out></span>';let items=[];const draw=()=>{$('[data-cb-list]',stage).innerHTML=items.length?items.map((x,i)=>`<label><input type="checkbox"> ${esc(x)} <button type="button" data-cb-rm="${i}" aria-label="Remove item">×</button></label>`).join(''):'<span class="muted">No checks yet.</span>';$$('[data-cb-rm]',stage).forEach(b=>b.onclick=()=>{items.splice(+b.dataset.cbRm,1);draw()})};$('[data-cb-add]',controls).onclick=()=>{const i=$('[data-cb-input]',controls),v=i.value.trim();if(v&&items.length<8){items.push(v);i.value='';draw();ping(600)}};$('[data-cb-claim]',controls).onclick=()=>{$('[data-cb-out]',controls).textContent=(l.verifiedClaims&&l.verifiedClaims[0])||l.takeaway||'';ping(620)};draw();return;
    }
'''
if marker not in js: raise RuntimeError('interactive marker not found')
js=js.replace(marker,generic+marker,1)
(P/'knowledge.js').write_text(js,encoding='utf-8')

css=(P/'knowledge.css').read_text(encoding='utf-8')
css += r'''
/* v1.0 evidence-first generic interactive studios */
.workflow-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}.workflow-grid article,.teachback label{min-width:0;border:1px solid var(--line2);border-radius:14px;padding:1rem;background:color-mix(in srgb,var(--panel) 88%,transparent)}.workflow-grid article>span{display:inline-grid;place-items:center;width:2rem;height:2rem;border-radius:999px;border:1px solid var(--line2);font-weight:700}.workflow-grid h4{margin:.6rem 0}.workflow-grid textarea,.teachback textarea,.fault-tree textarea,.concept-slots input{width:100%;box-sizing:border-box;min-height:44px}.workflow-claim{margin-top:.75rem;padding:.85rem;border-left:3px solid var(--accent);background:var(--panel2);overflow-wrap:anywhere}.fault-tree{text-align:center}.fault-root{display:inline-block;padding:.85rem 1.2rem;border:1px solid var(--line2);border-radius:12px}.fault-branches{display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap;margin:1rem 0}.fault-branches button,.decision-grid button{min-height:44px}.fault-branches .selected{outline:2px solid var(--accent);outline-offset:2px}.sequence-strip{display:flex;gap:.6rem;flex-wrap:wrap;align-items:center}.sequence-strip span{display:flex;gap:.5rem;align-items:center;padding:.65rem .8rem;border:1px solid var(--line2);border-radius:999px}.decision-grid{display:grid;grid-template-columns:minmax(9rem,1.3fr) repeat(2,minmax(5rem,1fr));gap:.45rem;align-items:stretch}.decision-grid>*{padding:.7rem;border:1px solid var(--line2);border-radius:8px;min-width:0}.concept-map{display:grid;gap:1rem}.concept-center{justify-self:center;padding:1rem 1.25rem;border:2px solid var(--accent);border-radius:999px;text-align:center}.concept-slots{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.75rem}.teachback{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}.teachback label{display:grid;gap:.6rem}.check-builder{display:grid;gap:.5rem}.check-builder label{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:.6rem;padding:.65rem .75rem;border:1px solid var(--line2);border-radius:10px}.check-builder button{min-width:2.5rem;min-height:2.5rem}
@media(max-width:720px){.workflow-grid,.teachback,.concept-slots{grid-template-columns:1fr}.decision-grid{grid-template-columns:minmax(7.5rem,1.2fr) repeat(2,minmax(4.5rem,1fr));font-size:.88rem}.workflow-grid textarea,.teachback textarea,.fault-tree textarea{font-size:16px}.fault-branches{display:grid;grid-template-columns:1fr}.sequence-strip{align-items:stretch}.sequence-strip span{border-radius:10px}}
'''
(P/'knowledge.css').write_text(css,encoding='utf-8')

# Update version strings in pages and projects.
for f in P.glob('*.html'):
    t=f.read_text(encoding='utf-8')
    t=re.sub(r'v0\.9\.0|v0\.8\.0|v0\.7\.0','v1.0.0',t)
    f.write_text(t,encoding='utf-8')

# Release documentation.
counts=collections.Counter(l['domain'] for l in D['lessons'])
model_count=sum(bool(l.get('interactive')) for l in D['lessons'])
union_count=sum(1 for l in D['lessons'] if l.get('interactive') or l.get('kind')=='Lab')
atlas=sum(len(v) for v in D.get('atlas',{}).values())
release=f'''JOSHUA RANDALL KNOWLEDGE PLATFORM — v1.0.0\n\nPUBLISHED SCALE\n- Total verified learning objects: {len(D['lessons']):,}\n'''
for k in TARGETS:release+=f'- {domain_names[k]}: {counts[k]:,}\n'
release+=f'''- Practical labs: {lab_count:,}\n- Guided curricula: {len(D['paths']):,}\n- Glossary concepts: {len(D['glossary']):,}\n- Unique interactive learning experiences (lab or model/workflow): {union_count:,}\n- Model/workflow-backed objects: {model_count:,}\n- Mapped future topics retained: {atlas:,}\n\nCONTENT DESIGN\nThe factual layer remains narrow and source-verifiable. New practice objects inherit an exact verified claim and the same authoritative evidence from one of 1,400 core source lessons. New scenarios, learner prompts, decisions, and hypothetical failures are explicitly pedagogical and do not introduce additional factual claims.\n\nNew learning modes include configuration labs, diagnostic labs, trace labs, fault isolation, prediction, counterexamples, measurement, runbooks, recovery, boundary-condition testing, concept maps, hypothesis testing, retrieval ladders, teach-back, design critique, mistake hunts, evidence reading, field notes, exam-style practice, and confidence calibration.\n\nSCALABILITY\nThe UI continues to paginate/bound large collections instead of rendering thousands of cards at once. Lesson content is split into Overview, Learn, Explore/Lab, Practice, and Evidence views.\n'''
(OUT/'RELEASE_NOTES_v1.0.0.txt').write_text(release,encoding='utf-8')
policy='''JOSHUA RANDALL KNOWLEDGE PLATFORM — SOURCE VERIFICATION POLICY v1.0.0\n\nPUBLICATION GATE\n1. Every published learning object exposes at least one narrow, checkable factual claim.\n2. Every factual claim links directly to authoritative evidence.\n3. Derived learning objects inherit an exact verified claim and the same references from a core source lesson.\n4. Hypothetical scenarios, learner predictions, calculations, design choices, and exercises are pedagogical—not additional factual claims.\n5. The original evidence review date is preserved. A separate derived/build date never masquerades as a fresh source review.\n6. Version-sensitive technologies remain labeled and must be rechecked against current official documentation before operational use.\n7. Interactive models that simplify real systems must remain educational models rather than claims of exact implementation behavior.\n\n“Verified” means supported by the linked evidence on the recorded source-review date.\n'''
(OUT/'SOURCE_VERIFICATION_POLICY_v1.0.0.txt').write_text(policy,encoding='utf-8')

# Human-facing deployment checklist in package (final response will also give steps).
(OUT/'DEPLOYMENT_CHECKLIST.txt').write_text('''FULL REPLACEMENT UPDATE\n\nThis package is designed to overwrite the Knowledge Platform / portfolio page files while preserving any unrelated assets already in public_html.\n\n1. Back up the existing public_html folder.\n2. Extract this ZIP.\n3. Open the extracted public_html folder.\n4. Copy every file inside it into the existing OSU public_html folder.\n5. Choose Replace/Overwrite for matching files.\n6. Do NOT delete the existing assets folder, styles.css, app.js, resume.html, or other unrelated project downloads unless you separately intend to replace them.\n7. Hard refresh the live site and test Home, Projects, Learn, Browse, Paths, Practice, Labs, Glossary, Map, Mastery, and Verification.\n''',encoding='utf-8')
(P/'README_KNOWLEDGE_PLATFORM.txt').write_text(f'Joshua Randall Knowledge Platform v1.0.0 — {len(D["lessons"]):,} published learning objects; {lab_count:,} labs; {len(D["paths"]):,} curricula; {len(D["glossary"]):,} glossary concepts; {union_count:,} interactive learning experiences.\n',encoding='utf-8')
# Remove obsolete README_FIRST from prior release; deployment is explicit in final + checklist.
if (OUT/'README_FIRST.txt').exists():(OUT/'README_FIRST.txt').unlink()

# Copy this builder into source for reproducibility.
source=OUT/'source';source.mkdir(exist_ok=True)
shutil.copy2('/mnt/data/build_v10.py',source/'build_v10.py')

# Validator.
validate=source/'validate_v10.py'
validate.write_text(r'''from pathlib import Path
import json,re,urllib.parse,subprocess,sys,collections,csv
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'public_html'
s=(P/'knowledge-data.js').read_text(encoding='utf-8');D=json.loads(s[s.index('{'):s.rfind('}')+1]);L=D['lessons'];errors=[]
ids=[x['id'] for x in L];titles=[re.sub(r'\W+',' ',x['title'].lower()).strip() for x in L];idset=set(ids)
expected={'cloud':1200,'advanced':1200,'software':1150,'cyber':1150,'leadership':1100,'math':1100,'physics':1100}
counts=collections.Counter(x['domain'] for x in L)
if D.get('version')!='1.0.0':errors.append('wrong version')
if len(L)!=8000:errors.append(f'expected 8000, got {len(L)}')
if dict(counts)!=expected:errors.append('domain counts '+repr(dict(counts)))
if len(ids)!=len(set(ids)):errors.append('duplicate IDs')
if len(titles)!=len(set(titles)):errors.append('duplicate titles')
allowed=set('openstax.org sre.google www.nist.gov www.rfc-editor.org www.postgresql.org docs.python.org git-scm.com csrc.nist.gov www.intel.com dlmf.nist.gov kubernetes.io docs.nvidia.com docs.kernel.org learn.microsoft.com www.mpi-forum.org cheatsheetseries.owasp.org ocw.mit.edu www.openmp.org docs.riscv.org pages.nist.gov www.cisa.gov quantum.cloud.ibm.com docs.redhat.com developer.hashicorp.com www.usenix.org docs.aws.amazon.com opentelemetry.io www.gnu.org lamport.azurewebsites.net slurm.schedmd.com prometheus.io www.freedesktop.org systemd.io escholarship.org www.iana.org pubs.opengroup.org developer.download.nvidia.com'.split())
for x in L:
    if x.get('verification',{}).get('status')!='verified':errors.append(x['id']+': not verified')
    if not x.get('verifiedClaims'):errors.append(x['id']+': missing claim')
    if not x.get('references'):errors.append(x['id']+': missing evidence')
    for r in x.get('references',[]):
        u=urllib.parse.urlparse(r[1]);host=u.netloc.lower()
        if u.scheme!='https' or not host:errors.append(x['id']+': bad URL')
        if host not in allowed:errors.append(x['id']+': unapproved source '+host)
    for k in ('prereq','related'):
        for y in x.get(k,[]):
            if y not in idset:errors.append(x['id']+': bad '+k+' '+y)
    q=x.get('quiz')
    if q and (not q.get('options') or not isinstance(q.get('answer'),int) or not 0<=q['answer']<len(q['options'])):errors.append(x['id']+': bad quiz')
if len(D.get('paths',[]))!=300:errors.append('paths '+str(len(D.get('paths',[]))))
for p in D.get('paths',[]):
    if not p.get('lesson_ids'):errors.append('empty path '+p.get('id','?'))
    for y in p.get('lesson_ids',[]):
        if y not in idset:errors.append('path missing '+y)
if len(D.get('glossary',[]))!=1600:errors.append('glossary '+str(len(D.get('glossary',[]))))
for g in D.get('glossary',[]):
    if g.get('lesson_id') not in idset:errors.append('glossary missing '+g.get('term','?'))
labs=sum(x.get('kind')=='Lab' for x in L);inter=sum(1 for x in L if x.get('kind')=='Lab' or x.get('interactive'))
if labs!=3000:errors.append('labs '+str(labs))
if inter!=4000:errors.append('interactive union '+str(inter))
for name in ['learn.html','learn-browse.html','learn-paths.html','learn-practice.html','learn-labs.html','learn-glossary.html','learn-map.html','learn-mastery.html','learn-verify.html','index.html','projects.html']:
    if not (P/name).exists():errors.append('missing '+name)
for f in P.glob('*.html'):
    t=f.read_text(encoding='utf-8');xs=re.findall(r'\bid=["\']([^"\']+)',t);dups=[k for k,v in collections.Counter(xs).items() if v>1]
    if dups:errors.append(f.name+': duplicate IDs '+repr(dups[:5]))
try:subprocess.run(['node','--check',str(P/'knowledge.js')],check=True,capture_output=True,text=True)
except Exception as e:errors.append('JS syntax '+str(e))
M=json.loads((P/'verification-manifest.json').read_text(encoding='utf-8'))
if M.get('version')!='1.0.0' or M.get('count')!=8000 or len(M.get('records',[]))!=8000:errors.append('manifest mismatch')
print('VALIDATION','PASS' if not errors else 'FAIL')
print('lessons',len(L),'domains',dict(counts),'labs',labs,'paths',len(D.get('paths',[])),'glossary',len(D.get('glossary',[])),'interactive_experiences',inter,'model_workflows',sum(bool(x.get('interactive')) for x in L))
if errors:
    print('\n'.join('ERROR: '+e for e in errors[:120]));sys.exit(1)
''',encoding='utf-8')
r=subprocess.run([sys.executable,str(validate)],capture_output=True,text=True)
print(r.stdout);print(r.stderr,file=sys.stderr)
if r.returncode:raise SystemExit(r.returncode)
(OUT/'VALIDATION_v1.0.0.txt').write_text('JOSHUA RANDALL KNOWLEDGE PLATFORM — v1.0.0 VALIDATION\n\n'+r.stdout+'\nChecks include exact scale targets, unique IDs/titles, approved evidence hosts, relationships, quizzes, curricula, glossary links, JavaScript syntax, duplicate HTML IDs, and verification-manifest integrity.\n',encoding='utf-8')

# Static HTTP smoke test.
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
cwd=Path.cwd()
try:
    os.chdir(P);server=socketserver.TCPServer(('127.0.0.1',0),Quiet);port=server.server_address[1];th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
    for name in ['index.html','projects.html','learn.html','learn-browse.html','learn-paths.html','learn-practice.html','learn-labs.html','learn-glossary.html','learn-map.html','learn-mastery.html','learn-verify.html','knowledge-data.js','knowledge.js','knowledge.css','verification-manifest.json']:
        import urllib.request
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/{name}',timeout=5) as resp:
            if resp.status!=200:raise RuntimeError(name+' HTTP '+str(resp.status))
    server.shutdown();server.server_close()
finally:os.chdir(cwd)

# Zip and integrity test.
if ZIP.exists():ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in OUT.rglob('*'):
        if f.is_file():z.write(f,Path(OUT.name)/f.relative_to(OUT))
with zipfile.ZipFile(ZIP) as z:
    bad=z.testzip();assert bad is None,bad
print('ZIP',ZIP,ZIP.stat().st_size)
print('FINAL lessons',len(D['lessons']),'labs',lab_count,'paths',len(D['paths']),'glossary',len(D['glossary']),'interactive',interactive_union,'models',model_count)
